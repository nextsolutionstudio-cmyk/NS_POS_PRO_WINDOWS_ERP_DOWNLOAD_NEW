# NS POS PRO Automatic Printer Fit v4.5.4 / Windows v4.8.3 (Source Only)

## ගැටලුව / Fix
- 58mm XP-P502A/P302A, 80mm XP-P301A (default), XP-80T සහ Windows printer profiles.
- Known printer name අනුව 58/80mm auto select; unknown name Android default 58mm to prevent cropping. Printer width cannot be reliably detected over generic Bluetooth SPP; Settings යටතේ one-time width calibration option ඇත.
- Android receipt logo max 192 dots (58mm) / 256 dots (80mm), centered inside 384/576 raster. ESC a left before and after raster.
- separator auto converts to paper width (32 or 42 text columns); duplicate contact header එකක් නැහැ; website display 'www.'; footer once only.
- Test Print is a separate action under printer settings. Do not print both bill and test for the same transaction.
- Windows receipt print uses each installed printer's selected 58/80mm profile, centered logo and contact info once.

## Build / Install
1. Android: import Android_Source directory into GitHub repo, use existing `.github/workflows/build-apk.yml` to build APK, install it as an update after testing/signing.
2. Windows: import Windows_Source, run `npm run check`, then existing GitHub workflow for EXE. Use Windows Printers & scanners to install driver/queue; normal checkout requires no manual choice.
3. Test XP-P502A / XP-P301A / XP-80T physical printers: print test under Settings, then ONE saved bill. Compare line wrapping, centered business logo, footer.
4. Android Bluetooth pairing and permission must be granted once. Windows automatic selection works only for printers installed as Windows printer queues.
5. If the Bluetooth name has unknown width or XP-P301A is using 58mm roll, print a test once, then change 'Printer Paper Width' in Settings (one-time).
6. Changes are local source only: NO cloud deploy, no installed APK/EXE, no physical printer test; do not overwrite live customer databases.

## Files
- Android_Source/app/src/main/java/.../MainActivity.java — native printer sizing/logo.
- Android_Source/app/src/main/assets/ns_receipt_auto_fit_v1.js — receipt builder and profile calibration.
- Windows_Source/desktop/receipt-renderer.cjs — 58/80mm print layout.

## Important
Many generic ESC/POS printers cannot report actual roll width via Bluetooth SPP. Width is inferred from model name or configured once. The second 'Next Solution Studio TEST PRINT' shown in the supplied photo was a separate test receipt; do not assume the POS appended it automatically without a print log.
