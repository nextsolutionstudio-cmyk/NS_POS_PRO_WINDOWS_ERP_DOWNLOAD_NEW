# NS POS PRO Windows ERP v4.9.0 — Premium Desktop Dashboard

## අලුත් Windows Desktop UI

- Fixed dark-blue sidebar, grouped as Overview / Sales & Cashier / Stock & Purchases / Delivery / Accounts & Reports / HR / System.
- Windows-friendly top search (`Ctrl + K`), New Bill shortcut and subscription status.
- 4-column real-device summary: today's sales, bills, products, low-stock count.
- Colourful workspace tiles; choose Billing, Stock, Delivery, Accounts, HR or Settings to filter the shortcuts.
- Recent sales and low stock lists use locally saved existing records only. No invented cloud revenue or combined ERP figures.
- Admin / Cashier / Rep / HR menu filtering. Rep and Cashier dashboards do not display HR and Payroll navigation. **This is UI visibility only; server-side data permissions must be enabled in production.**
- Existing Windows billing, product, GRN, invoices, shop routes, owner/cloud login and printer code retained. No data migration.
- Original v4.8.3 Windows printer auto-fit code retained: 58mm/80mm and printer selection logic; please test with physical printers.

## Not yet ported from newer Android v4.5.9

This project is a Windows dashboard upgrade on the existing Windows v4.8.3 base. The latest Android-specific **GRN supplier return**, **A4 Letter Writer**, **Employee document upload and print archive**, and full Owner remote support features have **not all been merged into Windows**. Do not treat the new dashboard as proof those workflows are available on Windows. Do not promise that all role/API controls are production-ready.

## Windows EXE build through GitHub Actions

1. Create/open a **private** GitHub repository and upload the *extracted source files*, preserving `.github/workflows/build-windows-exe.yml`, `app/`, `desktop/`, `package.json`, and `tests/`.
2. In GitHub Actions run **Build NS POS PRO Windows EXE** (or commit changes to trigger it).
3. When workflow succeeds, download the artifact `NS-POS-PRO-Windows-EXE` from the successful run. It should contain Installer and Portable x64 EXE files.
4. `npm run check` to run automated Node tests; `npm run dist:win` on Windows after `npm install` is an alternative.

**This environment has no access to the Electron npm dependencies**, so an actual EXE has NOT been compiled or installed/tested here. Do not rename the ZIP to .exe. The included Github workflow builds it in a Windows runner.

## Important before installing

- Never uninstall the existing POS before making a verified backup of local invoices, products and stock.
- This Windows base performs Cloud license verification while online. Review cloud login and backups before production deployment.
- Staff role separation must be enforced by Cloudflare on each API, not just hidden navigation.
- The HTML Preview is an interactive visual demonstration containing SAMPLE DATA only, not your business records.
- Windows Installer signing is not configured. A signed installer from an authorized certificate should be created before broad distribution.

© Developed by Next Solution Studio
