'use strict';
const {app, BrowserWindow, ipcMain, protocol, net, shell, session} = require('electron');
const {join, resolve, sep} = require('node:path');
const {pathToFileURL} = require('node:url');
const fs = require('node:fs');
const {active} = require('./license-policy.cjs');
const Printer = require('./printer-service.cjs');
const API = 'https://ns-pos-pro-cloud.nextsolutionstudio.workers.dev';
const HOST = 'nspos';
const ALLOWED_ORIGIN = `nspos://${HOST}`;
const CHECK_EVERY_MS = 30000; // Online-only trial: no offline grace / fail-closed.
const root = resolve(__dirname, '..', 'app');
let win, tick, checking = false, licensed = false, token = '', tenant = null, role = '';

protocol.registerSchemesAsPrivileged([{scheme:'nspos', privileges:{standard:true, secure:true, supportFetchAPI:true, stream:true}}]);

function isLocal(url, page) {
 try {const u=new URL(url);return u.origin === ALLOWED_ORIGIN && (!page || u.pathname === `/${page}`);}
 catch {return false;}
}
function assertSender(e, page) {
 if (!win || e.sender !== win.webContents || !isLocal(e.senderFrame?.url||e.sender.getURL(),page)) throw new Error('Invalid app page');
}
async function api(path, opts={}) {
 const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),10000);
 try {
  const response=await fetch(API+path, {method:opts.body?'POST':'GET',
   headers:{'Content-Type':'application/json',...(opts.token?{Authorization:'Bearer '+opts.token}:{})},
   body:opts.body?JSON.stringify(opts.body):undefined, signal:ctrl.signal, cache:'no-store'});
  const payload=await response.json().catch(()=>({error:'Invalid Cloud response'}));
  if(!response.ok)throw new Error(payload.error || `Cloud ${response.status}`);
  return payload;
 }finally{clearTimeout(timer);}
}
function lock(reason='Cloud verification required. Please sign in again.'){
 licensed=false;token='';tenant=null;role='';
 if (win && !win.isDestroyed()) {
  const to=`${ALLOWED_ORIGIN}/desktop-login.html`;
  if(!isLocal(win.webContents.getURL(),'desktop-login.html')) win.loadURL(to);
  else win.webContents.send('desktop:locked',reason);
 }
}
async function verify(){
 if(!licensed || !token || checking)return;
 checking=true;
 try {
  const me=await api('/v1/auth/me',{token});
  if(!me.licenseActive || !active(me.tenant)) {lock('Trial expired or your company was blocked by Developer Owner.');return;}
  if(!tenant || tenant.id!==me.tenant.id){lock('Company session changed; sign in again.');return;}
  tenant=me.tenant;
  if(win && !win.isDestroyed())win.webContents.send('desktop:license-updated',{name:tenant.name,expiresAt:tenant.expires_at,role});
 }catch(e){
  // No grace period on trial builds: this prevents staying unlocked after remote block.
  lock('Could not verify your subscription online. Reconnect to Internet and sign in.');
 }finally{checking=false;}
}
function handleWindow(){
 win = new BrowserWindow({width:1500,height:900,minWidth:1060,minHeight:700,
  show:false,backgroundColor:'#f4f7fc',title:'NS POS PRO Desktop · All-in-One Business Management',
  autoHideMenuBar:true,webPreferences:{preload:join(__dirname,'preload.cjs'),nodeIntegration:false,
   contextIsolation:true,sandbox:true,webSecurity:true,devTools:!app.isPackaged}});
 win.once('ready-to-show',()=>win.show());
 win.webContents.on('will-navigate',(event,url)=>{
  if(!isLocal(url))return event.preventDefault();
  if(new URL(url).pathname==='/index.html' && !licensed)event.preventDefault();
 });
 win.webContents.setWindowOpenHandler(({url})=>{
  try{const u=new URL(url);if(u.protocol==='https:'&&['wa.me','www.google.com','maps.google.com'].includes(u.hostname))shell.openExternal(url);}catch{}
  return {action:'deny'};
 });
 win.on('focus',()=>{if(licensed)verify();});
 win.on('closed',()=>{win=null;});
 win.loadURL(`${ALLOWED_ORIGIN}/desktop-login.html`);
}

app.whenReady().then(async()=>{
 protocol.handle('nspos',request=>{
  const url=new URL(request.url);
  if(url.host!==HOST) return new Response('Not found',{status:404});
  let relative;
  try{relative=decodeURIComponent(url.pathname).replace(/^\/+/, '');}catch{return new Response('Bad URL',{status:400});}
  if(!relative || relative.includes('\\'))return new Response('Not found',{status:404});
  const full=resolve(root,relative);
  if(!full.startsWith(root+sep))return new Response('Not found',{status:404});
  return net.fetch(pathToFileURL(full).toString());
 });
 session.defaultSession.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 // Customer app assets are packaged locally; deny embedded external page loads.
 session.defaultSession.webRequest.onBeforeRequest(({url,resourceType},callback)=>{
  if(url.startsWith(ALLOWED_ORIGIN+'/') || url.startsWith(API+'/') || url.startsWith('data:') || url.startsWith('blob:'))return callback({cancel:false});
  // Some POS functions open maps/share URLs in the OS browser instead.
  if(resourceType==='mainFrame')return callback({cancel:true});
  return callback({cancel: !url.startsWith('https://')});
 });
 ipcMain.handle('desktop:login',async(e,username,password)=>{
  assertSender(e,'desktop-login.html');
  if(typeof username!=='string'||typeof password!=='string'||username.length>254||password.length>128)return {ok:false,error:'Invalid credentials'};
  try{
   const r=await api('/v1/auth/login',{body:{username:username.trim().toLowerCase(),password}});
   if(!r.token||!r.tenant||!active(r.tenant)||!r.licenseActive)return {ok:false,error:'Trial expired or business blocked. Contact Developer Owner.'};
   const me=await api('/v1/auth/me',{token:r.token});
   if(!me.licenseActive||!active(me.tenant))return {ok:false,error:'Subscription is not active'};
   // Do not silently reuse a shared local billing database for a different company.
   // Owner should deploy a separate Windows OS user / installation for each tenant.
   const bindingPath=join(app.getPath('userData'),'bound-tenant.json');
   let bound=null;
   try{bound=JSON.parse(fs.readFileSync(bindingPath,'utf8'))?.tenantId}catch(e){if(e.code!=='ENOENT')throw e;}
   if(bound && bound!==me.tenant.id)return {ok:false,error:'This Windows profile is assigned to another company. Contact Developer Owner and export data before reassignment.'};
   if(!bound){fs.mkdirSync(app.getPath('userData'),{recursive:true});fs.writeFileSync(bindingPath,JSON.stringify({tenantId:me.tenant.id}),'utf8');}
   licensed=true;token=r.token;tenant=me.tenant;role=r.role;
   return {ok:true,auth:{token:r.token,role:r.role,tenant:r.tenant,uid:r.user.id,businessCode:r.tenant.id},expiresAt:r.tenant.expires_at};
  }catch(error){return {ok:false,error:'Cloud sign-in failed: '+error.message};}
 });
 ipcMain.handle('desktop:open-app',async e=>{
  assertSender(e,'desktop-login.html');
  if(!licensed || !token || !tenant || !active(tenant))return {ok:false,error:'License not active'};
  await win.loadURL(`${ALLOWED_ORIGIN}/index.html`);return {ok:true};
 });
 ipcMain.handle('desktop:status',e=>{
  assertSender(e);return {ok:licensed,tenant:licensed?{name:tenant.name,expires_at:tenant.expires_at}:null,role:licensed?role:null};
 });
 ipcMain.handle('desktop:logout',async e=>{assertSender(e);lock('Signed out.');return {ok:true};});
 ipcMain.handle('desktop:printer-status',async e=>{
  assertSender(e,'index.html');if(!licensed)return {ok:false,error:'Trial not active'};
  return {ok:true,...await Printer.status(app,win.webContents)};
 });
 ipcMain.handle('desktop:printer-width',async(e,name,width)=>{
  assertSender(e,'index.html');if(!licensed)return {ok:false,error:'Trial not active'};
  // Authorize against installed printer names rather than trusting arbitrary renderer input.
  const info=await Printer.status(app,win.webContents);
  if(!info.printers.some(p=>p.name===name))return {ok:false,error:'Printer is not installed'};
  try{return Printer.setWidth(app,name,width)}catch(error){return {ok:false,error:error.message}};
 });
 ipcMain.handle('desktop:print',async(e,invoice)=>{
  assertSender(e,'index.html');if(!licensed)return {ok:false,message:'Trial not active'};
  if(!invoice||!Array.isArray(invoice.lines)||invoice.lines.length>200)return {ok:false,message:'Invalid receipt data'};
  return Printer.printPage(app,win.webContents,invoice);
 });
 ipcMain.handle('desktop:test-print',async e=>{
  assertSender(e,'index.html');if(!licensed)return {ok:false,message:'Trial not active'};
  return Printer.printPage(app,win.webContents,{test:true});
 });
 handleWindow();tick=setInterval(verify,CHECK_EVERY_MS);
});
app.on('before-quit',()=>{if(tick)clearInterval(tick)});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)handleWindow()});

