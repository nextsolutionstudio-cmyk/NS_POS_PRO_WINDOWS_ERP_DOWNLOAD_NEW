'use strict';
function active(t, clock=Date.now()) {
 const expiry=Date.parse(t?.expires_at ?? '');
 return !!t && t.status==='active' && Number.isFinite(expiry) && expiry>clock;
}
module.exports={active};
