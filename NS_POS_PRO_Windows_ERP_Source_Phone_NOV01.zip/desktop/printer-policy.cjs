'use strict';
// Deterministic printer selection. No silent fallback to Microsoft PDF, OneNote, etc.
const EXCLUDE = /pdf|onenote|fax|xps document|send to|file printer|microsoft print/i;
function modelOf(name='') {
 const s=String(name).toLowerCase().replace(/[\s_]+/g,'');
 if(/(?:xp[-]?p502a|p502a)/.test(s))return {model:'XP-P502A',width:58,adjustable:false};
 if(/(?:xp[-]?p302a|p302a)/.test(s))return {model:'XP-P302A',width:58,adjustable:false};
 if(/(?:xp[-]?p301a|p301a)/.test(s))return {model:'XP-P301A',width:80,adjustable:true};
 if(/(?:xp[-]?80t|xp80t)/.test(s))return {model:'XP-80T',width:80,adjustable:false};
 if(/(?:xprinter|thermal|receipt|pos[-_ ]?80|pos[-_ ]?58)/i.test(name)){
  return {model:'Thermal Printer',width:/(?:58mm|pos.?58)/i.test(name)?58:80,adjustable:true};
 }
 return null;
}
function getIdentity(p){return String(p.name||p.displayName||'');}
function describePrinter(p,profiles={},windowsInfo=[]) {
 const name=getIdentity(p),driverName=String(p.displayName||'');
 const model=modelOf(name)||modelOf(driverName)||modelOf(p.description);
 if(!model||EXCLUDE.test(name+' '+driverName))return null;
 const win=windowsInfo.find(w=>String(w.Name||'').toLowerCase()===name.toLowerCase() || String(w.Name||'').toLowerCase()===driverName.toLowerCase())||{};
 const offline=win.WorkOffline===true || win.WorkOffline==='True';
 const custom=profiles[name];
 const width=model.adjustable && (custom===58||custom===80)?custom:model.width;
 return {name,displayName:driverName||name,model:model.model,width,adjustable:model.adjustable,
   offline,availability:offline?'Reported offline':Object.keys(win).length?'Installed; driver availability reported':'Installed; connection unverified',
   isDefault:win.Default===true||win.Default==='True',port:win.PortName||null};
}
function choosePrinter(printers,profiles={},last='',winList=[]) {
 const candidates=printers.map(p=>describePrinter(p,profiles,winList)).filter(Boolean);
 const ready=candidates.filter(p=>!p.offline);
 const selected=ready.find(p=>p.name===last) || ready.find(p=>p.isDefault) || ready[0] || null;
 return {selected,printers:candidates};
}
function pageHeightMm(rowCount){return Math.min(1100,Math.max(155,100+Math.min(200,rowCount)*8));}
module.exports={modelOf,describePrinter,choosePrinter,pageHeightMm};
