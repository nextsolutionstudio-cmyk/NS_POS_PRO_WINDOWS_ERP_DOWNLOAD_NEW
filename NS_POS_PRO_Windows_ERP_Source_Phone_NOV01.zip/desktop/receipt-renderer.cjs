'use strict';
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const short=(s,max=150)=>escape(String(s??'').slice(0,max));
const cash=n=>{let v=Number(n);return Number.isFinite(v)?v.toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2}):'0.00';};
const website=x=>{let s=String(x??'').trim().replace(/^https?:\/\//i,'').replace(/^\/\//,'');return s && !/^www\./i.test(s)?'www.'+s:s;};
const phones=b=>[...new Set([b.phone,b.phone2,b.phone3].map(x=>String(x||'').trim()).filter(Boolean))].join(' / ');
const row=(label,value)=>`<div class="row"><span>${label}</span><b>${value}</b></div>`;
function createPage(data,width){
 const isTest=data?.test===true;
 const b=isTest?{}:(data?.business||{});
 const items=Array.isArray(data?.lines)?data.lines.slice(0,200):[];
 const paperWidth=width===58?58:80;
 const innerWidth=paperWidth===58?48:70;
 const title=isTest?'NS POS PRO – Printer Test':short(b.name||'Business',120);
 const safeLogo=typeof b.logo==='string' && /^data:image\/(?:png|jpeg|webp);base64,[a-zA-Z0-9+/=]{100,280000}$/.test(b.logo)?b.logo:'';
 const logo=safeLogo?`<img class=\"logo\" src=\"${safeLogo}\" alt=\"Company logo\">`:'';
 const content=isTest?`<h2>NS POS PRO</h2><p>PRINTER TEST • ${paperWidth}mm</p><div class="dash"></div><p>Next Solution Studio</p><p>ABCDEFGHIJKLMNOPQRSTUVWXYZ</p><p>0123456789</p><div class="dash"></div><p>Width: ${paperWidth}mm</p><p>USB / Bluetooth via Windows driver</p><p class="small">If this line fits, alignment is correct.</p>`:
 `${logo}<h2>${title}</h2><p class="center">${short(b.address||'',240)}</p><p class="center">${short(phones(b),90)}</p><p class="center small">${short(b.email||'',110)}<br>${short(website(b.website),110)}</p>
 <div class="dash"></div>${row('Bill',short(data.number,55))}${row('Date',short(data.date,60))}${row('Customer',short(data.customer||'Walk-in',85))}${data.phone?row('Phone',short(data.phone,45)):''}
 <div class="dash"></div><div class="lines">${items.map(x=>`<div class="item"><div class="item-name">${short(x.name,135)}</div><div class="item-values"><span>${short(x.qty,14)} x ${cash(x.rate)}</span><b>${cash(Number(x.qty)*Number(x.rate))}</b></div></div>`).join('')}</div>
 <div class="dash"></div>${row('Subtotal',cash(data.subtotal))}${row('Discount',cash(data.discount))}${Number(data.taxAmount)?row('Tax',cash(data.taxAmount)):''}<div class="total">${row('TOTAL Rs.',cash(data.total))}</div>${row('Paid',cash(data.paid))}${row('Balance',cash(data.balance))}${row('Payment',short(data.payment||'Cash',60))}${data.paymentNote?row('Ref',short(data.paymentNote,85)):''}
 <div class="dash"></div><p class="center">${short(data.note||b.footer||'Thank you!',230)}</p><p class="center small">© Developed by Next Solution Studio</p>`;
 const heightMm=Math.min(1100,Math.max(155,110+items.length*14));
 // Electron pageSize sets the same physical width as the CSS; don't rely on old 80mm @page rules.
 return {heightMm,html:`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>NS POS PRO Receipt</title><style>
 @page{size:${paperWidth}mm ${heightMm}mm;margin:0}*{box-sizing:border-box}
 html,body{padding:0;margin:0;background:white;color:black;width:${paperWidth}mm;font-family:Arial,'Segoe UI',sans-serif}
 .paper{width:${innerWidth}mm;margin:0 auto;padding-top:2.5mm;padding-bottom:5mm;font-size:${paperWidth===58?'10':'12'}px;overflow-wrap:anywhere}
 .logo{display:block;max-width:${paperWidth===58?'28':'43'}mm;max-height:${paperWidth===58?'18':'23'}mm;object-fit:contain;margin:0 auto 2mm}
 h2{text-align:center;font-size:${paperWidth===58?'15':'19'}px;margin:3mm 0 2mm;line-height:1.2}
 .center{text-align:center}.small{font-size:9px}.paper p{margin:2mm 0}.dash{border-top:1px dashed #333;margin:3mm 0}
 .row{display:flex;justify-content:space-between;gap:5px;align-items:baseline;margin:1.8mm 0;font-size:inherit}.row span{overflow-wrap:anywhere;flex:1}.row b{text-align:right;overflow-wrap:anywhere}
 .item{padding:1.1mm 0}.item-name{font-weight:600}.item-values{display:flex;justify-content:space-between;gap:4px;padding-left:4px}
 .total{border-top:1px solid #222;border-bottom:1px solid #222;font-size:1.24em;margin:2.8mm 0;font-weight:900}
 </style></head><body><div class="paper">${content}</div></body></html>`};
}
module.exports={createPage,escape};
