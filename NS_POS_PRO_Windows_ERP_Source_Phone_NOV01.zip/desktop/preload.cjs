'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('NSDesktop',Object.freeze({
 signIn:(username,password)=>ipcRenderer.invoke('desktop:login',String(username),String(password)),
 openApp:()=>ipcRenderer.invoke('desktop:open-app'),
 getLicense:()=>ipcRenderer.invoke('desktop:status'),
 logout:()=>ipcRenderer.invoke('desktop:logout'),
 testPrint:()=>ipcRenderer.invoke('desktop:test-print'),
 onLicenseUpdate:handler=>{
  if(typeof handler==='function')ipcRenderer.on('desktop:license-updated',(_e,v)=>handler(v));
 },
 onLock:handler=>{if(typeof handler==='function')ipcRenderer.on('desktop:locked',(_e,v)=>handler(v))}
}));
contextBridge.exposeInMainWorld('NSDesktopPrinter',Object.freeze({
 printBill:(invoice)=>ipcRenderer.invoke('desktop:print',invoice),
 getStatus:()=>ipcRenderer.invoke('desktop:printer-status'),
 setWidth:(name,width)=>ipcRenderer.invoke('desktop:printer-width',String(name),Number(width))
}));
