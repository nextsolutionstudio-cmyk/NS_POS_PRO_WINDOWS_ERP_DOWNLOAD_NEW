'use strict';
const {BrowserWindow}=require('electron');
const {join}=require('node:path');
const fs=require('node:fs');
const {execFile}=require('node:child_process');
const {promisify}=require('node:util');
const {choosePrinter}=require('./printer-policy.cjs');
const {createPage}=require('./receipt-renderer.cjs');
const run=promisify(execFile);
let busy=false;
function configPath(app){return join(app.getPath('userData'),'windows-printer-profiles.json');}
function readConfig(app){try{const raw=JSON.parse(fs.readFileSync(configPath(app),'utf8'));return {last:raw.last||'',profiles:raw.profiles||{}};}catch{return {last:'',profiles:{}};}}
function writeConfig(app,c){const dest=configPath(app);fs.mkdirSync(app.getPath('userData'),{recursive:true});fs.writeFileSync(dest,JSON.stringify(c,null,2));}
async function windowsPrinters(){
 if(process.platform!=='win32')return [];
 try{
  const script='Get-CimInstance Win32_Printer | Select-Object Name,Default,WorkOffline,PortName | ConvertTo-Json -Compress';
  const {stdout}=await run('powershell.exe',['-NoProfile','-NonInteractive','-Command',script],{timeout:3500,windowsHide:true,maxBuffer:256000});
  const result=JSON.parse(stdout);return Array.isArray(result)?result:[result];
 }catch{return [];}
}
async function status(app,webContents){
 const c=readConfig(app);
 const [printers,wmi]=await Promise.all([webContents.getPrintersAsync(),windowsPrinters()]);
 const x=choosePrinter(printers,c.profiles,c.last,wmi);
 return {selected:x.selected,printers:x.printers,driversFound:printers.length,busy};
}
function setWidth(app,printerName,requestedWidth){
 const c=readConfig(app), width=Number(requestedWidth);
 if(width!==58&&width!==80)throw Error('Width must be 58 or 80mm');
 if(typeof printerName!=='string'||printerName.length>250)throw Error('Invalid printer');
 if(!/(?:XP-P301A|XPRINTER|thermal|POS.?80|POS.?58)/i.test(printerName))throw Error('Not a known configurable printer');
 // A fixed-width model cannot be accidentally assigned the wrong paper size.
 if(/(?:XP-P502A|XP-P302A)/i.test(printerName)&&width!==58)throw Error('This model only supports 58mm');
 if(/XP-80T/i.test(printerName)&&width!==80)throw Error('This model only supports 80mm');
 c.profiles[printerName]=width;writeConfig(app,c);
 return {ok:true};
}
async function printPage(app,webContents,data){
 if(busy)return {ok:false,message:'A print job is already being prepared. Do not press Print twice.'};
 busy=true;
 let printWindow;
 try{
  const cfg=readConfig(app);
  const current=await status(app,webContents);
  const printer=current.selected;
  if(!printer)return {ok:false,message:'No supported Xprinter is available in Windows Printers & scanners. Check driver, USB/Bluetooth pairing and Windows print queue.'};
  if(!data||typeof data!=='object')return {ok:false,message:'No saved bill available'};
  const page=createPage(data,printer.width);
  printWindow=new BrowserWindow({show:false,backgroundColor:'#ffffff',webPreferences:{sandbox:true,nodeIntegration:false,contextIsolation:true,webSecurity:true}});
  await printWindow.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(page.html));
  // This creates one Windows print-spooler job for the selected printer; do not fan out to every connected printer.
  const options={silent:true,deviceName:printer.name,printBackground:false,
    margins:{marginType:'none'},landscape:false,
    pageSize:{width:printer.width*1000,height:page.heightMm*1000}};
  const result=await new Promise(resolve=>{
    try{printWindow.webContents.print(options,(ok,reason)=>resolve({ok,reason}));}
    catch(e){resolve({ok:false,reason:e.message});}
  });
  if(!result.ok)return {ok:false,message:`${printer.displayName}: ${result.reason||'Windows print queue rejected job'}. Verify printer driver and configured paper width; job was not automatically retried.`};
  let saved=true;try{cfg.last=printer.name;writeConfig(app,cfg)}catch{saved=false;}
  return {ok:true,printer:printer.displayName,width:printer.width,message:`Queued once: ${printer.displayName} (${printer.width}mm). Verify paper output; Windows queue acceptance does not confirm physical printing.${saved?'':' Last-printer preference could not be saved.'}`};
 }catch(e){return {ok:false,message:`Print error: ${e.message}`};}
 finally{if(printWindow&&!printWindow.isDestroyed())printWindow.close();busy=false;}
}
module.exports={status,setWidth,printPage};
