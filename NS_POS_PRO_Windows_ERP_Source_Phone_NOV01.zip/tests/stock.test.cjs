const test=require('node:test');const assert=require('node:assert/strict');const f=require('../app/ns_stock_flow.js');
const item=[{id:'p',name:'Rice',stock:100}];let ledger=[{repId:'r1',productId:'p',kind:'load',qty:20}];
test('empty inventory remains at zero',()=>assert.equal(f.allDelivery([],[],'p'),0));
test('wholesale transfer reserves without a sale',()=>{assert.equal(f.wholesaleAvailable(item,ledger,[],'p'),80);assert.equal(f.deliveryBalance(ledger,[],'r1','p'),20)});
test('delivery sale reduces only delivery balance, not wholesale available',()=>{let inv=[{mode:'stock',vehicleRepId:'r1',lines:[{productId:'p',qty:5}]}];let updated=[{...item[0],stock:95}];assert.equal(f.deliveryBalance(ledger,inv,'r1','p'),15);assert.equal(f.wholesaleAvailable(updated,ledger,inv,'p'),80)});
test('delivery return restores wholesale available',()=>{let l=[...ledger,{repId:'r1',productId:'p',kind:'unload',qty:3}];assert.equal(f.deliveryBalance(l,[],'r1','p'),17);assert.equal(f.wholesaleAvailable(item,l,[],'p'),83)});
test('multiple rep allocations sum correctly',()=>{let l=[...ledger,{repId:'r2',productId:'p',kind:'load',qty:10}];assert.equal(f.allDelivery(l,[],'p'),30);assert.equal(f.wholesaleAvailable(item,l,[],'p'),70)});
test('cannot over-allocate or return more than available',()=>{assert.equal(f.canTransfer(item,ledger,[],'r1','p','load',81),false);assert.equal(f.canTransfer(item,ledger,[],'r1','p','load',80),true);assert.equal(f.canTransfer(item,ledger,[],'r1','p','unload',21),false)});
test('invalid quantities rejected',()=>{for(const q of [-3,0,'bad',Infinity])assert.equal(f.canTransfer(item,ledger,[],'r1','p','load',q),false)});
