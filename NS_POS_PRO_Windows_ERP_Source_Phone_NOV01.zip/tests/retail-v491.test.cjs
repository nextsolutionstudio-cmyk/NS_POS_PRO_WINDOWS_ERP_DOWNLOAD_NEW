const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const read=f=>fs.readFileSync(path.join(__dirname,'..','app',f),'utf8');
test('retail dashboard has genuine dynamic metrics and feature routes',()=>{
 const js=read('desktop.js');
 for(const key of ['nsdeskSales','nsdeskBills','nsdeskCustomers','nsdeskLow','nsdeskCredit','nsdeskProducts','nsdeskWeeklyChart','nsdeskTopItems','nsdeskRecent','nsdeskAlerts','Quick Access','GRN & Purchases','allowed(item)','window.navigate'])assert.ok(js.includes(key),'missing '+key);
 assert.ok(js.includes('invoices.filter')&&js.includes('invoices.forEach'),'metrics must come from invoices');
});
test('versioned deep blue stylesheet is loaded and ERP files preserved',()=>{
 const html=read('index.html');const css=read('ns_windows_premium_v491.css');
 assert.ok(html.includes('ns_windows_premium_v491.css'));
 for(const k of ['kpi-green','kpi-orange','.nsdesk-v491-chart','.nsdesk-v491-columns','.nsdesk-tiles'])assert.ok(css.includes(k));
 for(const k of ['id="invoice"','id="grn"','id="products"','id="history"'])assert.ok(html.includes(k));
});
