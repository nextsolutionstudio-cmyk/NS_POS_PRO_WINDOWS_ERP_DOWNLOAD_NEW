'use strict';
const {test} = require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const read=p=>fs.readFileSync(path.join(__dirname,'..','app',p),'utf8');
test('desktop v4.9 has grouped role-aware navigation and live local summaries',()=>{
 const js=read('desktop.js');const css=read('ns_windows_premium_v49.css');
 for(const s of ['HR & Employees','Salary & EPF / ETF','New Bill','GRN & Purchases','Ctrl K','nsdeskLow','getRole','allowed(item)']){
  assert.ok(js.includes(s),`Missing ${s}`);
 }
 assert.ok(css.includes('.nsdesk-tiles'));
 assert.ok(css.includes('body.ns-win-desktop.nsdesk-v49>header.nsdesk-top'));
});
test('desktop HTML includes versioned CSS and UI JS',()=>{
 const html=read('index.html');
 assert.ok(html.includes('ns_windows_premium_v49.css'));
 assert.ok(html.includes('desktop.js'));
 assert.ok(!html.includes('sample data'));
});
