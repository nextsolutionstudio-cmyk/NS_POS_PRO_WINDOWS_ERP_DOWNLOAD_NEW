'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {modelOf,choosePrinter,describePrinter,pageHeightMm}=require('../desktop/printer-policy.cjs');
const {createPage}=require('../desktop/receipt-renderer.cjs');
test('recognizes all three models including 58mm P502A',()=>{
 assert.equal(modelOf('XP-P301A').width,80);assert.equal(modelOf('XP-P502A').width,58);
 assert.equal(modelOf('XP-80T').width,80);
});
test('P301A supports one-time 58mm paper profile',()=>{
 assert.equal(describePrinter({name:'XP-P301A'},{'XP-P301A':58}).width,58);
 assert.equal(describePrinter({name:'XP-P502A'},{'XP-P502A':80}).width,58);
});
test('auto chooses last successful printer, skips Windows PDF',()=>{
 const r=choosePrinter([{name:'Microsoft Print to PDF'},{name:'XP-P301A'},{name:'XP-P502A'}],{},'XP-P502A');
 assert.equal(r.selected.name,'XP-P502A');assert.equal(r.printers.length,2);
});
test('when last successful printer is reported offline switch to available',()=>{
 const r=choosePrinter([{name:'XP-P502A'},{name:'XP-80T'}],{},'XP-P502A',[{Name:'XP-P502A',WorkOffline:true},{Name:'XP-80T',Default:true}]);
 assert.equal(r.selected.name,'XP-80T');
});
test('no fallback to PDF or unknown printer',()=>{
 assert.equal(choosePrinter([{name:'Microsoft Print to PDF'}]).selected,null);
});
test('receipt uses exact selected paper width, escapes printer text and valid invoice values',()=>{
 const d=createPage({business:{name:'A <B>'},number:'INV-1',lines:[{name:'Milk',qty:2,rate:12}],total:24},58);
 assert.match(d.html,/size:58mm/);assert.match(d.html,/A &lt;B&gt;/);assert.match(d.html,/24\.00/);
 assert.doesNotMatch(d.html,/size:80mm/);
});
test('test print and receipt page sizes consistent',()=>{
 const testPage=createPage({test:true},80);const bill=createPage({number:'INV-1',lines:[]},80);
 assert.match(testPage.html,/size:80mm/);assert.match(bill.html,/size:80mm/);
});
