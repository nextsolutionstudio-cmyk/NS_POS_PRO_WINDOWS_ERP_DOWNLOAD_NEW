const test=require('node:test');
const assert=require('node:assert/strict');
const {active}=require('../desktop/license-policy.cjs');
const now=Date.parse('2026-10-30T00:00:00Z');
test('active unexpired trial is allowed',()=>assert.equal(active({status:'active',expires_at:'2026-11-06T00:00:00Z'},now),true));
test('blocked business fails closed',()=>assert.equal(active({status:'blocked',expires_at:'2026-11-06T00:00:00Z'},now),false));
test('expired or invalid expiry fails closed',()=>{assert.equal(active({status:'active',expires_at:'2026-10-29T00:00:00Z'},now),false);assert.equal(active({status:'active',expires_at:'invalid'},now),false);assert.equal(active(null,now),false)});
test('desktop has native independent license verification and owner trial endpoints',()=>{
 const fs=require('node:fs'),path=require('node:path');const root=path.resolve(__dirname,'..');
 const main=fs.readFileSync(path.join(root,'desktop/main.cjs'),'utf8');const worker=fs.readFileSync(path.join(root,'Cloudflare_Server/src/worker.js'),'utf8');
 assert.match(main,/setInterval\(verify,CHECK_EVERY_MS\)/);assert.match(main,/lock\('Could not verify your subscription online/);
 assert.match(main,/sandbox:true/);assert.match(main,/contextIsolation:true/);
 assert.match(worker,/\/v1\/owner\/start-trial/);assert.match(worker,/\/v1\/owner\/set-expiry/);
});
