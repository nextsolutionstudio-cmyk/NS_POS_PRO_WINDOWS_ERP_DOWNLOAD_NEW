'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const {createPage}=require('../desktop/receipt-renderer.cjs');
const invoice={business:{name:'Nipun',address:'Katagamuwa',phone:'0711111111',phone2:'0711111111',email:'abc@shop.lk',website:'https://myshop.lk',logo:'data:image/png;base64,'+'a'.repeat(160)},number:'INV-1',date:'2026-10-31',lines:[{name:'Milk',qty:1,rate:350}],total:350,balance:0};
test('58mm fixed page width, centered narrower logo and www only',()=>{
 const p=createPage(invoice,58);assert.match(p.html,/@page\{size:58mm/);assert.match(p.html,/max-width:28mm/);assert.match(p.html,/www\.myshop\.lk/);assert.doesNotMatch(p.html,/https:\/\//);assert.equal((p.html.match(/0711111111/g)||[]).length,1);
});
test('80mm uses 80mm page & different logo max width',()=>{
 const p=createPage(invoice,80);assert.match(p.html,/@page\{size:80mm/);assert.match(p.html,/max-width:43mm/);
});
test('test print is a separate page and does not include invoice/customer logo',()=>{
 const p=createPage({test:true},58);assert.match(p.html,/PRINTER TEST/);assert.doesNotMatch(p.html,/INV-1/);assert.doesNotMatch(p.html,/Company logo/);
});
