/* NS POS PRO v2.3 LIFETIME — PWA offline caching, NO subscription gate */
const CACHE='ns-pos-pro-remote-owner-v21-windows';
const PREFIXES=['ns-mobile-pos-pwa-', 'ns-pos-pro-'];
const ASSETS=['./','./index.html','./vehicle_credit_v38.js','./upgrade.js','./ns_owner_branding_readonly.js','./ns_erp_hr_accounts_profit_v44.js','./ns_erp_cloud_v45.js','./ns_owner_remote_control_v2_1.js','./remote_branding_sync.js','./v35_fixes.js','./v36_layout.js','./enhancements_v33.js','./admin_brand_v34.js','./windows_extras_v34.js','./invoice_share_v34.js','./colourful_v34.css','./ns_logo_test.js','./receipt_refine.js','./location_sync.js','./dashboard_pro.css','./ns-test-logo.png','./print_actions.js','./receipt_jpg.js','./receipt_logo.js','./manifest.webmanifest','./icon-192.png','./icon-512.png','./apple-touch-icon.png'];
self.addEventListener('install', event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE && PREFIXES.some(p=>k.startsWith(p))).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', event=>{
  const req=event.request;
  if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
  const isPage=req.mode==='navigate'||new URL(req.url).pathname.endsWith('/index.html');
  if(isPage){
    event.respondWith(fetch(req).then(resp=>{
      if(resp.ok){const clone=resp.clone();caches.open(CACHE).then(c=>c.put(req,clone));}
      return resp;
    }).catch(()=>caches.open(CACHE).then(c=>c.match(req)||c.match('./index.html'))));
  }else{
    event.respondWith(caches.open(CACHE).then(c=>c.match(req).then(hit=>hit||fetch(req).then(resp=>{
      if(resp.ok)c.put(req,resp.clone());return resp;
    }))));
  }
});
