/* NS POS PRO: subscription-authenticated metadata + preinstalled feature toggles. */
(()=>{'use strict';
const el=id=>document.getElementById(id), currentVersion='3.9.1';
const flagTargets={vehicle_stock:['[onclick="navigate(\'vehicle\')"]','[data-page="vehicle"]'],credit_collection:['[onclick="navigate(\'credit\')"]','[data-page="credit"]'],extra_reports:[],three_printers:['#ns3PrinterPanel']};
let policy=null;
function compare(a,b){let x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<Math.max(x.length,y.length);i++){if((x[i]||0)!==(y[i]||0))return (x[i]||0)>(y[i]||0)?1:-1}return 0}
function status(v){const e=el('nsUpStatus');if(e)e.textContent=v}
function applyFlags(flags){
 // Only existing feature UI can be toggled. Defaults preserve old behavior.
 if(!flags||!Object.keys(flags).length)return;
 // Never change permissions: only supplement the local menu visibility.
 for(const [feature,selectors] of Object.entries(flagTargets)){
   if(typeof flags[feature]!=='boolean')continue;
   if(feature==='three_printers'){const p=el('ns3PrinterPanel');if(p)p.hidden=!flags[feature];continue}
   selectors.forEach(s=>{try{document.querySelectorAll(s).forEach(e=>{e.hidden=!flags[feature]})}catch(_){}});
 }
}
async function check(){
 if(!navigator.onLine){status('Offline: current installed version continues to work');return}
 if(!window.NSCloud?.repCall){status('Cloud login required');return}
 try{
  const response=await window.NSCloud.repCall('/v1/app/update-policy');policy=response.policy||{};
  applyFlags(policy.flags||{});
  const hasUpdate=policy.version && compare(policy.version,currentVersion)>0 && /^https:\/\/[^\s]+$/.test(policy.url||'');
  status(hasUpdate?'New APK available: v'+policy.version+' — '+(policy.notes||'Read the release notes'):'Up to date (v'+currentVersion+')');
  el('nsUpDownload').hidden=!hasUpdate;
 }catch(e){status('Update check unavailable: '+e.message)}
}
function showLink(){
 if(!policy?.url)return;
 // Android controls installation; never auto-download or silently install APKs.
 if(!confirm('Download v'+policy.version+' in a browser? You must confirm the Android installation yourself.'))return;
 const link=policy.url;
 if(window.AndroidPrinter?.openSharedLink){window.AndroidPrinter.openSharedLink(link)}
 else {window.prompt('Copy this HTTPS download link and open it in Chrome:',link)}
}
function install(){const target=el('settings');if(!target)return;
 const section=document.createElement('div');section.className='panel';section.innerHTML='<h2>☁ Software Updates</h2><p class="hint">Customer data is kept on this device. No silent APK installation.</p><p id="nsUpStatus">Version '+currentVersion+' · Check for updates</p><button type="button" id="nsUpCheck" class="secondary">↻ Check for Updates</button> <button type="button" id="nsUpDownload" class="primary" hidden>Download APK in Browser</button><label style="display:block;margin:13px 0"><input type="checkbox" id="nsUpAuto"> Automatically check when online</label>';
 target.append(section);
 const checkbox=el('nsUpAuto');checkbox.checked=localStorage.getItem('ns_auto_update_check')!=='off';
 checkbox.onchange=()=>localStorage.setItem('ns_auto_update_check',checkbox.checked?'on':'off');
 el('nsUpCheck').onclick=check;el('nsUpDownload').onclick=showLink;
 window.addEventListener('online',()=>{if(checkbox.checked)setTimeout(check,2000)});
 setTimeout(()=>{if(checkbox.checked&&navigator.onLine)check()},10000);
 setInterval(()=>{if(checkbox.checked&&navigator.onLine&&document.visibilityState==='visible')check()},30*60*1000);
}
install();
window.NSUpdates={check};
})();
