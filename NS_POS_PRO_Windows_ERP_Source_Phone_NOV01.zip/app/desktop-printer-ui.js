/* Windows v4.7: one automatic printer choice, a single receipt layout path for test and real bills. */
(()=>{'use strict';
if(!window.NSDesktopPrinter?.getStatus)return;
const $=id=>document.getElementById(id);
const settings=$('settings');if(!settings)return;
const previewHeader=document.querySelector('#previewModal .modal .row h2');if(previewHeader)previewHeader.textContent='Automatic Receipt Preview · 58/80mm';
const panel=document.createElement('div');panel.className='panel ns-printer-manager';
panel.innerHTML=`<h2>🖨 Auto Printer Manager · Windows</h2>
 <p class="hint">XP-P301A · XP-P502A · XP-80T · USB / Bluetooth / Windows print drivers. No printer selection needed while billing.</p>
 <div class="ns-printer-summary" id="nsPrinterSummary">Checking installed Windows printers…</div>
 <div id="nsPrinterCards" class="ns-printer-cards"></div>
 <div class="actions"><button type="button" class="primary" id="nsPrinterRefresh">↻ Check Connections</button><button type="button" class="secondary" id="nsPrinterTest">🧾 Test Print (auto)</button></div>
 <p class="hint" id="nsPrinterNotice" role="status">Bluetooth printers must be paired and installed as Windows printer queues, not only as COM devices. Driver status may not confirm that paper is loaded.</p>`;
settings.prepend(panel);
const root=$('nsPrinterCards'),summary=$('nsPrinterSummary'),notice=$('nsPrinterNotice');
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const status=msg=>{notice.textContent=String(msg||'');};
async function reload(){
 try{
  const r=await window.NSDesktopPrinter.getStatus();
  if(!r.ok)throw Error(r.error||'Cloud trial login required');
  const chosen=r.selected;
  summary.innerHTML=chosen?`<strong>Auto-selected: ${escape(chosen.displayName)}</strong><br>${chosen.model} • ${chosen.width}mm • ${escape(chosen.availability)}`:
    '<strong>No supported Windows printer queue found.</strong><br>Install and configure the Xprinter Windows driver first.';
  root.replaceChildren();
  for(const p of r.printers){
   const c=document.createElement('div');c.className='ns-printer-card';
   c.innerHTML=`<div><strong>🖨 ${escape(p.displayName)}</strong><small>${escape(p.model)} · ${escape(p.availability)}${p.name===chosen?.name?' · AUTO SELECTED':''}</small></div><div class="ns-printer-width">${p.width}mm</div>`;
   if(p.adjustable){
    const dropdown=document.createElement('select');dropdown.setAttribute('aria-label',`Paper size for ${p.displayName}`);
    for(const width of [58,80]){const opt=document.createElement('option');opt.value=width;opt.textContent=`${width}mm roll`;dropdown.appendChild(opt);}
    dropdown.value=String(p.width);dropdown.addEventListener('change',async()=>{
      const answer=await window.NSDesktopPrinter.setWidth(p.name,Number(dropdown.value));
      status(answer.ok?'Paper width profile saved for '+p.displayName:(answer.error||'Could not save profile'));
      reload();
    });
    const hint=document.createElement('div');hint.className='hint';hint.textContent='Set paper roll width once (XP-P301A supports both).';
    c.appendChild(dropdown);c.appendChild(hint);
   }
   root.appendChild(c);
  }
  if(!r.printers.length)root.textContent='No supported thermal printers currently installed as Windows printer queues.';
 }catch(err){summary.textContent=err.message||'Printer status unavailable';}
}
$('nsPrinterRefresh').onclick=reload;
$('nsPrinterTest').onclick=async()=>{
 const button=$('nsPrinterTest');button.disabled=true;status('Sending ONE diagnostic receipt to auto-selected printer…');
 try{const r=await window.NSDesktop.testPrint();status(r.message||r.error||'Printer test did not finish');await reload();status(r.message||r.error||'Printer test did not finish');}
 catch(e){status(e.message||'Printer test failed');}
 finally{button.disabled=false;}
};
reload();
})();
