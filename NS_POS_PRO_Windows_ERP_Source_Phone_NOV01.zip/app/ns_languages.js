/* NS POS PRO - UI language selector. Translates common static UI labels without changing stored data. */
(()=>{
 'use strict';
 const STORE='nspos_ui_lang';
 const labels={

 'New Bill':['නව බිල්පත','புதிய ரசீது'],
 'Bill & Print':['බිල්පත සහ මුද්‍රණය','ரசீது மற்றும் அச்சிடுதல்'],
 'Orders':['ඇණවුම්','ஆர்டர்கள்'],
 'Take & Share':['ඇණවුම් ලබාගෙන බෙදාගන්න','ஆர்டர்கள் எடுத்து பகிரவும்'],
 'Shops Map':['වෙළෙඳසැල් සිතියම','கடைகள் வரைபடம்'],
 'Find delivery':['බෙදාහැරීම් සොයන්න','விநியோகத்தைக் கண்டறி'],
 'GRN / Stock':['භාණ්ඩ ලැබීම් / තොග','பொருள் வரவு / இருப்பு'],
 'Add goods':['භාණ්ඩ එක් කරන්න','பொருட்களைச் சேர்'],
 'Products':['භාණ්ඩ','பொருட்கள்'],
 'Prices & Items':['භාණ්ඩ සහ මිල ගණන්','பொருட்கள் மற்றும் விலைகள்'],
 'Invoices':['බිල්පත්','ரசீதுகள்'],
 'History / JPG':['ඉතිහාසය / JPG','வரலாறு / JPG'],
 'Returns':['ආපසු භාරගැනීම්','திருப்பி அளித்தல்'],
 'Credit notes':['ණය සටහන්','கடன் குறிப்புகள்'],
 'Cheques':['චෙක්පත්','காசோலைகள்'],
 'Track payments':['ගෙවීම් නිරීක්ෂණය','கட்டணங்களைக் கண்காணி'],
 'Rep Accounts':['අලෙවි නියෝජිත ගිණුම්','விற்பனை பிரதிநிதி கணக்குகள்'],
 'Users & PINs':['පරිශීලකයින් සහ PIN','பயனர்கள் மற்றும் PIN'],
 'Settings':['සැකසුම්','அமைப்புகள்'],
 'Brand & Printer':['වෙළෙඳ නාමය සහ මුද්‍රණය','பிராண்ட் மற்றும் அச்சுப்பொறி'],
 'Wholesale Stock':['තොග අලෙවි තොගය','மொத்த விற்பனை இருப்பு'],
 'Delivery Stock':['බෙදාහැරීමේ තොගය','விநியோக இருப்பு'],
 'Rep inventory':['නියෝජිත තොග','பிரதிநிதி இருப்பு'],
 'Customer Credit':['පාරිභෝගික ණය','வாடிக்கையாளர் கடன்'],
 'Payments due':['අය විය යුතු මුදල්','பெற வேண்டிய தொகைகள்'],
 'Rep Closing':['නියෝජිත දෛනික පියවීම','பிரதிநிதி நாள் முடிவு'],
 'Daily summary':['දෛනික සාරාංශය','தினசரி சுருக்கம்'],
 'Retail · Wholesale · Distribution':['සිල්ලර · තොග · බෙදාහැරීම','சில்லறை · மொத்தம் · விநியோகம்'],
 'Customer Shops':['පාරිභෝගික වෙළෙඳසැල්','வாடிக்கையாளர் கடைகள்'],
 'Credit Collection':['ණය මුදල් අයකිරීම','கடன் வசூல்'],
 'Stock / Products':['තොග / භාණ්ඩ','இருப்பு / பொருட்கள்'],
 'Purchase / GRN':['මිලදී ගැනීම් / GRN','கொள்முதல் / GRN'],
 'Stock / Price Unit':['තොග / මිල ඒකකය','இருப்பு / விலை அலகு'],
 'Log out':['ඉවත් වන්න','வெளியேறு'],
 'Your smart business hub':['ඔබේ ව්‍යාපාර කළමනාකරණය','உங்கள் வணிக மேலாண்மை'],
 'Today at a glance':['අද සාරාංශය','இன்றைய சுருக்கம்'],
 'What would you like to do?':['ඔබට අවශ්‍ය කාර්යය','நீங்கள் செய்ய விரும்புவது'],
 '📊 Last 7 Days Sales':['📊 දින 7ක විකුණුම්','📊 கடந்த 7 நாள் விற்பனை'],
 '🧾 Latest Sales':['🧾 නවතම විකුණුම්','🧾 சமீபத்திய விற்பனை'],
 '⚠️ Stock Alerts':['⚠️ තොග අනතුරු ඇඟවීම්','⚠️ இருப்பு எச்சரிக்கைகள்'],
 'Product details & selling prices':['භාණ්ඩ විස්තර හා මිල','பொருள் விவரங்கள் மற்றும் விலை'],
 'Product list':['භාණ්ඩ ලැයිස්තුව','பொருட்கள் பட்டியல்'],
 'Goods Received Note (GRN)':['භාණ්ඩ ලැබීම් (GRN)','பொருள் வரவு (GRN)'],
 'Recent GRNs':['මෑත භාණ්ඩ ලැබීම්','சமீபத்திய பொருள் வரவுகள்'],
 'New 80mm Invoice':['නව බිල්පත (80mm)','புதிய ரசீது (80mm)'],
 'Saved bills':['සුරැකි බිල්පත්','சேமிக்கப்பட்ட ரசீதுகள்'],
 'Business Details':['ව්‍යාපාර විස්තර','வணிக விவரங்கள்'],
 'Android APK Bluetooth 80mm printer':['Android Bluetooth 80mm මුද්‍රණ යන්ත්‍රය','Android Bluetooth 80mm அச்சுப்பொறி'],
 'Data safety & transfer':['දත්ත ආරක්ෂාව හා හුවමාරුව','தரவு பாதுகாப்பு மற்றும் பரிமாற்றம்'],
 '80mm Receipt Preview':['80mm රිසිට්පත් පෙරදසුන','80mm ரசீது முன்னோட்டம்'],
 'Product name *':['භාණ්ඩ නාමය *','பொருளின் பெயர் *'],
 'SKU / barcode':['SKU / බාර්කෝඩ්','SKU / பார்கோடு'],
 'Purchase cost (Rs.)':['මිලදී ගැනීමේ මිල (රු.)','கொள்முதல் விலை (ரூ.)'],
 'Selling price (Rs.)':['විකුණුම් මිල (රු.)','விற்பனை விலை (ரூ.)'],
 'Low stock alert at':['අඩු තොග දැනුම්දීම','குறைந்த இருப்பு எச்சரிக்கை'],
 'Product photo (optional)':['භාණ්ඩ ඡායාරූපය (විකල්ප)','பொருள் புகைப்படம் (விருப்பம்)'],
 'Supplier':['සැපයුම්කරු','வழங்குநர்'],
 'Reference number':['යොමු අංකය','குறிப்பு எண்'],
 'Product':['භාණ්ඩය','பொருள்'],
 'Quantity':['ප්‍රමාණය','அளவு'],
 'Unit cost (Rs.)':['ඒකක මිල (රු.)','அலகு விலை (ரூ.)'],
 'Customer / shop name':['පාරිභෝගික / කඩේ නම','வாடிக்கையாளர் / கடை பெயர்'],
 'Phone (optional)':['දුරකථන (විකල්ප)','தொலைபேசி (விருப்பம்)'],
 'Bill mode':['බිල් වර්ගය','ரசீது வகை'],
 'Payment':['ගෙවීම් ක්‍රමය','கட்டண முறை'],
 'Item':['භාණ්ඩය','பொருள்'],
 'Qty':['ප්‍රමාණය','அளவு'],
 'Manual item name':['අතින් ඇතුළත් භාණ්ඩය','கையால் சேர்க்கும் பொருள்'],
 'Rate (Rs.)':['මිල (රු.)','விலை (ரூ.)'],
 'Discount (Rs.)':['වට්ටම (රු.)','தள்ளுபடி (ரூ.)'],
 'Paid / advance (Rs.)':['ගෙවූ / අත්තිකාරම් (රු.)','செலுத்திய / முன்பணம் (ரூ.)'],
 'Payment Note (optional)':['ගෙවීම් සටහන (අවශ්‍ය නම්)','கட்டணக் குறிப்பு (விருப்பம்)'],
 'Bill note':['බිල්පත් සටහන','ரசீது குறிப்பு'],
 'Business name *':['ව්‍යාපාරයේ නම *','வணிகப் பெயர் *'],
 'Phone number':['දුරකථන අංකය','தொலைபேசி எண்'],
 'Address':['ලිපිනය','முகவரி'],
 'Business Email (optional)':['ව්‍යාපාර Email (විකල්ප)','வணிக மின்னஞ்சல் (விருப்பம்)'],
 'Website (optional)':['වෙබ් අඩවිය (විකල්ප)','இணையதளம் (விருப்பம்)'],
 'Business logo (optional on printed bill)':['ව්‍යාපාර ලාංඡනය (විකල්ප)','வணிக லோகோ (விருப்பம்)'],
 'Receipt footer text':['රිසිට්පත අවසාන පාඨය','ரசீது இறுதிக் குறிப்பு'],
 '📋 History':['📋 බිල් ඉතිහාසය','📋 ரசீது வரலாறு'],
 '🏠 Dashboard':['🏠 මුල් පිටුව','🏠 முகப்பு'],
 '🧾 Bill':['🧾 බිල්පත','🧾 ரசீது'],
 '📦 Products':['📦 භාණ්ඩ','📦 பொருட்கள்'],
 '📥 GRN':['📥 GRN','📥 GRN'],
 '⚙ Settings':['⚙ සැකසුම්','⚙ அமைப்புகள்'],
 'Save Product':['භාණ්ඩය සුරකින්න','பொருளைச் சேமி'],
 'Clear':['හිස් කරන්න','அழி'],
 '+ Add to GRN':['+ GRN වෙත එකතු කරන්න','+ GRN இல் சேர்'],
 'Save GRN & Increase Stock':['GRN සුරකින්න / තොග වැඩි කරන්න','GRN சேமித்து இருப்பை அதிகரி'],
 '+ Add Item':['+ භාණ්ඩයක් එකතු කරන්න','+ பொருளைச் சேர்'],
 '+ Add Manual Item':['+ භාණ්ඩය අතින් එක් කරන්න','+ பொருளை கைமுறையாக சேர்'],
 '✓ Save Bill':['✓ බිල්පත සුරකින්න','✓ ரசீதைச் சேமி'],
 'Preview':['පෙරදසුන','முன்னோட்டம்'],
 'New/Clear':['නව / හිස් කරන්න','புதிய / அழி'],
 'Save Business Details':['ව්‍යාපාර විස්තර සුරකින්න','வணிக விவரங்களைச் சேமி'],
 'Find Paired Printers':['සම්බන්ධ මුද්‍රණ යන්ත්‍ර සොයන්න','இணைத்த அச்சுப்பொறிகளைத் தேடு'],
 'Test Print':['මුද්‍රණය පරීක්ෂා කරන්න','அச்சிடுதல் சோதனை'],
 '⬇ Backup JSON':['⬇ දත්ත උපස්ථය','⬇ தரவு காப்பு'],
 '⬆ Restore JSON':['⬆ දත්ත නැවත ලබාගන්න','⬆ தரவை மீட்டெடு'],
 '⌂ Home':['⌂ මුල් පිටුව','⌂ முகப்பு'],
 '▤ New Bill':['▤ නව බිල්පත','▤ புதிய ரசீது'],
 '🛒 Orders':['🛒 ඇණවුම්','🛒 ஆர்டர்கள்'],
 '📍 Shops':['📍 වෙළෙඳසල්','📍 கடைகள்'],
 '▤ Bills':['▤ බිල්පත්','▤ ரசீதுகள்'],
 'Business Login':['ව්‍යාපාර පිවිසුම','வணிக உள்நுழைவு'],
 'Username':['පරිශීලක නාමය','பயனர் பெயர்'],
 'Password':['මුරපදය','கடவுச்சொல்'],
 '↪ Sign In to POS':['↪ POS වෙත පිවිසෙන්න','↪ POS இல் உள்நுழைய'],
 '💳 Subscription & Renewal':['💳 දායකත්වය සහ අලුත් කිරීම','💳 சந்தா மற்றும் புதுப்பித்தல்'],
 '📷 Send Payment Slip via WhatsApp':['📷 WhatsApp හරහා ගෙවීම් ස්ලිප් යවන්න','📷 WhatsApp மூலம் கட்டண ரசீதை அனுப்பவும்'],
 '💬 Open WhatsApp & Send Slip':['💬 WhatsApp විවෘත කර ස්ලිප් යවන්න','💬 WhatsApp திறந்து ரசீதை அனுப்பவும்'],
 '✕ Back to App':['✕ App වෙත ආපසු','✕ செயலிக்குத் திரும்பு'],
 'Admin setup':['Admin සකසන්න','நிர்வாகி அமைப்பு'],
 'Sign in to NS POS':['NS POS වෙත පිවිසෙන්න','NS POS இல் உள்நுழைய'],
 'PIN':['PIN අංකය','PIN எண்'],
 'Continue':['ඉදිරියට','தொடரவும்'],
 'Cash':['මුදල්','பணம்'],
 'Credit':['ණය','கடன்'],
 'Bank Transfer':['බැංකු මාරු','வங்கி பரிமாற்றம்'],
 'Card':['කාඩ්පත්','அட்டை'],
 'Cheque':['චෙක්පත්','காசோலை'],
 'View Subscription / Bank Transfer':['දායකත්වය සහ ගෙවීම්','சந்தா மற்றும் கட்டணம்'],
 '☁ Sync':['☁ සමමුහුර්ත කරන්න','☁ ஒத்திசைவு'],
 '📊 Reports':['📊 වාර්තා','📊 அறிக்கைகள்'],
 '👥 Admin / Rep PIN':['👥 Admin / Rep PIN','👥 நிர்வாகி / பிரதிநிதி PIN'],
 '↪ Cloud Log out':['↪ Cloud වෙතින් ඉවත්වන්න','↪ Cloud வெளியேறு'],
 'Admin / Rep Login':['Admin / Rep පිවිසුම','நிர்வாகி / பிரதிநிதி உள்நுழைவு'],
 'Offline Billing':['Offline බිල්පත්','ஆஃப்லைன் பில்லிங்'],
 };
 const PHS={
 'Type full product name (e.g. Rice 1 kg)':['සම්පූර්ණ භාණ්ඩ නාමය ඇතුළත් කරන්න (උදා: සහල් 1 kg)','முழு பொருள் பெயரை உள்ளிடவும் (எ.கா. அரிசி 1 kg)'],
 'Enter Username':['පරිශීලක නාමය ඇතුළත් කරන්න','பயனர் பெயரை உள்ளிடவும்'],
 'Enter Password':['මුරපදය ඇතුළත් කරන්න','கடவுச்சொல்லை உள்ளிடவும்'],
 'Cash / Card reference / Online transfer / Credit terms (optional)':['මුදල් / කාඩ් අංකය / බැංකු ගනුදෙනු අංකය / ණය කොන්දේසි (විකල්ප)','பணம் / அட்டை குறிப்பு / வங்கி பரிமாற்ற எண் / கடன் விவரம் (விருப்பம்)'],
 '4+ digits':['අංක 4ක් හෝ වැඩි','4 அல்லது கூடுதல் இலக்கங்கள்'],
 };
 let lang=localStorage.getItem(STORE)||'en';if(!['en','si','ta'].includes(lang))lang='en';
 const originals=new WeakMap(),originalPH=new WeakMap();let scheduled=false;
 function apply(){
  const selectors='header, .tabs, #dashboard, #invoice, #products, #grn, #history, #settings, #cloudGate, #ns2Auth, #cloudTopMenu, #team, #shops';
  const roots=document.querySelectorAll(selectors);
  for(const root of roots){
   const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
   let node;while((node=walker.nextNode())){
    const par=node.parentElement;if(!par||/SCRIPT|STYLE|OPTION|TEXTAREA/.test(par.tagName))continue;
    if(par.closest('.invoice-paper,.developer-credit,.ns-developer-footer,#receiptPreview,#printZone,.ns2-entry'))continue;
    const raw=originals.get(node)??node.nodeValue;
    const key=raw.trim(),opts=labels[key];if(!opts)continue;
    if(!originals.has(node)) originals.set(node,raw);
    const translated=lang==='en'?key:opts[lang==='si'?0:1];
    const prefix=(raw.match(/^\s*/)||[''])[0],suffix=(raw.match(/\s*$/)||[''])[0];
    const next=prefix+translated+suffix;if(node.nodeValue!==next)node.nodeValue=next;
   }
  }
  for(const el of document.querySelectorAll('#invoice input[placeholder],#invoice textarea[placeholder],#products input[placeholder],#cloudGate input[placeholder],#ns2Auth input[placeholder]')){
   const original=originalPH.get(el)||el.getAttribute('placeholder')||'';if(!originalPH.has(el))originalPH.set(el,original);
   const opts=PHS[original];if(opts)el.setAttribute('placeholder',lang==='en'?original:opts[lang==='si'?0:1]);
  }
  // Keep payment values in English for the database/receipts; only translate option labels.
  for(const opt of document.querySelectorAll('#iPayment option')){
    if(!opt.dataset.nsBasePayment)opt.dataset.nsBasePayment=opt.value;
    const code=opt.dataset.nsBasePayment,trans=labels[code];
    opt.value=code;
    if(trans)opt.textContent=lang==='en'?code:trans[lang==='si'?0:1];
  }
  document.documentElement.lang=lang==='si'?'si':lang==='ta'?'ta':'en';
  const sel=document.getElementById('nsLangSelect');if(sel&&sel.value!==lang)sel.value=lang;
 }
 function schedule(){if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;apply()},100)}
 function init(){
  const target=document.querySelector('header')||document.body;
  const div=document.createElement('div');div.id='nsLangWidget';div.style='display:flex;align-items:center;gap:4px;padding:4px 7px;border-radius:12px;background:#ffffffea;color:#123a71;max-width:185px;white-space:nowrap';
  const lbl=document.createElement('label');lbl.style='font-size:12px;font-weight:800;color:#123a71';lbl.setAttribute('for','nsLangSelect');lbl.textContent='🌐';
  const sel=document.createElement('select');sel.id='nsLangSelect';sel.setAttribute('aria-label','Select language');sel.style='width:140px;max-width:100%;border:0;background:#fff;color:#123a71;font-size:13px;padding:6px 2px;border-radius:7px';
  sel.innerHTML='<option value="en">English</option><option value="si">සිංහල</option><option value="ta">தமிழ்</option>';
  sel.value=lang;sel.onchange=()=>{lang=sel.value;localStorage.setItem(STORE,lang);apply()};div.append(lbl,sel);
  target.append(div);apply();
  const observer=new MutationObserver(schedule);observer.observe(document.body,{childList:true,subtree:true});
  window.NSLang={get:()=>lang,set:v=>{if(['en','si','ta'].includes(v)){lang=v;localStorage.setItem(STORE,v);apply()}}};
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
