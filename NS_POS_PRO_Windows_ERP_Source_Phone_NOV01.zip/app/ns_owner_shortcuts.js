/* NS POS PRO — tenant-scoped cloud quick buttons, no remote executable code. */
(()=>{'use strict';
 const allowed={invoice:'🧾',history:'📋',shops:'📍',dashboard:'🏠'};
 const anchor=document.querySelector('.ns31-shortcuts');
 if(!anchor)return;
 const holder=document.createElement('section');holder.id='nsOwnerQuickButtons';holder.hidden=true;
 holder.style.cssText='margin:14px 0;';
 const heading=document.createElement('h3');heading.textContent='⚡ Business Quick Actions';
 holder.append(heading);
 const body=document.createElement('div');body.style.cssText='display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;';
 holder.append(body);anchor.insertAdjacentElement('afterend',holder);
 async function refresh(){
  if(!navigator.onLine || !window.NSCloud?.repCall)return;
  try{
   const data=await window.NSCloud.repCall('/v1/app/shortcuts');
   const actions=Array.isArray(data.shortcuts)?data.shortcuts:[];
   body.replaceChildren();
   actions.forEach(a=>{
    if(!Object.prototype.hasOwnProperty.call(allowed,a.target))return;
    const b=document.createElement('button');b.type='button';b.className='secondary';
    b.textContent=allowed[a.target]+' '+String(a.label||'').slice(0,40);
    b.style.cssText='width:100%;min-height:54px;padding:10px;border-radius:12px;white-space:normal;';
    b.onclick=()=>{if(typeof navigate==='function')navigate(a.target)};
    body.append(b);
   });
   holder.hidden=!body.childElementCount;
  }catch(_){ /* Never block normal billing when network or new API is unavailable. */ }
 }
 window.addEventListener('online',()=>setTimeout(refresh,3000));
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});
 setTimeout(refresh,15000);
 setInterval(()=>{if(document.visibilityState==='visible')refresh()},5*60*1000);
 window.NSQuickButtons={refresh};
})();
