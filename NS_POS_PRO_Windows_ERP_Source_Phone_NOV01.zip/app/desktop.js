/* NS POS PRO Windows Desktop v4.9 — responsive dashboard & navigation.
   Pure UI layer over the existing business functions; no storage schema migration.
   Backend authorization must remain enforced independently of this UI. */
(()=>{'use strict';
  if (!window.NSDesktop) return;
  const $ = id => document.getElementById(id);
  const catalog = [
    {id:'dashboard',page:'dashboard',group:'overview',icon:'🏠',title:'Dashboard',desc:'Business overview',roles:['admin','cashier','rep','hr']},
    {id:'invoice',page:'invoice',group:'sales',icon:'🧾',title:'New Bill',desc:'Touch-ready cashier billing',roles:['admin','cashier','rep']},
    {id:'orders',page:'orders',group:'sales',icon:'🛒',title:'Orders',desc:'Manage orders',roles:['admin','cashier','rep']},
    {id:'history',page:'history',group:'sales',icon:'📋',title:'Bill History',desc:'Find, view and reprint',roles:['admin','cashier','rep']},
    {id:'products',page:'products',group:'inventory',icon:'📦',title:'Products',desc:'Products, prices & alerts',roles:['admin']},
    {id:'grn',page:'grn',group:'inventory',icon:'📥',title:'GRN & Purchases',desc:'Receive goods',roles:['admin']},
    {id:'wholesale',page:'wholesale',group:'inventory',icon:'🏬',title:'Wholesale Stock',desc:'Bulk inventory',roles:['admin']},
    {id:'delivery',page:'delivery',group:'inventory',icon:'🚚',title:'Delivery Stock',desc:'Rep & delivery stock',roles:['admin','rep']},
    {id:'returns',page:'returns',group:'inventory',icon:'↩️',title:'Sales Returns',desc:'Return & exchange',roles:['admin']},
    {id:'shops',page:'shops',group:'distribution',icon:'📍',title:'Shops & Routes',desc:'Location & delivery',roles:['admin','rep']},
    {id:'cheques',page:'cheques',group:'finance',icon:'🏦',title:'Cheques',desc:'Cheque collections',roles:['admin']},
    {id:'accounts',page:'nsERP',tab:'accounts',group:'finance',icon:'💼',title:'Accounts & Cashbook',desc:'Business accounts',roles:['admin']},
    {id:'profit',page:'nsERP',tab:'profit',group:'finance',icon:'📊',title:'Profit & Reports',desc:'Sales & profitability',roles:['admin']},
    {id:'hr',page:'nsERP',tab:'hr',group:'people',icon:'👥',title:'HR & Employees',desc:'Employee records',roles:['admin','hr']},
    {id:'payroll',page:'nsERP',tab:'payroll',group:'people',icon:'💳',title:'Salary & EPF / ETF',desc:'Payroll management',roles:['admin','hr']},
    {id:'settings',page:'settings',group:'system',icon:'⚙️',title:'Business Settings',desc:'Branding & printers',roles:['admin']}
  ];
  const groups=[['overview','OVERVIEW'],['sales','SALES & CASHIER'],['inventory','STOCK & PURCHASES'],['distribution','DELIVERY'],['finance','ACCOUNTS & REPORTS'],['people','HUMAN RESOURCES'],['system','SYSTEM']];
  let authRole='';let active='dashboard';let filter='all';let searchOpen=false;
  const normalizeRole=r=>{const s=String(r||'').toLowerCase().trim();if(['administrator','owner','manager','developer','developer_owner'].includes(s))return 'admin';if(['sales_rep','sales-rep','salesrep'].includes(s))return 'rep';return s||'cashier';};
  const role=()=>normalizeRole(window.NSCloud?.getRole?.()||authRole);
  const allowed=item=>{
    if (!item.roles.includes(role())) return false;
    if (!$(item.page)) return false;
    if (window.NSOwnerRemote?.isAllowedPage && !window.NSOwnerRemote.isAllowedPage(item.page))return false;
    return true;
  };
  document.body.classList.add('ns-win-desktop','nsdesk-v49');
  const sidebar=document.createElement('aside');sidebar.className='nsdesk-sidebar';sidebar.setAttribute('aria-label','Main navigation');
  sidebar.innerHTML=`<div class="nsdesk-brand"><div class="nsdesk-logo"><img src="./icon-192.png" alt="NS POS PRO"/></div><div><strong>NS POS PRO</strong><small>WINDOWS ERP</small></div></div><div class="nsdesk-nav-scroll"><nav id="nsdeskNav" aria-label="Modules"></nav></div><div class="nsdesk-side-bottom"><div class="nsdesk-side-status"><span class="nsdesk-status-dot"></span><span id="nsdeskSideStatus">Business workspace</span></div><small>© Developed by Next Solution Studio</small></div>`;
  const top=document.createElement('header');top.className='nsdesk-top';
  top.innerHTML=`<div class="nsdesk-crumb"><span>NS ERP</span><span aria-hidden="true">/</span><strong id="nsdeskCurrent">Dashboard</strong></div><div class="nsdesk-search-wrap"><span class="nsdesk-search-icon">⌕</span><input id="nsdeskSearch" aria-label="Search modules" autocomplete="off" placeholder="Find a module, product or task..."/><kbd>Ctrl K</kbd><div id="nsdeskSearchResults" class="nsdesk-results" hidden></div></div><div class="nsdesk-head-actions"><div class="nsdesk-status"><span class="nsdesk-status-dot"></span><span id="nsdeskLicense">Checking subscription…</span></div><button type="button" id="nsdeskNewBill" class="nsdesk-top-bill">＋ New Bill</button><button type="button" id="nsdeskSignout" class="nsdesk-logout" title="Sign out">⇥</button></div>`;
  document.body.prepend(top);document.body.prepend(sidebar);
  const dashboard=$('dashboard');
  const home=document.createElement('div');home.className='nsdesk-home';
  home.innerHTML=`
  <section class="nsdesk-dashboard-v491" aria-label="NS ERP business dashboard">
    <div class="nsdesk-v491-heading"><div><small>LIVE ERP OVERVIEW</small><h1>Business Dashboard</h1><p>Retail · Supermarket · Wholesale</p></div><div class="nsdesk-v491-date" id="nsdeskToday">${new Date().toLocaleDateString('en-LK',{weekday:'short',day:'numeric',month:'short',year:'numeric'})}</div></div>
    <section class="nsdesk-kpis" aria-label="Today at a glance">
      <article class="nsdesk-kpi kpi-green"><span class="nsdesk-kpi-icon">▥</span><div><small>Today's Sales</small><strong id="nsdeskSales">Rs. 0.00</strong><em>From saved bills</em></div></article>
      <article class="nsdesk-kpi kpi-blue"><span class="nsdesk-kpi-icon">▤</span><div><small>Bills Today</small><strong id="nsdeskBills">0</strong><em>Saved today</em></div></article>
      <article class="nsdesk-kpi kpi-purple"><span class="nsdesk-kpi-icon">♟</span><div><small>Customers</small><strong id="nsdeskCustomers">0</strong><em>Local bill contacts</em></div></article>
      <article class="nsdesk-kpi kpi-orange"><span class="nsdesk-kpi-icon">⚠</span><div><small>Low Stock Alerts</small><strong id="nsdeskLow">0</strong><button data-open="products">View products →</button></div></article>
      <article class="nsdesk-kpi kpi-red"><span class="nsdesk-kpi-icon">▣</span><div><small>Credit Balance</small><strong id="nsdeskCredit">Rs. 0.00</strong><em>Saved unpaid balances</em></div></article>
      <article class="nsdesk-kpi kpi-cyan"><span class="nsdesk-kpi-icon">⬡</span><div><small>Products</small><strong id="nsdeskProducts">0</strong><em>Product records</em></div></article>
    </section>
    <section class="nsdesk-v491-toolbar"><div class="nsdesk-v491-toolbar-text">⚡ QUICK ACTIONS</div><div class="nsdesk-v491-action-list"><button data-open="invoice">✚ New Invoice</button><button data-open="products">⌕ Product Search</button><button data-open="history">▤ Saved Bills</button><button data-open="grn">▣ GRN / Purchase</button></div></section>
    <div class="nsdesk-v491-columns">
      <div class="nsdesk-v491-main">
        <section class="nsdesk-workspace nsdesk-v491-panel"><div class="nsdesk-v491-panelhead"><h2>▦ Quick Access</h2><span>Choose your module</span></div><div id="nsdeskFilters" class="nsdesk-filters" role="group" aria-label="Filter modules"></div><div id="nsdeskTiles" class="nsdesk-tiles"></div></section>
        <div class="nsdesk-v491-bottom">
          <section class="nsdesk-v491-panel nsdesk-v491-chart-panel"><div class="nsdesk-v491-panelhead"><h2>▥ Sales Overview</h2><span>Last 7 days · local bills</span></div><div id="nsdeskWeeklyChart" class="nsdesk-v491-chart" role="img" aria-label="Local sales chart for the last seven days"></div></section>
          <section class="nsdesk-v491-panel"><div class="nsdesk-v491-panelhead"><h2>▤ Recent Invoices</h2><button data-open="history">View All</button></div><div id="nsdeskRecent" class="nsdesk-recent"></div></section>
        </div>
      </div>
      <aside class="nsdesk-v491-right" aria-label="Stock and system information">
        <section class="nsdesk-v491-panel"><div class="nsdesk-v491-panelhead"><h2>⚠ Low Stock Alerts</h2><button data-open="products">View All</button></div><div id="nsdeskAlerts" class="nsdesk-alerts"></div></section>
        <section class="nsdesk-v491-panel"><div class="nsdesk-v491-panelhead"><h2>🏆 Top Selling Products</h2><span>Saved bills</span></div><div id="nsdeskTopItems" class="nsdesk-top-items"></div></section>
        <section class="nsdesk-v491-panel"><div class="nsdesk-v491-panelhead"><h2>◆ System Status</h2><button data-open="settings">Settings</button></div><div class="nsdesk-v491-system"><div>🖨 Receipt Printer <strong>Check settings</strong></div><div>☁ Cloud Sync <strong>Not verified</strong></div><div>⬇ Backup <strong>Check backups</strong></div><div>▣ App <strong>v4.9.1</strong></div></div></section>
      </aside>
    </div>
    <p class="nsdesk-disclaimer">Metrics are based on bills and products available locally. Cloud, printer and backup status require real verification. No sample transactions are added.</p>
  </section>`;
  dashboard.prepend(home);
  // dashboard itself still contains the original application elements and IDs to preserve legacy business logic.
  const color={sales:'blue',inventory:'mint',distribution:'amber',finance:'violet',people:'pink',system:'slate',overview:'blue'};
  const filters=[['all','✨ All'],['sales','🧾 Billing'],['inventory','📦 Stock'],['distribution','🚚 Delivery'],['finance','📊 Accounts'],['people','👥 HR'],['system','⚙️ Settings']];
  const node=(tag,className,text)=>{const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined)n.textContent=text;return n;};
  function open(item){if(!item||!allowed(item))return;active=item.id;
    if(typeof window.navigate==='function')window.navigate(item.page);
    if(item.tab)setTimeout(()=>$('nsERP')?.querySelector(`[data-erp-tab="${item.tab}"]`)?.click(),60);
    $('nsdeskCurrent').textContent=item.title;document.title=`${item.title} · NS POS PRO Windows`;
    document.querySelectorAll('[data-nsdesk-id]').forEach(b=>b.classList.toggle('active',b.dataset.nsdeskId===item.id));
    $('nsdeskSearch').value='';hideSearch();window.scrollTo(0,0);
  }
  function renderNav(){const nav=$('nsdeskNav');nav.replaceChildren();
    for(const [gid,title] of groups){const items=catalog.filter(x=>x.group===gid&&allowed(x));if(!items.length)continue;
      const h=node('div','nsdesk-group-label',title);nav.append(h);
      items.forEach(item=>{const b=node('button','nsdesk-nav-item'+(item.id===active?' active':''));b.type='button';b.dataset.nsdeskId=item.id;
        b.append(node('span','nsdesk-nav-emoji',item.icon),node('span','nsdesk-nav-name',item.title));if(item.id==='dashboard')b.append(node('span','nsdesk-nav-end','⌘'));
        b.addEventListener('click',()=>open(item));nav.append(b)});
    }
  }
  function renderTiles(){const holder=$('nsdeskTiles');holder.replaceChildren();catalog.filter(x=>x.group!=='overview'&&allowed(x)&&(filter==='all'||filter===x.group)).slice(0,filter==='all'?12:50).forEach(item=>{
    const b=node('button',`nsdesk-tile ${color[item.group]}`);b.type='button';b.dataset.nsdeskId=item.id;
    b.append(node('span','nsdesk-tile-emoji',item.icon),node('strong','',item.title),node('small','',item.desc),node('span','nsdesk-tile-arrow','↗'));
    b.addEventListener('click',()=>open(item));holder.append(b);
  });
    if(!holder.children.length)holder.append(node('p','nsdesk-empty','No modules are available for this account in this category.'));
  }
  function renderFilters(){const c=$('nsdeskFilters');c.replaceChildren();filters.filter(([id])=>id==='all'||catalog.some(item=>item.group===id&&allowed(item))).forEach(([id,title])=>{
    const b=node('button',id===filter?'active':'',title);b.type='button';b.setAttribute('aria-pressed',String(id===filter));b.addEventListener('click',()=>{filter=id;renderFilters();renderTiles()});c.append(b);
  })}
  const money=n=>'Rs. '+(Number(n)||0).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2});
  function localDb(){try{return typeof db!=='undefined'&&db?db:null}catch(_){return null}}
  const sameDay=(a,b)=>a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();
  function updateMetrics(){const d=localDb();if(!d)return;const invoices=Array.isArray(d.invoices)?d.invoices.filter(x=>x&&!x.voidedAt):[];
    const products=Array.isArray(d.products)?d.products:[];const today=new Date();const todays=invoices.filter(x=>sameDay(new Date(x.date),today));
    $('nsdeskSales').textContent=money(todays.reduce((s,i)=>s+(Number(i.total)||0),0));$('nsdeskBills').textContent=String(todays.length);
    $('nsdeskProducts').textContent=String(products.length);const low=products.filter(p=>Number(p.stock||0)<=Number(p.min||0));$('nsdeskLow').textContent=String(low.length);
    const names=new Set(invoices.map(i=>String(i.customer||'').trim().toLowerCase()).filter(x=>x&&x!=='cash customer'&&x!=='walk in customer'));
    $('nsdeskCustomers').textContent=String(names.size);
    $('nsdeskCredit').textContent=money(invoices.reduce((sum,i)=>sum+Math.max(0,Number(i.balance)||0),0));
    const recent=$('nsdeskRecent');recent.replaceChildren();invoices.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,6).forEach(i=>{
      const line=node('div','nsdesk-list-row');const left=node('div','nsdesk-list-label');left.append(node('strong','',String(i.number||'Invoice')),node('small','',String(i.customer||'Cash customer')));
      line.append(node('span','nsdesk-row-symbol','🧾'),left,node('strong','nsdesk-row-amount',money(i.total)));recent.append(line);
    });if(!recent.children.length)recent.append(node('p','nsdesk-empty','No sales saved on this device yet.'));
    const alerts=$('nsdeskAlerts');alerts.replaceChildren();low.slice(0,5).forEach(p=>{
      const line=node('div','nsdesk-list-row');const left=node('div','nsdesk-list-label');left.append(node('strong','',String(p.name||'Product')),node('small','',`Minimum ${Number(p.min||0)} units`));
      line.append(node('span','nsdesk-row-symbol orange','⚠️'),left,node('strong','nsdesk-stock-amount',String(p.stock||0)+' left'));alerts.append(line);
    });if(!alerts.children.length)alerts.append(node('p','nsdesk-empty','All stock levels are healthy.'));
    // Top sellers and seven-day sales are calculated from locally saved invoice lines.
    const totalsByProduct=new Map();invoices.forEach(i=>{(Array.isArray(i.lines)?i.lines:[]).forEach(l=>{const k=String(l.name||'Unnamed item');const old=totalsByProduct.get(k)||{qty:0,amount:0};old.qty+=Number(l.qty)||0;old.amount+=(Number(l.qty)||0)*(Number(l.rate)||0);totalsByProduct.set(k,old)})});
    const ranked=[...totalsByProduct.entries()].sort((a,b)=>b[1].qty-a[1].qty).slice(0,5);const sellers=$('nsdeskTopItems');sellers.replaceChildren();ranked.forEach(([name,sale],idx)=>{const line=node('div','nsdesk-v491-seller');line.append(node('span','nsdesk-v491-rank',String(idx+1)),node('span','nsdesk-v491-seller-name',name),node('span','nsdesk-v491-qty',String(sale.qty)+' pcs'),node('strong','',money(sale.amount)));sellers.append(line)});if(!ranked.length)sellers.append(node('p','nsdesk-empty','Top products appear after you save bills.'));
    const chart=$('nsdeskWeeklyChart');chart.replaceChildren();const startDate=new Date(today.getFullYear(),today.getMonth(),today.getDate());const points=[];
    for(let n=6;n>=0;n--){const dt=new Date(startDate);dt.setDate(dt.getDate()-n);const value=invoices.filter(i=>sameDay(new Date(i.date),dt)).reduce((sum,i)=>sum+(Number(i.total)||0),0);points.push({date:dt,value})}
    const ceiling=Math.max(1,...points.map(x=>x.value));points.forEach(p=>{const wrap=node('div','nsdesk-v491-baritem');wrap.title=p.date.toLocaleDateString('en-LK')+' · '+money(p.value);const bar=node('div','nsdesk-v491-bar');bar.style.height=(p.value===0?3:Math.max(8,p.value/ceiling*100))+'%';bar.setAttribute('aria-label',wrap.title);wrap.append(node('span','nsdesk-v491-barvalue',p.value?money(p.value):'—'),bar,node('span','nsdesk-v491-barlabel',p.date.toLocaleDateString('en-US',{weekday:'short'})));chart.append(wrap)});
  }
  function hideSearch(){$('nsdeskSearchResults').hidden=true;searchOpen=false;}
  function doSearch(){const q=$('nsdeskSearch').value.trim().toLowerCase(),results=$('nsdeskSearchResults');results.replaceChildren();
    if(!q){hideSearch();return;}const found=catalog.filter(x=>allowed(x)&&(x.title+' '+x.desc+' '+x.group).toLowerCase().includes(q)).slice(0,9);
    if(!found.length)results.append(node('div','nsdesk-result-none','No matching modules'));
    else found.forEach(item=>{const b=node('button','nsdesk-result');b.type='button';b.append(node('span','',item.icon),node('span','',item.title));b.onclick=()=>open(item);results.append(b)});
    results.hidden=false;searchOpen=true;
  }
  $('nsdeskSearch').addEventListener('input',doSearch);
  $('nsdeskSearch').addEventListener('keydown',e=>{if(e.key==='Escape'){hideSearch();e.target.blur()}if(e.key==='Enter'&&searchOpen){const match=catalog.find(x=>allowed(x)&&(x.title+' '+x.desc).toLowerCase().includes(e.target.value.toLowerCase()));if(match)open(match)}});
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('nsdeskSearch').focus();$('nsdeskSearch').select()}if(e.key==='Escape')hideSearch()});
  document.addEventListener('click',e=>{const b=e.target.closest('[data-open]');if(b&&home.contains(b)){const item=catalog.find(x=>x.id===b.dataset.open);if(item)open(item)}if(!e.target.closest('.nsdesk-search-wrap'))hideSearch()});
  $('nsdeskNewBill').addEventListener('click',()=>open(catalog.find(x=>x.id==='invoice')));
  $('nsdeskSignout').addEventListener('click',async()=>{if(confirm('Sign out of NS POS PRO Windows?'))await window.NSDesktop.logout()});
  function licenseStatus(s){if(!s)return;authRole=s.role||authRole;
    const expiry=s.tenant?.expires_at||s.expiresAt||'';
    $('nsdeskLicense').textContent=expiry?`Subscription · ${new Date(expiry).toLocaleDateString('en-LK')}`:'Cloud connected';
    $('nsdeskSideStatus').textContent=(s.tenant?.name||s.name||'Business')+' · '+role().toUpperCase();
    $('nsdeskNewBill').hidden=!allowed(catalog.find(x=>x.id==='invoice'));
    document.querySelectorAll('.nsdesk-home [data-open]').forEach(b=>{const item=catalog.find(x=>x.id===b.dataset.open);b.hidden=!(item&&allowed(item))});
    if(!allowed(catalog.find(x=>x.id===active)))active=allowed(catalog[0])?'dashboard':catalog.find(allowed)?.id||'';
    renderNav();renderFilters();renderTiles();updateMetrics();
    // This hides UI navigation only. Access to data must be checked by the Cloud service.
  }
  renderNav();renderFilters();renderTiles();updateMetrics();
  window.addEventListener('ns-owner-controls-updated',()=>licenseStatus({role:authRole,name:'Business'}));
  window.NSDesktop.getLicense().then(s=>{if(s?.ok)licenseStatus(s)}).catch(()=>{});
  window.NSDesktop.onLicenseUpdate(s=>licenseStatus(s));
  const observe=$('mSales');if(observe)new MutationObserver(updateMetrics).observe(observe,{childList:true,subtree:true,characterData:true});
  if($('mLow'))new MutationObserver(updateMetrics).observe($('mLow'),{childList:true,subtree:true});
  document.querySelectorAll('.ns31-lifetime').forEach(el=>el.textContent='Cloud subscription');
  const bluetooth=$('bluetoothPanel');if(bluetooth)bluetooth.style.display='none';
  document.addEventListener('click',()=>{if($('dashboard')?.classList.contains('active'))setTimeout(updateMetrics,70)});
  window.addEventListener('load',()=>{renderNav();renderFilters();renderTiles();updateMetrics()},{once:true});
})();