/* Only Admin may void, audit kept. No deletion of financial records. */
(()=>{'use strict';
const el=id=>document.getElementById(id);
const admin=()=>typeof NS2_admin==='function'&&NS2_admin()&&window.NSCloud?.getRole?.()!=='rep';
function doVoid(id){if(!admin())return toast('Admin PIN required');const bill=db.invoices.find(i=>i.id===id);
 if(!bill||bill.voidedAt)return toast('Bill missing or already voided');
 if((db.returns||[]).some(x=>x.invoiceId===id)||(db.creditPayments||[]).some(x=>x.invoiceId===id)||(db.cheques||[]).some(x=>x.invoiceId===id))return toast('Linked payments / returns / cheques: reconcile before voiding');
 const reason=prompt('Reason to void '+bill.number+' (at least 5 characters):');if(reason===null)return;if(reason.trim().length<5)return toast('Please enter a reason');
 if(!confirm('VOID '+bill.number+'? Stock will NOT be restored automatically. The original invoice is retained in audit.'))return;
 const before=JSON.stringify(db);bill.voidedAt=new Date().toISOString();bill.voidReason=reason.trim();bill.voidedBy=NS2_USER?.name||'Admin';db.invoiceVoidAudit=db.invoiceVoidAudit||[];db.invoiceVoidAudit.push({invoiceId:id,number:bill.number,at:bill.voidedAt,by:bill.voidedBy,reason:bill.voidReason});
 if(!save()){db=JSON.parse(before);return}renderAll();toast('Bill voided — original preserved for audit');}
const history=renderHistory;renderHistory=function(){history();if(!admin())return;const box=el('historyList');if(!box)return;box.querySelectorAll('button[onclick^="openInvoice("]').forEach(button=>{
 const match=button.getAttribute('onclick')?.match(/openInvoice\('([^']+)'\)/);if(!match)return;const bill=db.invoices.find(i=>i.id===match[1]);if(!bill)return;
 const row=button.closest('.ns2-entry')||button.parentElement;if(!row||row.querySelector('[data-admin-void]'))return;
 if(bill.voidedAt){const label=document.createElement('span');label.className='pill bad';label.textContent='VOID · '+bill.voidReason;row.append(label);return}
 const voidBtn=document.createElement('button');voidBtn.className='danger sm';voidBtn.type='button';voidBtn.textContent='Void Bill';voidBtn.dataset.adminVoid=bill.id;voidBtn.onclick=()=>doVoid(bill.id);row.append(voidBtn);
 });};
const dashboard=renderDashboard;renderDashboard=function(){dashboard();const td=new Date().toDateString();const active=db.invoices.filter(i=>!i.voidedAt);const sales=active.filter(i=>new Date(i.date).toDateString()===td).reduce((s,i)=>s+Number(i.total||0),0);if(el('mSales'))el('mSales').textContent=money(sales)};
window.NSBillVoid={voidBill:doVoid};
})();
