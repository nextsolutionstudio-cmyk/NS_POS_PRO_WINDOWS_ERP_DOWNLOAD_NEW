/* NS POS PRO v2.8 LIFETIME — genuine ESC/POS centering for 80mm bills.
 * Do not center thermal text by padding with spaces: font sizes and printer columns vary.
 * ESC a 1 centers the business name, address and phone on the real printer.
 * GS ! 0x11 makes each business-name line twice as wide/tall (max 20 ASCII chars per line).
 * Uses the EXISTING paired Bluetooth SPP transport / logo printing.
 */
(function(){
'use strict';
const el=id=>document.getElementById(id);
const hasNative=()=>Boolean(window.AndroidPrinter && typeof AndroidPrinter.printAuto==='function');
const PKEY='ns_pos_preferred_printer_mac_v21';
const ESC='\x1b';
const ALIGN_CENTER=ESC+'a'+'\x01', ALIGN_LEFT=ESC+'a'+'\x00';
const BOLD=ESC+'E'+'\x01', NORMAL=ESC+'E'+'\x00';
const BIG='\x1d'+'!'+'\x11', NORMAL_SIZE='\x1d'+'!'+'\x00';
const num2=x=>(Number(x)||0).toFixed(2);
const sep='------------------------------------------';
const clean=x=>String(x==null?'':x).replace(/[\r\n\x1b\x00-\x08\x0b-\x1f]/g,' ').replace(/\s+/g,' ').trim();
function wrapWords(input,limit){
  const text=clean(input), out=[];let line='';
  for(const word of text.split(' ')){
    if(!word)continue;
    const pieces=word.length<=limit?[word]:word.match(new RegExp('.{1,'+limit+'}','g'))||[word];
    for(const part of pieces){
      if(!line){line=part;continue;}
      if(line.length+1+part.length<=limit)line+=' '+part;
      else{out.push(line);line=part;}
    }
  }
  if(line)out.push(line);
  return out.length?out:[''];
}
function headingLines(name){
  const value=clean(name||'BUSINESS');
  if(value.length<=20)return [value];
  // HIGHTAGS / Ceylon Global Market is easier to read and centered on 80mm paper.
  const at=value.indexOf(' ');
  if(at>0 && at<=13 && value.length-at-1<=20)return [value.slice(0,at),value.slice(at+1)];
  return wrapWords(value,20);
}
function receipt(inv){
  const b=inv.business||db.settings||{};
  const lines=[];
  const add=s=>lines.push(s);
  // Printer ESC/POS alignment: works after a logo/raster print, unlike leading spaces.
  for(const line of headingLines(b.name||'BUSINESS'))
    add(ALIGN_CENTER+BOLD+BIG+line+NORMAL_SIZE+NORMAL);
  for(const line of wrapWords(b.address||'',40))if(line)add(ALIGN_CENTER+line);
  for(const phone of [b.phone,b.phone2,b.phone3].filter(Boolean))for(const line of wrapWords('Tel: '+clean(phone),40))add(ALIGN_CENTER+line);
  add(ALIGN_LEFT+sep);
  add('Invoice: '+clean(inv.number||''));
  add('Date: '+new Date(inv.date||Date.now()).toLocaleString());
  add('Customer: '+clean(inv.customer||'Walk-in Customer'));
  if(inv.phone)add('Phone: '+clean(inv.phone));
  add(sep);
  (inv.lines||[]).forEach(item=>{
    for(const name of wrapWords(item.name||'Item',40))add(BOLD+name+NORMAL);
    add('  '+clean(item.qty)+' x '+num2(item.rate)+' = '+num2((Number(item.qty)||0)*(Number(item.rate)||0)));
  });
  add(sep);
  add('Subtotal: '+num2(inv.subtotal));
  add('Discount: '+num2(inv.discount));
  add(BOLD+'TOTAL:   Rs. '+num2(inv.total)+NORMAL);
  add('Paid: '+num2(inv.paid));
  add(BOLD+'BALANCE: Rs. '+num2(inv.balance)+NORMAL);
  add('Payment: '+clean(inv.payment||'Cash'));
  if(inv.rep)add('Sales Rep: '+clean(inv.rep));
  let ck=inv.chequeId && db.cheques?.find(x=>x.id===inv.chequeId);
  if(ck){add('Cheque: '+clean(ck.number)+' / '+clean(ck.bank));add('Cheque Status: '+clean(ck.status));}
  if(inv.kind==='return')add('SALES RETURN / CREDIT NOTE');
  add(sep);
  for(const line of wrapWords(inv.note||b.footer||'Thank you! Visit again.',40))add(ALIGN_CENTER+line);
  add(ALIGN_CENTER+'© Next Solution Studio');
  add(ALIGN_CENTER+'All rights reserved.');
  add(ALIGN_LEFT+'');add('');add('');
  return lines.join('\n');
}
window.NS28_textReceipt=receipt;
window.NS27_textReceipt=receipt;
if(typeof window.textReceipt==='function')window.textReceipt=receipt;
else try{textReceipt=receipt;}catch(_){}
function adjustPreview(){
  for(const parentId of ['receiptPreview','printZone']){
    const paper=el(parentId)?.querySelector('.invoice-paper');if(!paper)continue;
    const b=previewInvoice?.business||db.settings||{};
    const heading=paper.querySelector('.center');
    if(heading){
      heading.style.textAlign='center';heading.style.width='100%';
      const nodes=heading.querySelectorAll('div');
      for(const node of nodes){node.style.textAlign='center';node.style.width='100%';node.style.lineHeight='1.35';}
      if(nodes.length>=2){const phones=[b.phone,b.phone2,b.phone3].filter(Boolean);nodes[nodes.length-1].textContent=phones.length?'Tel: '+phones.join(' / '):'';nodes[nodes.length-1].style.overflowWrap='anywhere';}
      const h=heading.querySelector('h2');
      if(h){h.style.cssText='font-family:Arial,sans-serif;font-size:24px;font-weight:900;line-height:1.2;text-align:center;overflow-wrap:anywhere;margin:8px 0 6px;';}
    }
    paper.querySelectorAll('table td:first-child').forEach(n=>n.style.fontWeight='750');
    const total=paper.querySelector('.total');if(total){total.style.fontSize='19px';total.style.fontWeight='800';}
    for(const node of paper.querySelectorAll('div')){
      if(node.children.length===0 && /^Balance:\s/.test((node.textContent||'').trim())){
        node.style.fontWeight='800';node.style.fontSize='18px';node.style.marginTop='3px';
      }
    }
  }
}
const baseShow=window.showPreview;
if(typeof baseShow==='function')window.showPreview=function(...args){const r=baseShow.apply(this,args);adjustPreview();return r;};
function makeTestMarkup(){return `<div class="invoice-paper" style="margin:auto;text-align:center;color:black;background:white;font-family:Arial,sans-serif;padding:10px"><img src="./ns-test-logo.png" style="width:94px;height:94px;object-fit:contain;margin:auto"><h2 style="font-size:23px;margin:5px 0">Next Solution Studio</h2><div style="font-weight:600">Tel: 076 27 18 629</div><div style="margin:9px 0;font-style:italic">Your Business. Our Solutions.</div><div style="border-top:1px dashed #444;margin:10px 0"></div><div style="font-size:11px">TEST PRINT</div></div>`;}
function testPrint(){
  const msg='\n'+ALIGN_CENTER+BOLD+BIG+'Next Solution Studio'+NORMAL_SIZE+NORMAL+'\n'
    +ALIGN_CENTER+'Tel: 076 27 18 629\n'+ALIGN_CENTER+'Your Business. Our Solutions.\n'
    +ALIGN_LEFT+sep+'\n'+ALIGN_CENTER+'TEST PRINT\n'+ALIGN_LEFT+'\n\n';
  if(hasNative()){
    const mac=localStorage.getItem(PKEY)||window.selectedPrinter||'';
    const btn=el('ns21TestPrint');if(btn)btn.disabled=true;
    try{AndroidPrinter.printAuto(mac,msg,window.NS_TEST_LOGO_DATA||'');}
    catch(e){if(btn)btn.disabled=false;toast('Test Print error: '+e.message);}
  }else{
    const box=el('printZone');if(!box)return toast('No system printing available');
    const prev=box.innerHTML;box.innerHTML=makeTestMarkup();
    try{window.print();}finally{setTimeout(()=>{box.innerHTML=prev;},350);}
  }
}
window.NS27_testPrint=testPrint;
const testBtn=el('ns21TestPrint')||document.querySelector('button[onclick="testPrinter()"]');
if(testBtn){testBtn.textContent='🖨 Test Print';testBtn.removeAttribute('onclick');testBtn.onclick=testPrint;}
const btn=el('ns21TestPrint');if(btn){btn.textContent='🖨 Test Print';btn.onclick=testPrint;}
const statusNative=window.NS21_printStatus;
if(typeof statusNative==='function')window.NS21_printStatus=function(status,msg,mac){
  const btn=el('ns21TestPrint');if(btn)btn.disabled=false;
  return statusNative(status,msg,mac);
};
})();
