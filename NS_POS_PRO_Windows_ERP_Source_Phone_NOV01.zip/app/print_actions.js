/* NS POS Pro v2.4 Lifetime - text-only printer diagnostic and JPG receipt fallback.
 * Android APK -> paired Bluetooth Classic ESC/POS printer (native bridge).
 * Browser/iOS -> operating system print dialog (AirPrint only if available).
 * Never print an unsaved sales invoice. Prevent repeat taps while sending.
 */
(function () {
  'use strict';
  const KEY = 'ns_pos_preferred_printer_mac_v21';
  const $id = id => document.getElementById(id);
  let busy = false;
  let currentStatus = '';
  const native = () => !!(window.AndroidPrinter && typeof window.AndroidPrinter.printAuto === 'function');
  const desktop = () => !!(window.NSDesktopPrinter && typeof window.NSDesktopPrinter.printBill === 'function');
  function mark(text) {
    const box = $id('ns21PrintInfo');
    if (box) box.textContent = text;
  }
  function isSaved() {
    if (!previewInvoice) return false;
    if (db.invoices.some(i => i.id === previewInvoice.id)) return true;
    return previewInvoice.kind === 'return' && db.returns.some(r => 'return-' + r.id === previewInvoice.id);
  }
  function buttons(on) {
    busy = on;
    for (const id of ['ns21PrintNow', 'ns21SavePrint', 'ns21TestPrint']) {
      const button = $id(id);
      if (button) button.disabled = on;
    }
    if ($id('ns21PrintNow')) $id('ns21PrintNow').textContent = on ? '⏳ Sending to printer…' : '🖨 Print Bill';
  }
  function printViaSystem() {
    // This only opens the OS print UI. Browser Bluetooth Classic is unsupported.
    // Supported AirPrint/printer services must be installed separately.
    window.print();
    mark('System Print opened — choose an available printer and confirm.');
  }
  window.NS21_printNow = function () {
    if (busy) return;
    if (!isSaved()) return toast('Save Bill first, then press Print.');
    if (native()) {
      buttons(true);
      currentStatus = previewInvoice.number;
      mark('Connecting to paired Bluetooth Xprinter…');
      try {
        let preferred = localStorage.getItem(KEY) || selectedPrinter || '';
        window.AndroidPrinter.printAuto(preferred, textReceipt(previewInvoice), db.settings.receiptLogo===false ? '' : ((previewInvoice.business||db.settings).logo||''));
      } catch (error) {
        buttons(false);
        mark('Printer error: ' + error.message);
        toast('Print could not start');
      }
    } else if (desktop()) {
      buttons(true); mark('Sending bill to the auto-selected Windows thermal printer…');
      window.NSDesktopPrinter.printBill({
        number:String(previewInvoice.number||''), date:String(previewInvoice.date||new Date().toISOString()),
        business:{...(previewInvoice.business||db.settings||{})},
        customer:String(previewInvoice.customer||''), phone:String(previewInvoice.phone||''),
        lines:(previewInvoice.lines||[]).map(item=>({name:String(item.name||''),qty:Number(item.qty)||0,rate:Number(item.rate)||0})),
        subtotal:Number(previewInvoice.subtotal)||0,discount:Number(previewInvoice.discount)||0,
        taxAmount:Number(previewInvoice.taxAmount)||0,total:Number(previewInvoice.total)||0,
        paid:Number(previewInvoice.paid)||0,balance:Number(previewInvoice.balance)||0,
        payment:String(previewInvoice.payment||''),paymentNote:String(previewInvoice.paymentNote||''),note:String(previewInvoice.note||'')
      }).then(result=>{
        buttons(false); mark(result.message || (result.ok?'Sent to Windows printer':'Printing failed'));
        toast(result.ok?'Print job queued':'Windows print failed');
      }).catch(e=>{buttons(false);mark('Windows print error: '+e.message);toast('Print failed');});
    } else printViaSystem();
  };
  window.NS21_printStatus = function (status, message, mac) {
    buttons(false);
    mark(message || status);
    if (status === 'sent' && mac) {
      selectedPrinter = mac;
      try { localStorage.setItem(KEY, mac); } catch (_) { /* private storage may be off */ }
    }
    if (status === 'permission') return toast('Allow Nearby Devices permission and try Print again.');
    if (status === 'choose') {
      toast('Choose your Xprinter under Settings → Paired Printers');
      return;
    }
    toast(message || (status === 'sent' ? 'Receipt sent to printer' : 'Print failed'));
  };
  // Persist explicit selection from Settings, for the next invoice and next app launch.
  const priorChoose = window.choosePrinter;
  window.choosePrinter = function (mac) {
    if (typeof priorChoose === 'function') priorChoose(mac);
    else selectedPrinter = mac;
    try { localStorage.setItem(KEY, mac); } catch (_) {}
    mark('Preferred Bluetooth printer saved.');
  };
  try { selectedPrinter = localStorage.getItem(KEY) || selectedPrinter || ''; } catch (_) {}

  window.NS21_saveAndPrint = function () {
    const last = db.invoices[0] ? db.invoices[0].id : '';
    saveInvoice(); // Handles validation + stock adjustment atomically in existing app.
    if (db.invoices[0] && db.invoices[0].id !== last && isSaved()) NS21_printNow();
  };
  window.NS21_testPrint = function () {
    if (!native()) return toast('Pair a Bluetooth printer in Android Settings and print a saved test bill.');
    if (busy) return;
    buttons(true);
    mark('Sending text-only ESC/POS diagnostic…');
    try {
      const preferred = localStorage.getItem(KEY) || selectedPrinter || '';
      window.AndroidPrinter.printAuto(preferred, 'NS POS PRO - TEXT ONLY TEST\nXPRINTER XP-P502A\n------------------------------\nIF YOU SEE THIS: RECEIPT MODE OK\n------------------------------\n\n\n', '');
    } catch(e) { buttons(false); mark('Could not send test: ' + e.message); }
  };
  // One prominent Print button with same wording on Android, iPhone and PC.
  // Keep standard System Print as a secondary fallback on Android.
  const container = $id('btPrintButton')?.parentElement;
  if (container) {
    const primary = document.createElement('button');
    primary.type = 'button'; primary.id = 'ns21PrintNow'; primary.className = 'primary';
    primary.textContent = '🖨 Print Bill';
    primary.addEventListener('click', NS21_printNow);
    container.insertBefore(primary, container.firstChild);
    $id('btPrintButton').style.display = 'none';
    const system = $id('systemPrintButton');
    if (system) {
      system.style.display = native() || desktop() ? 'none' : '';
      system.textContent = 'System Print / PDF';
    }
    const hint = document.createElement('p');
    hint.className = 'hint'; hint.id = 'ns21PrintInfo';
    hint.style.cssText = 'width:100%;margin:6px 0 0';
    hint.textContent = native() ? 'Android: paired available Xprinter prints automatically; pair once in Android Settings.' :
      (desktop() ? 'Windows: detects installed Xprinters and prints one receipt at the matching 58/80mm width.' :
      'Browser: opens the operating-system print dialog; no silent printer access.');
    container.appendChild(hint);
  }
  const saveBill = document.querySelector('button[onclick="saveInvoice()"]');
  if (saveBill) {
    const extra = document.createElement('button');
    extra.type = 'button';extra.className = 'secondary';extra.id='ns21SavePrint';
    extra.textContent = '✓ Save & Print';
    extra.addEventListener('click', NS21_saveAndPrint);
    saveBill.after(extra);
  }
  const test = document.querySelector('button[onclick="testPrinter()"]');
  if (test) { test.textContent = '🧾 Test Text Only';test.id='ns21TestPrint';test.onclick = NS21_testPrint; }
  const helper = $id('bluetoothPanel');
  if (helper) helper.insertAdjacentHTML('beforeend', '<p class="hint">XP-P301A / XP-P502A: Bluetooth must be paired once in Android Settings. XP-80T: USB or LAN driver with Windows Default Printer. Avoid retry if printing status is uncertain.</p>');
})();
