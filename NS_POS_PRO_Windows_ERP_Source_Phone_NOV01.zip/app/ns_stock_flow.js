/* NS POS PRO v4.8 wholesale and delivery inventory calculations.
   The persisted vehicleLedger field remains for backwards-compatibility only.
   No remote sync is implied by this module. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.NSStockFlow=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';const n=v=>{const x=Number(v);return Number.isFinite(x)?x:0};const r=v=>Math.round((v+Number.EPSILON)*1000)/1000;
 const deliverySold=(invoices,repId,pid)=>r((invoices||[]).filter(i=>i.mode==='stock'&&i.vehicleRepId===repId).reduce((a,i)=>a+(i.lines||[]).filter(l=>l.productId===pid).reduce((s,l)=>s+n(l.qty),0),0));
 const deliveryBalance=(ledger,invoices,repId,pid)=>r((ledger||[]).filter(t=>t.repId===repId&&t.productId===pid).reduce((s,t)=>s+(t.kind==='load'?n(t.qty):-n(t.qty)),0)-deliverySold(invoices,repId,pid));
 const allDelivery=(ledger,invoices,pid)=>{const reps=new Set((ledger||[]).filter(t=>t.productId===pid).map(t=>t.repId));return r([...reps].reduce((s,rep)=>s+deliveryBalance(ledger,invoices,rep,pid),0));};
 const wholesaleAvailable=(products,ledger,invoices,pid)=>r(n((products||[]).find(p=>p.id===pid)?.stock)-allDelivery(ledger,invoices,pid));
 const canTransfer=(products,ledger,invoices,repId,pid,kind,quantity)=>{const qty=Number(quantity);if(!Number.isFinite(qty)||qty<=0)return false;if(kind==='load')return qty<=wholesaleAvailable(products,ledger,invoices,pid)+1e-9;if(kind==='unload')return qty<=deliveryBalance(ledger,invoices,repId,pid)+1e-9;return false;};
 return Object.freeze({deliverySold,deliveryBalance,allDelivery,wholesaleAvailable,canTransfer});
});
