/* Customer branding is read-only. Cloudflare owner branding sync remains enabled. */
(()=>{'use strict';
 const brandKeys=['name','phone','phone2','phone3','email','website','address','logo','footer','theme'];
 const get=id=>document.getElementById(id);
 const panel=get('sName')?.closest('.panel');
 if(!panel)return;
 panel.dataset.nsOwnerOnly='true';
 panel.querySelector('h2').textContent='🏢 Business Details (Owner Managed)';
 const label=document.createElement('p');label.className='hint';label.textContent='Business name, logo, phone, address, email, website, receipt footer and branding are edited in NS POS PRO Developer Owner and synced from Cloud. This Customer App displays them only.';
 panel.querySelector('h2').after(label);
 function readonly(){
  ['sName','sPhone','sAddress','sEmail','sWebsite','sFooter','sLogo'].forEach(id=>{const e=get(id);if(!e)return;e.disabled=true;e.setAttribute('aria-readonly','true')});
  const saveBtn=panel.querySelector('button[onclick="saveSettings()"]');if(saveBtn)saveBtn.remove();
  const theme=get('ns2ThemePicks');if(theme)theme.style.display='none';
  for(const x of document.querySelectorAll('.dev37-access'))x.remove();
 }
 // These functions cannot be used to change remote-controlled identity from the customer UI.
 saveSettings=function(){toast('Business details are managed in Developer Owner. Tap Refresh Business Details Now.')};
 uploadLogo=function(input){if(input)input.value='';toast('Change logo in Developer Owner only')};
 if(typeof NS2_setTheme==='function')NS2_setTheme=function(){toast('Business theme is managed by Developer Owner')};
 const oldRender=renderSettings;renderSettings=function(...args){const value=oldRender.apply(this,args);readonly();return value};
 // Restore business data without replacing owner-controlled business branding.
 restoreData=function(input){
  if(typeof NS2_needAdmin==='function'&&!NS2_needAdmin())return;
  const f=input?.files?.[0];if(!f)return;
  const reader=new FileReader();reader.onload=()=>{try{
   const next=JSON.parse(reader.result);
   if(!Array.isArray(next.products)||!Array.isArray(next.invoices)||!Array.isArray(next.grns)||!next.settings)throw Error('Invalid business backup');
   if(!confirm('Restore local products, invoices and GRNs? Owner-controlled branding will be preserved.'))return;
   const previous=db,original={...db.settings};const revised={...next,settings:{...next.settings}};
   for(const key of brandKeys)revised.settings[key]=original[key];
   db=revised;if(!save()){db=previous;return}
   grnCart=[];invoiceCart=[];renderAll();toast('Business data restored; Owner branding unchanged');
  }catch(e){toast('Restore failed: '+e.message)}finally{input.value=''}};reader.readAsText(f);
 };
 readonly();
})();
