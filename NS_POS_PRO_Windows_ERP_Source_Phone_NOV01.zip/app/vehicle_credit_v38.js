/* NS POS PRO v3.8: Wholesale available and Delivery (Rep) stock, customer receivables & daily rep closing.
   Device-local. Wholesale-to-Delivery transfers do not alter total stock; stock invoices do.
   Stock transfers are local to this Windows profile; cross-device stock sync is NOT provided. */
(()=>{
'use strict';
const $v=id=>document.getElementById(id), fmt=n=>'Rs. '+Number(n||0).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2});
const safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dec=n=>Number.isFinite(Number(n))?Number(n):0, round=n=>Math.round((n+Number.EPSILON)*1000)/1000;
function ensure(){db.vehicleLedger=Array.isArray(db.vehicleLedger)?db.vehicleLedger:[];db.creditPayments=Array.isArray(db.creditPayments)?db.creditPayments:[];db.repClosings=Array.isArray(db.repClosings)?db.repClosings:[];}
ensure();
const current=()=>typeof NS2_USER==='undefined'?null:NS2_USER;
const admin=()=>typeof NS2_admin==='function'&&NS2_admin();
const ownerInvoice=inv=>admin()||inv.repId===current()?.id;
const product=id=>db.products.find(p=>p.id===id);
function repName(id){return db.users.find(u=>u.id===id)?.name||db.invoices.find(i=>i.repId===id)?.rep||'Unknown rep'}
function activeRepId(){return admin()?($v('v38Rep')?.value||''):current()?.id||'';}
function vehicleSold(repId,pid){return NSStockFlow.deliverySold(db.invoices,repId,pid)}
function vehicleBalance(repId,pid){return NSStockFlow.deliveryBalance(db.vehicleLedger,db.invoices,repId,pid)}
function allVehicle(pid){return NSStockFlow.allDelivery(db.vehicleLedger,db.invoices,pid)}
function warehouse(pid){return NSStockFlow.wholesaleAvailable(db.products,db.vehicleLedger,db.invoices,pid)}
function creditAdjustment(i){return (db.returns||[]).filter(r=>r.invoiceId===i.id).reduce((s,r)=>s+dec(r.refund),0)}
function outstanding(i){if(i.payment==='Cheque')return 0;return round(Math.max(0,dec(i.total)-dec(i.paid)-creditAdjustment(i)))}
function creditInvoices(){return db.invoices.filter(i=>i.payment==='Credit'||(i.payment!=='Cheque'&&outstanding(i)>.0001));}
function dueStatus(i){if(outstanding(i)<.001)return 'Paid';if(!i.creditDue)return 'Outstanding';const due=new Date(i.creditDue+'T23:59:59');return due<new Date()?'Overdue':'Due '+i.creditDue;}
function setOptions(id,arr,selected){let e=$v(id);if(!e)return;const old=selected??e.value;e.innerHTML=arr.map(a=>`<option value="${safe(a[0])}">${safe(a[1])}</option>`).join('');if(arr.some(x=>x[0]===old))e.value=old;}
function install(){
 const nav=$v('tabs');nav.insertAdjacentHTML('beforeend','<button type="button" data-page="wholesale" onclick="navigate(\'wholesale\')">📦 Wholesale Stock</button><button type="button" data-page="delivery" onclick="navigate(\'delivery\')">🚚 Delivery Stock</button><button type="button" data-page="credit" onclick="navigate(\'credit\')">💳 Customer Credit</button>');
 document.querySelector('main').insertAdjacentHTML('beforeend',`
 <section class="page" id="wholesale"><div class="ns38-banner ns38-vehicle"><span>📦</span><div><h2>Wholesale Stock</h2><small>Available for wholesale • Not allocated to deliveries</small></div></div>
 <div class="ns38-kpis"><div><span>Wholesale available</span><b id="v38WAvailable">0</b></div><div><span>Delivery allocated</span><b id="v38WDelivery">0</b></div><div><span>Total stock on hand</span><b id="v38WTotal">0</b></div></div>
 <div class="panel"><h2>Wholesale Inventory</h2><p class="hint">GRN adds to total stock. Delivery transfer reserves quantity without recording a sale. Prices and GRNs can be managed in Products / Purchases.</p><div class="field"><label>Search product</label><input id="v38WholesaleSearch" type="search" placeholder="Search product / barcode" oninput="NS38.renderWholesale()"></div><div id="v38WholesaleTable" class="scroll"></div></div>
 <div class="panel"><h2>Stock Movement</h2><p class="hint">To allocate stock to a rep, open Delivery Stock → Transfer Stock. Only Admin can approve transfers. Changes made on this device are not yet shared to other PCs.</p><button class="primary" onclick="navigate('delivery')">🚚 Open Delivery Stock</button></div></section>
 <section class="page" id="delivery"><div class="ns38-banner ns38-vehicle"><span>🚚</span><div><h2>Delivery Stock</h2><small>Allocated to reps • Sales • Unsold goods returned to Wholesale</small></div></div>
 <div class="ns38-kpis"><div><span>Allocated for delivery</span><b id="v38OnVehicle">0</b></div><div><span>Sold from delivery</span><b id="v38VehicleSold">0</b></div><div><span>Wholesale available</span><b id="v38Warehouse">0</b></div></div>
 <div class="panel"><h2>Delivery Inventory by Rep</h2><div class="row"><div class="field"><label>Sales Rep</label><select id="v38Rep" onchange="NS38.render()"></select></div></div><div id="v38Table" class="scroll"></div></div>
 <div class="panel" id="v38AdminForm"><h2>Transfer Stock</h2><div class="row"><div class="field"><label>Product</label><select id="v38Product" onchange="NS38.renderAvailable()"></select></div><div class="field"><label>Quantity</label><input id="v38Qty" type="number" step="any" min="0.001" placeholder="Qty"></div></div><div id="v38Available" class="hint"></div><div class="field"><label>Notes (optional)</label><input id="v38Note" placeholder="Delivery / Route / Return notes"></div><div class="actions"><button class="primary" onclick="NS38.transfer('load')">+ Allocate to Delivery</button><button class="secondary" onclick="NS38.transfer('unload')">↩ Return to Wholesale</button></div></div>
 <div class="panel"><h2>Transfer History</h2><div id="v38History" class="scroll"></div></div></section>
 <section class="page" id="credit"><div class="ns38-banner ns38-credit"><span>💳</span><div><h2>Customer Credit</h2><small>Outstanding balances • Collections • Due dates</small></div></div>
 <div class="ns38-kpis"><div><span>Outstanding</span><b id="v38DueTotal">0</b></div><div><span>Overdue bills</span><b id="v38Overdue">0</b></div><div><span>Collected today</span><b id="v38Collected">0</b></div></div>
 <div class="panel"><h2>Customer Balances</h2><div class="field"><label>Search Customer / Invoice</label><input id="v38CreditSearch" placeholder="Shop, customer or invoice number" oninput="NS38.renderCredit()"></div><div id="v38CreditTable" class="scroll"></div></div>
 <div class="panel"><h2>Receive Payment</h2><div class="row"><div class="field"><label>Invoice</label><select id="v38CreditInvoice" onchange="NS38.renderAvailable()"></select></div><div class="field"><label>Amount (LKR)</label><input id="v38PayAmount" type="number" step="0.01" min="0.01"></div></div><div class="row"><div class="field"><label>Received Via</label><select id="v38PayMethod"><option>Cash</option><option>Bank Transfer</option><option>Card</option></select></div><div class="field"><label>Reference (optional)</label><input id="v38PayReference" placeholder="Receipt / Bank reference"></div></div><p id="v38BalanceInfo" class="hint"></p><button class="primary" onclick="NS38.collect()">✓ Record Payment</button></div>
 <div class="panel"><h2>Payment History</h2><div id="v38Payments" class="scroll"></div></div></section>
 <section class="page" id="repclosing"><div class="ns38-banner ns38-closing"><span>📊</span><div><h2>Daily Rep Closing</h2><small>Invoices • Collections • Returns • Delivery stock</small></div></div>
 <div class="panel"><div class="row"><div class="field"><label>Date</label><input type="date" id="v38ClosingDate" onchange="NS38.renderClosing()"></div><div class="field"><label>Rep</label><select id="v38ClosingRep" onchange="NS38.renderClosing()"></select></div></div><div id="v38ClosingSummary"></div><div class="actions"><button class="secondary" onclick="NS38.downloadClosing()">⬇ Export CSV</button><button class="primary" onclick="NS38.closeDay()">✓ Save Daily Closing</button></div></div><div class="panel"><h2>Saved Closing Reports</h2><div id="v38ClosingHistory"></div></div></section>`);
 let tiles=document.querySelector('.ns31-shortcuts');if(tiles)tiles.insertAdjacentHTML('beforeend',`<button type="button" class="ns31-tile ns38-tile-vehicle" onclick="navigate('wholesale')"><span class="ns31-tileicon">📦</span><strong>Wholesale Stock</strong><small>Available stock</small></button><button type="button" class="ns31-tile ns38-tile-vehicle" onclick="navigate('delivery')"><span class="ns31-tileicon">🚚</span><strong>Delivery Stock</strong><small>Allocated to rep</small></button><button type="button" class="ns31-tile ns38-tile-credit" onclick="navigate('credit')"><span class="ns31-tileicon">💳</span><strong>Customer Credit</strong><small>Payments due</small></button><button type="button" class="ns31-tile ns38-tile-close" onclick="navigate('repclosing')"><span class="ns31-tileicon">📊</span><strong>Rep Closing</strong><small>Daily summary</small></button>`);
 const payment=$v('iPayment');payment?.closest('.row')?.insertAdjacentHTML('afterend','<div class="field ns38-due" id="v38DueWrap" style="display:none"><label>Customer Payment Due Date (optional)</label><input id="v38DueDate" type="date"></div>');
 payment?.addEventListener('change',dueVisibility);
 const css=document.createElement('style');css.textContent=`.ns38-banner{color:#fff;display:flex;align-items:center;gap:16px;border-radius:20px;padding:24px;margin-bottom:15px;box-shadow:0 8px 18px #1b355b24}.ns38-banner>span{font-size:36px;border-radius:14px;background:#ffffff28;padding:11px}.ns38-banner h2{color:#fff;font-size:23px;margin:0 0 5px}.ns38-banner small{font-size:13px;color:#ffffffdc}.ns38-vehicle{background:linear-gradient(115deg,#0c9d83,#44c5ab)}.ns38-credit{background:linear-gradient(115deg,#6643d3,#a26bea)}.ns38-closing{background:linear-gradient(115deg,#e07828,#e8ad50)}.ns38-tile-vehicle{background:linear-gradient(140deg,#008e8b,#44c7bb)!important;color:white!important}.ns38-tile-credit{background:linear-gradient(140deg,#6d44c7,#ad77ef)!important;color:white!important}.ns38-tile-close{background:linear-gradient(140deg,#e47f22,#f2b654)!important;color:white!important}.ns38-kpis{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:10px 0 18px}.ns38-kpis>div{padding:12px;border-radius:12px;background:#fff;border:1px solid #e4e9f3;min-width:0}.ns38-kpis span{display:block;color:#6c7894;font-size:11px}.ns38-kpis b{display:block;font-size:clamp(12px,2.7vw,19px);margin-top:5px;overflow-wrap:anywhere;color:#1a3271}.ns38-list{display:flex;justify-content:space-between;gap:8px;padding:9px 3px;border-bottom:1px solid #eef0f5;align-items:center}.ns38-list small{display:block;color:#64748b}.ns38-warning{color:#b42335!important}.ns38-pill{border-radius:40px;padding:4px 7px;background:#eaf2ff;color:#294c9b;font-size:11px;font-weight:700}.ns38-table{width:100%;font-size:12px}.ns38-table th,.ns38-table td{padding:9px 6px}.ns38-table td:last-child{text-align:right}@media(max-width:480px){.ns38-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.ns38-kpis>div:last-child{grid-column:1/-1}}`;document.head.append(css);
 if($v('v38ClosingDate'))$v('v38ClosingDate').value=new Date().toLocaleDateString('en-CA');
}
function dueVisibility(){if($v('v38DueWrap'))$v('v38DueWrap').style.display=$v('iPayment')?.value==='Credit'?'':'none'}
function renderAvailable(){let id=$v('v38Product')?.value,repId=activeRepId(),inv=db.invoices.find(i=>i.id===$v('v38CreditInvoice')?.value);if($v('v38Available'))$v('v38Available').textContent=id?`Wholesale available: ${warehouse(id)} • Rep balance: ${repId?vehicleBalance(repId,id):0}`:'';if($v('v38BalanceInfo'))$v('v38BalanceInfo').textContent=inv?`${inv.number} — ${inv.customer||'Cash Customer'} | Outstanding: ${fmt(outstanding(inv))}`:'Select an outstanding invoice';}
function renderWholesale(){
 const table=$v('v38WholesaleTable');if(!table)return;
 const query=($v('v38WholesaleSearch')?.value||'').trim().toLowerCase();
 const products=db.products.filter(p=>(String(p.name||'')+' '+String(p.barcode||'')).toLowerCase().includes(query));
 const total=db.products.reduce((sum,p)=>sum+dec(p.stock),0);
 const delivery=db.products.reduce((sum,p)=>sum+allVehicle(p.id),0);
 $v('v38WAvailable').textContent=round(total-delivery);
 $v('v38WDelivery').textContent=round(delivery);
 $v('v38WTotal').textContent=round(total);
 table.innerHTML=products.length?`<table class="ns38-table"><thead><tr><th>Product</th><th>Wholesale</th><th>Delivery</th><th>Total</th></tr></thead><tbody>${products.map(p=>{const w=warehouse(p.id),d=allVehicle(p.id);return `<tr><td><b>${safe(p.name)}</b><small style="display:block">${safe(p.barcode||'')}</small></td><td><b class="${w<0?'ns38-warning':''}">${w}</b></td><td>${d}</td><td>${round(dec(p.stock))}</td></tr>`}).join('')}</tbody></table>`:'<div class="empty">No products yet. Start by adding products and a GRN.</div>';
}
function renderVehicle(){
 const rid=activeRepId(),visible=admin()?db.vehicleLedger:db.vehicleLedger.filter(m=>m.repId===rid);
 const repList=db.users.filter(u=>u.role==='rep');
 setOptions('v38Rep',admin()?repList.map(r=>[r.id,r.name+' ('+r.login+')']):[[rid,current()?.name||'My delivery stock']],rid);
 const assigned=admin()?($v('v38Rep')?.value||rid):rid;
 const rows=db.products.filter(p=>assigned&&(vehicleBalance(assigned,p.id)!==0||db.vehicleLedger.some(m=>m.repId===assigned&&m.productId===p.id)));
 $v('v38Table').innerHTML=rows.length?`<table class="ns38-table"><thead><tr><th>Product</th><th>Loaded / Returned</th><th>Sold</th><th>Balance</th></tr></thead><tbody>${rows.map(p=>{const moved=db.vehicleLedger.filter(m=>m.repId===assigned&&m.productId===p.id).reduce((s,m)=>s+(m.kind==='load'?m.qty:-m.qty),0);let bal=vehicleBalance(assigned,p.id);return `<tr><td><b>${safe(p.name)}</b></td><td>${round(moved)}</td><td>${vehicleSold(assigned,p.id)}</td><td><b class="${bal<0?'ns38-warning':''}">${bal}</b></td></tr>`}).join('')}</tbody></table>`:'<div class="empty">No Delivery Stock allocated to this rep yet</div>';
 $v('v38AdminForm').style.display=admin()?'':'none';
 setOptions('v38Product',db.products.map(p=>[p.id,p.name]),$v('v38Product').value);
 $v('v38OnVehicle').textContent=round(db.products.reduce((s,p)=>s+(assigned?vehicleBalance(assigned,p.id):0),0));
 $v('v38VehicleSold').textContent=round(db.products.reduce((s,p)=>s+(assigned?vehicleSold(assigned,p.id):0),0));
 $v('v38Warehouse').textContent=round(db.products.reduce((s,p)=>s+warehouse(p.id),0));
 $v('v38History').innerHTML=visible.length?visible.slice().reverse().slice(0,40).map(m=>`<div class="ns38-list"><div><b>${m.kind==='load'?'Loaded':'Returned'} ${safe(product(m.productId)?.name||'Deleted item')}</b><small>${safe(repName(m.repId))} · ${new Date(m.date).toLocaleString()}</small><small>${safe(m.note||'')}</small></div><b>${m.kind==='load'?'+':'−'}${m.qty}</b></div>`).join(''):'<div class="empty">No stock transfers</div>';
 renderAvailable();
}
function transfer(kind){if(!admin())return toast('Admin only');let repId=$v('v38Rep').value,pid=$v('v38Product').value,qty=dec($v('v38Qty').value);if(!repId||!product(pid))return toast('Select a Sales Rep and Product');if(!(qty>0&&Number.isFinite(qty)))return toast('Enter a valid quantity');if(kind==='load'&&qty>warehouse(pid)+.000001)return toast('Insufficient Wholesale Stock');if(kind==='unload'&&qty>vehicleBalance(repId,pid)+.000001)return toast('Insufficient Delivery Stock');
 const t={id:uid(),date:new Date().toISOString(),repId,productId:pid,kind,qty,note:$v('v38Note').value.trim(),by:current()?.name||'Admin'};db.vehicleLedger.push(t);if(!save()){db.vehicleLedger.pop();return toast('Storage full; nothing saved')} $v('v38Qty').value='';$v('v38Note').value='';render();toast(kind==='load'?'Transferred from Wholesale to Delivery':'Returned to Wholesale Stock');}
function renderCredit(){
 const input=($v('v38CreditSearch')?.value||'').trim().toLowerCase();let list=creditInvoices().filter(ownerInvoice);
 let remaining=list.filter(i=>outstanding(i)>.001);
 let overdue=remaining.filter(i=>i.creditDue&&new Date(i.creditDue+'T23:59:59')<new Date());
 const today=new Date().toDateString();const received=db.creditPayments.filter(p=>new Date(p.date).toDateString()===today&&(admin()||p.repId===current()?.id)).reduce((s,p)=>s+p.amount,0);
 $v('v38DueTotal').textContent=fmt(remaining.reduce((s,i)=>s+outstanding(i),0));$v('v38Overdue').textContent=overdue.length;$v('v38Collected').textContent=fmt(received);
 const rows=list.filter(i=>(i.number+' '+i.customer+' '+i.phone).toLowerCase().includes(input));
 $v('v38CreditTable').innerHTML=rows.length?`<table class="ns38-table"><thead><tr><th>Invoice / Customer</th><th>Outstanding</th><th>Due</th></tr></thead><tbody>${rows.map(i=>`<tr><td><b>${safe(i.number)}</b><small style="display:block">${safe(i.customer||'Walk-in')} · ${new Date(i.date).toLocaleDateString()}</small></td><td>${fmt(outstanding(i))}</td><td><span class="${dueStatus(i)==='Overdue'?'ns38-warning':''}">${safe(dueStatus(i))}</span></td></tr>`).join('')}</tbody></table>`:'<div class="empty">No credit invoices yet</div>';
 const selectable=remaining;setOptions('v38CreditInvoice',selectable.map(i=>[i.id,i.number+' · '+(i.customer||'Walk-in')+' · '+fmt(outstanding(i))]),$v('v38CreditInvoice')?.value);
 $v('v38Payments').innerHTML=db.creditPayments.filter(p=>admin()||p.repId===current()?.id).slice().reverse().slice(0,60).map(p=>`<div class="ns38-list"><div><b>${safe(p.invoiceNo||'Invoice')} · ${safe(p.customer||'')}</b><small>${new Date(p.date).toLocaleString()} · ${safe(p.method)} · ${safe(p.by||'')}</small><small>${safe(p.reference||'')}</small></div><b>${fmt(p.amount)}</b></div>`).join('')||'<div class="empty">No repayments recorded</div>';
 renderAvailable();
}
function collect(){if(!current())return toast('Sign in first');let inv=db.invoices.find(i=>i.id===$v('v38CreditInvoice')?.value),a=dec($v('v38PayAmount').value);if(!inv||!ownerInvoice(inv))return toast('Select a permitted invoice');if(!Number.isFinite(a)||a<=0||a>outstanding(inv)+.00001)return toast('Amount must be within outstanding balance');if(!confirm('Record '+fmt(a)+' received for invoice '+inv.number+'?'))return;
 const oldPaid=inv.paid;inv.paid=round(dec(inv.paid)+a);inv.balance=round(dec(inv.total)-dec(inv.paid));const record={id:uid(),date:new Date().toISOString(),invoiceId:inv.id,invoiceNo:inv.number,customer:inv.customer,amount:a,method:$v('v38PayMethod').value,reference:$v('v38PayReference').value.trim(),repId:current()?.id||'',by:current()?.name||'Administrator'};
 db.creditPayments.push(record);if(!save()){db.creditPayments.pop();inv.paid=oldPaid;inv.balance=round(dec(inv.total)-dec(inv.paid));return toast('Storage full; payment was not recorded')}
 $v('v38PayAmount').value='';$v('v38PayReference').value='';render();toast('Payment recorded');}
function closingData(){const day=$v('v38ClosingDate')?.value,rep=$v('v38ClosingRep')?.value;const same=d=>d&&new Date(d).toLocaleDateString('en-CA')===day;
 const inv=db.invoices.filter(i=>i.repId===rep&&same(i.date)),s=inv.reduce((a,i)=>a+dec(i.total),0),col=db.creditPayments.filter(p=>p.repId===rep&&same(p.date)),credit=col.reduce((a,p)=>a+p.amount,0),ret=(db.returns||[]).filter(r=>same(r.date)&&inv.some(i=>i.id===r.invoiceId)),ref=ret.reduce((a,r)=>a+dec(r.refund),0);
 return {date:day,repId:rep,repName:repName(rep),invoiceCount:inv.length,sales:round(s),collections:round(credit),returns:round(ref),netSales:round(s-ref),vehicleCount:round(db.products.reduce((a,p)=>a+vehicleBalance(rep,p.id),0))};}
function renderClosing(){const repId=current()?.id||'';setOptions('v38ClosingRep',admin()?db.users.map(u=>[u.id,u.name]):[[repId,current()?.name||'My account']],$v('v38ClosingRep')?.value);
 const r=closingData();$v('v38ClosingSummary').innerHTML=`<div class="ns38-kpis"><div><span>Invoices</span><b>${r.invoiceCount}</b></div><div><span>Sales</span><b>${fmt(r.sales)}</b></div><div><span>Credit collections</span><b>${fmt(r.collections)}</b></div><div><span>Sales returns</span><b>${fmt(r.returns)}</b></div><div><span>Net sales</span><b>${fmt(r.netSales)}</b></div><div><span>Delivery balance Qty</span><b>${r.vehicleCount}</b></div></div>`;
 $v('v38ClosingHistory').innerHTML=db.repClosings.filter(x=>admin()||x.repId===repId).slice().reverse().slice(0,30).map(x=>`<div class="ns38-list"><div><b>${safe(x.repName)} · ${safe(x.date)}</b><small>Sales ${fmt(x.netSales)} · Invoices ${x.invoiceCount}</small></div><span class="ns38-pill">Saved</span></div>`).join('')||'<div class="empty">No closing reports yet</div>';}
function closeDay(){if(!current())return toast('Sign in first');const r=closingData();if(!r.repId)return toast('Select rep');if(db.repClosings.some(x=>x.repId===r.repId&&x.date===r.date))return toast('Closing report already saved for this date');if(!confirm('Save closing report for '+r.repName+' / '+r.date+'?'))return;db.repClosings.push({...r,id:uid(),savedAt:new Date().toISOString(),savedBy:current()?.name});if(!save()){db.repClosings.pop();return toast('Could not save closing')}renderClosing();toast('Daily closing saved');}
function downloadClosing(){let r=closingData();if(!r.repId)return toast('Select a Rep');let rows=[['Date','Sales Rep','Invoices','Total Sales','Collections','Returns','Net Sales','Delivery Qty'],[r.date,r.repName,r.invoiceCount,r.sales,r.collections,r.returns,r.netSales,r.vehicleCount]];let csv=rows.map(row=>row.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n');let a=document.createElement('a'),u=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.href=u;a.download='rep-closing-'+r.date+'.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000)}
function render(){if(!$v('delivery'))return;ensure();renderWholesale();renderVehicle();renderCredit();renderClosing();dueVisibility()}
const previousRender=renderAll;renderAll=function(){previousRender();render()};
const previousSave=saveInvoice;
saveInvoice=function(){let mode=$v('iMode')?.value,cart=invoiceCart.map(l=>({...l}));let user=current(),repId=user?.id||'',isRep=user?.role==='rep';const sales=new Map();
 if(mode==='stock'&&isRep){for(const line of cart){sales.set(line.productId,round((sales.get(line.productId)||0)+dec(line.qty)))}for(const [pid,q] of sales){if(q>vehicleBalance(repId,pid)+.000001)return toast('Delivery stock insufficient: '+(product(pid)?.name||'Product'))}}
 // Never sell delivery-allocated goods from wholesale.
 if(mode==='stock'&&!isRep){for(const line of cart){sales.set(line.productId,round((sales.get(line.productId)||0)+dec(line.qty)))}for(const [pid,q] of sales){if(q>warehouse(pid)+.000001)return toast('Wholesale stock insufficient: '+(product(pid)?.name||'Product'))}}
 const due=$v('v38DueDate')?.value||'';const count=db.invoices.length;previousSave();if(db.invoices.length===count)return;
 const inv=db.invoices[0];if(inv.payment==='Credit')inv.creditDue=due;
 if(mode==='stock'&&isRep)inv.vehicleRepId=repId;
 save();render();};
// Delivery balance derives from allocations minus confirmed delivery sales.
// Negative balances are surfaced in red rather than silently changing transfers.
install();render();
window.NS38={render,renderWholesale,renderCredit,renderClosing,renderAvailable,transfer,collect,closeDay,downloadClosing};
})();