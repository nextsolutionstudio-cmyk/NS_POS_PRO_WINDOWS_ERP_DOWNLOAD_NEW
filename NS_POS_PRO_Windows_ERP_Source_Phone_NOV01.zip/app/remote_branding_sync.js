/* NS POS PRO remote branding v2: Owner-controlled per-tenant sync + visible diagnostics.
   Never alters bills, products, stock, staff or any other POS data. */
(()=>{'use strict';
 const SESSION='nspos_cloud_v1_daily_session';
 const KEY='nspos_owner_branding_revision_v1_';
 const DETAIL_KEYS=['name','phone','phone2','phone3','address','email','website','logo'];
 let lastAttempt=0,inFlight=false,latestError='',lastSuccessfulTenant='';
 const el=id=>document.getElementById(id);
 const tenant=()=>{try{return String(JSON.parse(localStorage.getItem(SESSION)||'null')?.auth?.tenant?.id||'')}catch(_){return ''}};
 const safeErr=err=>{const msg=String(err?.message||err||'Unknown error');return msg.slice(0,220)};
 const status=(message,good=false)=>{
  const e=el('nsBrandStatus');if(e){e.textContent=message;e.style.color=good?'#08734a':'#9b3c20'}
 };
 const currentValues=brand=>({
  name:brand.name,phone:brand.phone??'',phone2:brand.phone2??'',phone3:brand.phone3??'',
  address:brand.address??'',email:brand.email??'',website:brand.website??'',logo:brand.logo_data??''
 });
 async function pull(force=false){
  if(inFlight){status('Business details sync already in progress…');return false}
  const code=tenant();
  if(!code){status('Customer Cloud Login required. Sign in to the correct business, then Refresh.');return false}
  if(!window.NSCloud||typeof window.NSCloud.repCall!=='function'){
   status('This Customer APK has no Cloud Login module. Update the Customer APK.');return false
  }
  if(!force && Date.now()-lastAttempt<45000)return false;
  if(!navigator.onLine){status('Phone is offline. Connect to the Internet and Refresh.');return false}
  lastAttempt=Date.now();inFlight=true;latestError='';status('Checking Cloud business '+code+'…');
  const btn=el('nsBrandSync');if(btn)btn.disabled=true;
  try{
   let data;
   try{data=await window.NSCloud.repCall('/v1/business/remote-config')}
   catch(err){
    if(!/404|Route not found|Not Found/i.test(String(err?.message||err)))throw err;
    data=await window.NSCloud.repCall('/v1/business/branding');
   }
   if(window.NSSeasonalUI)window.NSSeasonalUI.apply(data.visuals||{effect:'none',enabled:false});
   if(tenant()!==code)throw Error('Business account changed during sync. Sign in and retry.');
   // Keep older Cloudflare branding until Owner publishes a new remote configuration.
   if(!data?.branding && Number(data?.revision||0)===0){
    try{const legacy=await window.NSCloud.repCall('/v1/business/branding');if(legacy?.branding)data={...data,branding:legacy.branding}}
    catch(_){/* No old branding available; visuals are still valid. */}
   }
   const brand=data?.branding;
   const cloudRevision=Number(data?.revision||brand?.revision||0);
   if(!brand||!Number.isFinite(cloudRevision)||cloudRevision<1){
    status('✓ Visual effects synced · Business '+code+' · No branding saved yet',true);return true;
   }
   if(typeof brand.name!=='string'||!brand.name.trim())throw Error('Cloud branding has no business name');
   if(typeof db==='undefined'||!db?.settings||typeof save!=='function')throw Error('Customer POS database is not ready');
   const vals=currentValues(brand);
   const revision=cloudRevision,previousRev=Number(localStorage.getItem(KEY+code)||0);
   // Even at the same revision, re-apply if a local backup/reset/setting overwrote branding.
   const dirty=DETAIL_KEYS.some(k=>String(db.settings[k]??'')!==String(vals[k]??''));
   if(!dirty){
    localStorage.setItem(KEY+code,String(revision));lastSuccessfulTenant=code;
    status('✓ Up to date · Business '+code+' · Cloud revision '+revision+' · No changes needed',true);
    return true;
   }
   const original=Object.fromEntries(DETAIL_KEYS.map(k=>[k,db.settings[k]]));
   DETAIL_KEYS.forEach(k=>{db.settings[k]=String(vals[k]??'')});
   if(!save()){
    DETAIL_KEYS.forEach(k=>{db.settings[k]=original[k]});
    throw Error('Phone storage is full. Backup your data and free space; no settings were changed.');
   }
   // Revision marker is written *after* successful data save.
   try{localStorage.setItem(KEY+code,String(revision))}catch(_){}
   lastSuccessfulTenant=code;
   if(typeof renderSettings==='function')renderSettings();
   const header=el('appBusinessName');if(header)header.textContent=db.settings.name;
   // Never rewrite invoices: historic receipt snapshots must remain unchanged.
   status('✓ Updated '+code+' · Cloud revision '+revision+' (was '+previousRev+') · Name, logo and contact saved',true);
   if(force&&typeof toast==='function')toast('Owner business details updated from Cloud');
   return true;
  }catch(err){
   latestError=safeErr(err);
   let tip='';
   if(/Route not found|404/i.test(latestError))tip=' · Deploy Customer Branding route in Cloudflare Worker.';
   else if(/401|403|token|login|sign.in|verification|session/i.test(latestError))tip=' · Log in again to Customer Cloud.';
   else if(/Storage|quota/i.test(latestError))tip=' · Check phone storage and backup.';
   status('✕ Sync failed for '+code+': '+latestError+tip);
   return false;
  }finally{inFlight=false;if(btn)btn.disabled=false}
 }
 function install(){
  const settings=el('settings');if(!settings)return;
  let panel=el('nsRemoteBrandingPanel');
  if(!panel){
   panel=document.createElement('div');panel.id='nsRemoteBrandingPanel';panel.className='panel';
   panel.innerHTML='<h2>☁ Owner Business Details Sync</h2><p class="hint">Business name, logo, phones, email, address and website are controlled by the Developer Owner. Internet and Customer Cloud Login are required.</p><p id="nsBrandStatus" role="status" style="font-size:13px;line-height:1.5;overflow-wrap:anywhere">Checking Cloud Login…</p><button type="button" class="secondary" id="nsBrandSync">↻ Refresh Business Details Now</button>';
   settings.appendChild(panel)
  }
  const btn=el('nsBrandSync');if(btn)btn.addEventListener('click',()=>{lastAttempt=0;void pull(true)});
  const code=tenant();status(code?'Business '+code+' · Press Refresh to check Cloud.':'Customer Cloud Login required.');
  setTimeout(()=>void pull(),5500)
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 setTimeout(()=>void pull(),13000);
 setInterval(()=>{if(!document.hidden)void pull()},90000);
 window.addEventListener('online',()=>{lastAttempt=0;void pull()});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){lastAttempt=0;void pull()}});
 window.NSRemoteBranding={sync:()=>{lastAttempt=0;return pull(true)},status:()=>({business:tenant(),lastSuccessfulTenant,error:latestError})};
})();
