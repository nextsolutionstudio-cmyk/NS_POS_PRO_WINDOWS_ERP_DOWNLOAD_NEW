/* NS POS PRO organized UI: non-destructive visual grouping + device-only sales summaries.
   No schema change, no inventory mutation, no billing function replacement. */
(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  const STRINGS={
    en:{filter:'Browse by category',all:'All',bill:'Billing',stock:'Stock',rep:'Sales reps',management:'Management',customer:'Customer details',customerSub:'Shop, phone and bill type',items:'Add products',itemsSub:'Select items and quantities',pay:'Payment & notes',paySub:'Choose payment and add optional notes',finish:'Total & save',finishSub:'Review before saving or printing',identity:'Product identity',identitySub:'Name, SKU / barcode',pricing:'Prices & inventory',pricingSub:'Cost, selling price and alerts',receiving:'Supplier & received stock',receivingSub:'Receive quantities and costs',sales:'Sales summary',deviceOnly:'From bills saved on this device only · excludes voided bills · not the complete cloud business report',daily:'Daily',monthly:'Monthly',yearly:'Yearly',gross:'Total sales',bills:'Bills',cash:'Cash sales',credit:'Credit sales'},
    si:{filter:'කාර්යය අනුව බලන්න',all:'සියල්ල',bill:'බිල්පත්',stock:'තොග',rep:'අලෙවි නියෝජිත',management:'කළමනාකරණය',customer:'පාරිභෝගික විස්තර',customerSub:'කඩේ, දුරකථන, බිල් වර්ගය',items:'භාණ්ඩ එක් කරන්න',itemsSub:'භාණ්ඩ සහ ප්‍රමාණ තෝරන්න',pay:'ගෙවීම් සහ සටහන්',paySub:'ගෙවීම් ක්‍රමය සහ අවශ්‍ය නම් සටහන්',finish:'එකතුව සහ සුරැකීම',finishSub:'සුරැකීමට පෙර පරීක්ෂා කරන්න',identity:'භාණ්ඩ හඳුනාගැනීම',identitySub:'නම, SKU / බාර්කෝඩ්',pricing:'මිල සහ තොග',pricingSub:'මිලදී ගැනීමේ මිල, විකුණුම් මිල, ඇඟවීම්',receiving:'සැපයුම් සහ ලැබුණු තොග',receivingSub:'ප්‍රමාණය සහ මිල',sales:'විකුණුම් සාරාංශය',deviceOnly:'මෙම දුරකථනයේ සුරැකි බිල්පත් පමණි · අවලංගු බිල්පත් නැත · සම්පූර්ණ Cloud වාර්තාවක් නොවේ',daily:'දෛනික',monthly:'මාසික',yearly:'වාර්ෂික',gross:'මුළු විකුණුම්',bills:'බිල්පත්',cash:'මුදල් විකුණුම්',credit:'ණය විකුණුම්'},
    ta:{filter:'பிரிவின்படி பார்க்க',all:'அனைத்தும்',bill:'பில்கள்',stock:'இருப்பு',rep:'விற்பனை பிரதிநிதிகள்',management:'நிர்வாகம்',customer:'வாடிக்கையாளர் விவரங்கள்',customerSub:'கடை, தொலைபேசி மற்றும் பில் வகை',items:'பொருட்களைச் சேர்க்க',itemsSub:'பொருட்களையும் அளவையும் தேர்ந்தெடுக்கவும்',pay:'கட்டணம் மற்றும் குறிப்புகள்',paySub:'கட்டண முறை மற்றும் விருப்பக் குறிப்பு',finish:'மொத்தம் மற்றும் சேமிப்பு',finishSub:'சேமிப்பதற்கு முன் சரிபார்க்கவும்',identity:'பொருள் அடையாளம்',identitySub:'பெயர், SKU / பார்கோடு',pricing:'விலை மற்றும் இருப்பு',pricingSub:'கொள்முதல், விற்பனை விலை, எச்சரிக்கை',receiving:'விநியோகஸ்தர் மற்றும் சரக்கு',receivingSub:'அளவு மற்றும் செலவு',sales:'விற்பனைச் சுருக்கம்',deviceOnly:'இந்த சாதனத்தில் சேமித்த பில்கள் மட்டும் · ரத்து செய்யப்பட்டவை தவிர்க்கப்படும் · முழு Cloud அறிக்கை அல்ல',daily:'தினசரி',monthly:'மாதாந்திர',yearly:'ஆண்டு',gross:'மொத்த விற்பனை',bills:'பில்கள்',cash:'பண விற்பனை',credit:'கடன் விற்பனை'}
  };
  let group='all',period='daily';
  function lang(){try{const v=window.NSLang?.get?.()||localStorage.getItem('nspos_ui_lang');return STRINGS[v]?v:'en'}catch(_){return 'en'}}
  function t(key){return STRINGS[lang()][key]||STRINGS.en[key]||key}
  function el(tag,cls,txt){const x=document.createElement(tag);if(cls)x.className=cls;if(txt!==undefined)x.textContent=txt;return x}
  const labels=[];
  function insertHeading(anchor,icon,key,detail,step){
    if(!anchor||!anchor.parentNode)return;
    const h=el('div','ns-flow-heading');if(step)h.dataset.step=step;
    h.append(el('span','ns-flow-step',icon));const div=el('div');const title=el('strong');const subtitle=el('small');
    div.append(title,subtitle);h.append(div);anchor.parentNode.insertBefore(h,anchor);
    labels.push(()=>{title.textContent=t(key);subtitle.textContent=t(detail)});
  }
  function organizeInvoice(){
    const root=$('invoice');if(!root)return;
    const panel=root.querySelector('.panel');if(!panel||panel.dataset.nsOrganized)return;
    panel.dataset.nsOrganized='1';
    const customer=$('iCustomer')?.closest('.row');
    const product=$('iProduct')?.closest('.row');
    const discount=$('iDiscount')?.closest('.row');
    const grand=panel.querySelector('.grand');
    // Existing module preserves the canonical #iPayment select, so move only its visible card.
    const payment=panel.querySelector('.ns-payment-stable-section');
    const note=$('iPaymentNote')?.closest('.field');
    if(payment&&note&&note.parentNode===panel)panel.insertBefore(payment,note);
    insertHeading(customer,'👤','customer','customerSub','customer');
    insertHeading(product,'📦','items','itemsSub','items');
    insertHeading(discount,'💳','pay','paySub','pay');
    insertHeading(grand,'✅','finish','finishSub','complete');
  }
  function organizeInventory(){
    const products=$('products')?.querySelector('.panel');
    if(products){
      insertHeading($('pName')?.closest('.row'),'🏷️','identity','identitySub');
      insertHeading($('pCost')?.closest('.row'),'💰','pricing','pricingSub');
    }
    const grn=$('grn')?.querySelector('.panel');if(grn)insertHeading($('grnSupplier')?.closest('.row'),'📥','receiving','receivingSub');
  }
  function tileGroup(button){
    const action=button.getAttribute('onclick')||'';
    const name=(button.textContent||'').toLowerCase();
    if(/invoice|orders|history|returns|cheques/.test(action))return'bill';
    if(/products|grn|vehicle/.test(action))return'stock';
    if(/team|repclosing|rep|credit/.test(action))return'rep';
    if(/settings|update|admin/.test(action))return'management';
    if(/shops/.test(action))return'rep';
    if(/invoice|bills/.test(name))return'bill';
    return'management';
  }
  function applyFilter(){const holder=document.querySelector('#dashboard .ns31-shortcuts');if(!holder)return;
    [...holder.querySelectorAll(':scope > button')].forEach(b=>b.classList.toggle('ns-organize-hidden',group!=='all'&&tileGroup(b)!==group));
    document.querySelectorAll('.ns-organize-filter button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.group===group)));
  }
  function createFilter(){
    const holder=document.querySelector('#dashboard .ns31-shortcuts');if(!holder)return;
    const toolbar=el('div','ns-organize-toolbar');toolbar.append(el('div','ns-organize-caption'));
    const tabs=el('div','ns-organize-filter');tabs.setAttribute('role','group');
    for(const [key,emoji] of [['all','✨'],['bill','🧾'],['stock','📦'],['rep','🚚'],['management','⚙️']]){
      const b=el('button');b.type='button';b.dataset.group=key;b.addEventListener('click',()=>{group=key;applyFilter()});tabs.append(b);
      labels.push(()=>{b.textContent=emoji+' '+t(key)});
    }
    toolbar.append(tabs);holder.parentNode.insertBefore(toolbar,holder);
    labels.push(()=>{toolbar.querySelector('.ns-organize-caption').textContent='🗂️ '+t('filter')});
    applyFilter();
    const observer=new MutationObserver(entries=>{if(entries.some(e=>e.addedNodes.length))applyFilter()});
    observer.observe(holder,{childList:true});
  }
  function localInvoices(){try{return (typeof db!=='undefined'&&Array.isArray(db?.invoices))?db.invoices:[]}catch(_){return[]}}
  function activePeriod(date,now){
    if(!Number.isFinite(date.getTime()))return false;
    if(period==='daily')return date.getFullYear()===now.getFullYear()&&date.getMonth()===now.getMonth()&&date.getDate()===now.getDate();
    if(period==='monthly')return date.getFullYear()===now.getFullYear()&&date.getMonth()===now.getMonth();
    return date.getFullYear()===now.getFullYear();
  }
  function amount(n){return 'Rs. '+(Number(n)||0).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2})}
  let reportBox;
  function renderReport(){if(!reportBox)return;const now=new Date();
    const bills=localInvoices().filter(x=>x&&!x.voidedAt&&activePeriod(new Date(x.date),now));
    const total=bills.reduce((sum,x)=>sum+(Number(x.total)||0),0);
    const cash=bills.filter(x=>String(x.payment).toLowerCase()==='cash').reduce((sum,x)=>sum+(Number(x.total)||0),0);
    const credit=bills.filter(x=>String(x.payment).toLowerCase()==='credit').reduce((sum,x)=>sum+(Number(x.total)||0),0);
    const values=[amount(total),String(bills.length),amount(cash),amount(credit)];
    [...reportBox.querySelectorAll('.ns-report-metric strong')].forEach((x,i)=>x.textContent=values[i]);
    [...reportBox.querySelectorAll('.ns-report-periods button')].forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.period===period)));
  }
  function createReport(){const dashboard=$('dashboard');const grid=dashboard?.querySelector('.ns31-bottom-grid');if(!dashboard||!grid)return;
    reportBox=el('section','ns-device-report');
    const top=el('div','ns-report-title');const heading=el('span');top.append(heading);reportBox.append(top);
    const caption=el('p','ns-report-caption');reportBox.append(caption);
    const controls=el('div','ns-report-periods');controls.setAttribute('role','group');
    for(const key of ['daily','monthly','yearly']){
      const button=el('button');button.type='button';button.dataset.period=key;button.addEventListener('click',()=>{period=key;renderReport()});controls.append(button);
      labels.push(()=>button.textContent=t(key));
    }
    reportBox.append(controls);
    const stats=el('div','ns-report-metrics');for(const key of ['gross','bills','cash','credit']){
      const item=el('div','ns-report-metric');const label=el('small');const value=el('strong','',key==='bills'?'0':'Rs. 0.00');item.append(label,value);stats.append(item);
      labels.push(()=>label.textContent=t(key));
    }
    reportBox.append(stats);grid.parentNode.insertBefore(reportBox,grid);
    labels.push(()=>{heading.textContent='📊 '+t('sales');caption.textContent=t('deviceOnly')});
    // This is deliberately a local-device report; cloud-wide admin totals require server aggregation.
    dashboard.addEventListener('click',()=>queueMicrotask(renderReport));
    renderReport();
  }
  function translate(){labels.forEach(fn=>fn());renderReport()}
  function boot(){if($('nsOrganizedLoaded'))return;
    const marker=el('span');marker.id='nsOrganizedLoaded';marker.hidden=true;document.body.append(marker);
    organizeInvoice();organizeInventory();createFilter();createReport();translate();
    $('nsLangSelect')?.addEventListener('change',()=>setTimeout(translate,0));
    document.addEventListener('click',e=>{
      if(e.target.closest('[data-page="dashboard"]')||e.target.closest('[onclick*="dashboard"]'))setTimeout(renderReport,0);
    });
  }
  if(document.readyState==='loading')window.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
