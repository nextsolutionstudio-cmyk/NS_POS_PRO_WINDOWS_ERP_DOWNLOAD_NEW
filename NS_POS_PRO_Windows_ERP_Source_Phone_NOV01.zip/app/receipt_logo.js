/* NS POS PRO Lifetime v2.5 — Show / Hide receipt logo.
   Shop branding logo stays saved when receipt logo is switched off. */
(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const setting = () => db.settings.receiptLogo !== false;
  function syncLogo() {
    // Receipt preview and system/PDF print use separate containers.
    ['receiptPreview', 'printZone'].forEach(id => {
      const root = byId(id);
      if (!root) return;
      // Uploaded business logo is an img inside the receipt heading.
      root.querySelectorAll('.invoice-paper > .center img').forEach(img => {
        img.style.display = setting() ? '' : 'none';
      });
    });
  }
  function persist(on) {
    db.settings.receiptLogo = !!on;
    save();
    const state = byId('ns25ReceiptLogoState');
    if (state) state.textContent = on ? 'ON — Logo on receipt/JPG' : 'OFF — No logo on receipt/JPG';
    syncLogo();
    toast(on ? 'Bill logo enabled' : 'Bill logo removed (business logo saved)');
  }
  function createControl() {
    const logo = byId('sLogo');
    if (!logo || byId('ns25ReceiptLogoToggle')) return;
    const preview = byId('logoPreview');
    const row = document.createElement('div');
    row.id = 'ns25LogoSettings';
    row.style.cssText = 'background:var(--bg);padding:13px;border:1px solid var(--line);border-radius:12px;margin:10px 0 13px';
    const label = document.createElement('label');
    label.style.cssText = 'display:flex;gap:12px;align-items:center;cursor:pointer;font-weight:750';
    const checkbox = document.createElement('input');
    checkbox.id = 'ns25ReceiptLogoToggle';
    checkbox.type = 'checkbox'; checkbox.checked = setting();
    checkbox.style.cssText = 'width:23px;height:23px;accent-color:var(--blue);flex:0 0 auto';
    const title = document.createElement('span'); title.textContent = 'Print business logo on bill / JPG';
    label.append(checkbox,title);
    const state = document.createElement('p');state.id = 'ns25ReceiptLogoState';
    state.className = 'hint';
    state.textContent = checkbox.checked ? 'ON — Logo on receipt/JPG' : 'OFF — No logo on receipt/JPG';
    const hint = document.createElement('p');hint.className='hint';
    hint.textContent = 'Switch OFF to hide the logo only on bills; your uploaded business logo is kept for later.';
    const remove = document.createElement('button');
    remove.type='button'; remove.className='danger sm'; remove.textContent='Delete current uploaded logo';
    remove.onclick = () => {
      if (!db.settings.logo) return toast('No logo saved');
      if (!confirm('Delete the current uploaded business logo? Past invoices can retain a historical copy.')) return;
      db.settings.logo='';save();
      logo.value=''; if (preview){preview.src='';preview.style.display='none';}
      toast('Business logo removed');syncLogo();
    };
    checkbox.addEventListener('change', () => persist(checkbox.checked));
    row.append(label,state,hint,remove);
    (preview || logo).after(row);
  }
  // The upgrade layer augments the receipt with Sales Rep and cheque lines.
  // Wrap it after upgrade.js so our option controls the finished output.
  const oldPreview = window.showPreview;
  window.showPreview = function (...args) {
    const result = oldPreview.apply(this,args);
    syncLogo();
    return result;
  };
  createControl();
  syncLogo();
  const priorRenderSettings=window.renderSettings;
  if(typeof priorRenderSettings==='function') window.renderSettings=function(...args){
    const r=priorRenderSettings.apply(this,args);
    const checkbox=byId('ns25ReceiptLogoToggle');
    if(checkbox)checkbox.checked=setting();
    const state=byId('ns25ReceiptLogoState');
    if(state)state.textContent=setting()?'ON — Logo on receipt/JPG':'OFF — No logo on receipt/JPG';
    return r;
  };
})();
