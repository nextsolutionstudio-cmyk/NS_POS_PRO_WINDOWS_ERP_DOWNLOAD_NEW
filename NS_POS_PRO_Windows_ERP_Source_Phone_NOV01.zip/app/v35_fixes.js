/* NS POS PRO v3.5.1 – user-facing workflow improvements. No subscription checks. */
(() => {
'use strict';
const $=id=>document.getElementById(id), escTxt=s=>String(s??''), html=s=>esc(escTxt(s));
const currency=n=>Number(n||0).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2});
const safeFile=s=>String(s||'Bill').replace(/[^A-Za-z0-9_-]/g,'_').slice(0,55);
const unitNames=['g','kg','mg','ml','L','pcs','dozen','pack','box','bottle','bag','m','cm','mm'];

// Shared JPG file workflow: never substitute a WhatsApp text message for the invoice/order image.
async function sendJpg(name,dataUrl){
  if(window.AndroidPrinter?.shareJpeg){window.AndroidPrinter.shareJpeg(name,dataUrl);return;}
  if(window.NSDesktop?.shareJpg){let r=await window.NSDesktop.shareJpg(name,dataUrl);
    if(r?.copied){toast('JPG copied. Open the WhatsApp chat and press Ctrl+V.');return;}
    if(r?.error)throw Error(r.error);
  }
  const resp=await fetch(dataUrl),blob=await resp.blob(),file=new File([blob],name,{type:'image/jpeg'});
  if(navigator.share && navigator.canShare?.({files:[file]})){
    try{await navigator.share({files:[file],title:name});return;}
    catch(e){if(e.name==='AbortError')return;}
  }
  const u=URL.createObjectURL(blob),link=document.createElement('a');link.href=u;link.download=name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(u),10000);
  toast('JPG saved. Attach this JPG in WhatsApp.');
}

// Invoice button supplied by v3.4: switch the handler from WhatsApp URL text to a real image.
const invoiceBtn=$('ns34ShareInvoiceWhatsApp');
if(invoiceBtn){invoiceBtn.textContent='🟢 WhatsApp JPG';invoiceBtn.onclick=async()=>{
  const inv=previewInvoice;
  if(!inv||!db.invoices.some(i=>i.id===inv.id))return toast('Save the invoice before sharing');
  invoiceBtn.disabled=true;try{const jpg=await window.NS35_makeInvoiceJpg(inv);await sendJpg('Invoice-'+safeFile(inv.number)+'.jpg',jpg)}
  catch(e){toast('WhatsApp JPG error: '+e.message)}finally{invoiceBtn.disabled=false}
};}

// Move Sales Rep from footer to directly after Payment Method on both receipt previews.
const priorPreview=showPreview;
showPreview=function(saved){priorPreview(saved);const inv=previewInvoice;if(!inv)return;
  for(const id of ['receiptPreview','printZone']){
    const paper=$(id)?.querySelector('.invoice-paper');if(!paper)continue;
    const extras=paper.querySelector('.ns2-receipt-detail');
    if(extras){for(const d of Array.from(extras.children)){if((d.textContent||'').trim().startsWith('Sales Rep:'))d.remove()}
      if(!extras.children.length)extras.remove();}
    const paymentNode=[...paper.querySelectorAll('div')].find(d=>[...d.childNodes].some(n=>n.nodeType===Node.TEXT_NODE&&n.textContent.trim().startsWith('Payment:')));
    if(paymentNode&&inv.rep){const rep=document.createElement('div');rep.className='ns35-rep';rep.textContent='Sales Rep: '+inv.rep;paymentNode.insertAdjacentElement('afterend',rep);}
    const subtotal=[...paper.querySelectorAll('div')].find(d=>[...d.childNodes].some(n=>n.nodeType===Node.TEXT_NODE&&n.textContent.trim().startsWith('Subtotal:')));
    if(subtotal)subtotal.style.fontWeight='900';
  }
};

// Saved order JPG with proper item quantities, delivery details, status and optional prices.
function orderJpg(order){
 const width=600, margin=32, ctx=document.createElement('canvas').getContext('2d');
 const entries=[];
 const wrap=(str,size=20,bold=false)=>{ctx.font=(bold?'bold ':'')+size+'px Arial, sans-serif';const words=String(str??'').split(/\s+/);let line='';const out=[];
 for(const word of words){let test=line?line+' '+word:word;if(ctx.measureText(test).width<width-2*margin){line=test;continue}if(line)out.push(line);line=word;if(ctx.measureText(line).width>width-2*margin){let acc='';for(const c of [...line]){if(ctx.measureText(acc+c).width>width-2*margin){out.push(acc);acc=''}acc+=c}line=acc}}if(line)out.push(line);return out.length?out:['']};
 const txt=(s,size=20,bold=false,align='left')=>wrap(s,size,bold).forEach(text=>entries.push({type:'text',text,size,bold,align,height:size+13}));
 const line=()=>entries.push({type:'rule',height:20});const space=h=>entries.push({type:'space',height:h});
 const business=db.settings||{};
 txt(business.name||'NS POS PRO',31,true,'center');txt('CUSTOMER ORDER',26,true,'center');line();
 txt('Order: '+order.number,21,true);txt('Date: '+new Date(order.date||Date.now()).toLocaleString(),18);
 txt('Shop: '+order.shop,22,true);if(order.phone)txt('Phone: '+order.phone,18);
 if(order.address)txt('Address: '+order.address,19);
 if(order.needBy)txt('Required: '+order.needBy,19);
 txt('Status: '+(order.status||'Pending'),20,true);if(order.deliveredAt)txt('Delivered: '+new Date(order.deliveredAt).toLocaleString(),17);
 line();txt('ORDER ITEMS',20,true);let sum=0,priced=0;
 for(let i=0;i<(order.lines||[]).length;i++){let item=order.lines[i];txt((i+1)+'. '+(item.name||'Item'),21,true);let q=Number(item.qty||0),p=Number(item.price||0);txt('Qty: '+q+' '+(item.unit||'pcs')+(p>0?'    Rs. '+currency(q*p):''),18);if(p>0){sum+=q*p;priced++}space(5)}
 line();if(priced)txt('ORDER VALUE: Rs. '+currency(sum),23,true,'right');if(order.notes)txt('Notes: '+order.notes,18);
 if(order.rep)txt('Sales Rep: '+order.rep,18);line();txt('© Next Solution Studio · All rights reserved.',14,false,'center');space(18);
 const height=36+entries.reduce((n,e)=>n+e.height,0);const canvas=ctx.canvas,scale=2;
 canvas.width=width*scale;canvas.height=height*scale;const c=canvas.getContext('2d');c.scale(scale,scale);c.fillStyle='white';c.fillRect(0,0,width,height);let y=26;
 for(const e of entries){if(e.type==='space'){y+=e.height;continue}if(e.type==='rule'){c.strokeStyle='#777';c.setLineDash([5,4]);c.beginPath();c.moveTo(margin,y+10);c.lineTo(width-margin,y+10);c.stroke();c.setLineDash([]);y+=e.height;continue}
 c.fillStyle='#151515';c.textBaseline='top';c.font=(e.bold?'bold ':'')+e.size+'px Arial, sans-serif';c.textAlign=e.align;c.fillText(e.text,e.align==='center'?width/2:e.align==='right'?width-margin:margin,y);y+=e.height}
 return canvas.toDataURL('image/jpeg',.94);
}
window.NS35_makeOrderJpg=orderJpg;

// Add an optional price beside order entry; the core Orders editor reads
// this field directly, then saves the amount in the order record.
const orderAdd=$('ns33OrderAdd');if(orderAdd){
 const row=$('ns33OrderUnit')?.closest('.row');
 if(row&&!$('ns35OrderPrice')){
  const field=document.createElement('div');field.className='field';
  field.innerHTML='<label>Rate (optional)</label><input id="ns35OrderPrice" type="number" min="0" step="0.01" value="0">';
  row.append(field);
 }
}

// Replace order text URL event bindings each time list refreshes, keep Edit and status functional.
const history=$('ns33OrderHistory');if(history){const observer=new MutationObserver(()=>{
 for(const b of history.querySelectorAll('button[data-order-share]')){
  if(b.dataset.ns35==='yes')continue;b.dataset.ns35='yes';b.textContent='🟢 Share JPG';
  b.addEventListener('click',async event=>{event.stopImmediatePropagation();const o=db.orders.find(x=>x.id===b.dataset.orderShare);if(!o)return;
   b.disabled=true;try{await sendJpg('Order-'+safeFile(o.number)+'.jpg',orderJpg(o))}catch(e){toast('Order share error: '+e.message)}finally{b.disabled=false}
  },true);
 }
 for(const s of history.querySelectorAll('select[data-order-status]')){
  if(s.dataset.ns35==='yes')continue;s.dataset.ns35='yes';s.addEventListener('change',()=>{const o=db.orders.find(x=>x.id===s.dataset.orderStatus);
   if(!o)return;if(s.value==='Delivered'){o.deliveredAt=new Date().toISOString();o.deliveredBy=(typeof NS2_USER!=='undefined'?NS2_USER?.name:'')||'Sales Rep'}
   else {delete o.deliveredAt;delete o.deliveredBy}
   save();
  });
 }
 for(const card of history.querySelectorAll('.ns33-order-card')){
  const select=card.querySelector('select[data-order-status]');const o=select&&db.orders.find(x=>x.id===select.dataset.orderStatus);
  if(o?.deliveredAt&&!card.querySelector('.ns35-delivered')){const info=document.createElement('div');info.className='hint ns35-delivered';info.textContent='✓ Delivered: '+new Date(o.deliveredAt).toLocaleString()+' · '+(o.deliveredBy||'');card.append(info)}
 }
 });observer.observe(history,{childList:true,subtree:false});}

// Show Share Location explicitly in saved shop cards, using coordinates already recorded with the shop.
const shops=$('nsLocResults');if(shops){const apply=()=>{
 for(const card of shops.querySelectorAll('.ns-shop-card')){
   if(card.querySelector('.ns35-shop-share'))continue;
   const btn=card.querySelector('[data-shop-action="route"]');if(!btn)continue;
   const id=btn.dataset.id;
   // v3.3 may already add a WhatsApp button; relabel to a recognizable action.
   const prev=card.querySelector('.ns33-share-shop');if(prev){prev.textContent='🟢 Share Location';continue;}
   const extra=document.createElement('button');extra.type='button';extra.className='secondary sm ns35-shop-share';extra.textContent='🟢 Share Location';extra.onclick=()=>{
     // Save current GPS to shop directory before sharing if it hasn't been saved.
     let match=null;for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(!/ns_shop_(directory|pending)/.test(key))continue;try{match=JSON.parse(localStorage.getItem(key))?.find(x=>x.id===id);if(match)break}catch(_){}}
     if(!match){toast('Save this shop location before sharing');return;}
     const url='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(match.lat+','+match.lon);
     const text='Shop: '+match.name+'\n'+(match.address||'')+'\n'+url;
     const phone=String(match.phone||'').replace(/[^\d]/g,'');const w=phone.startsWith('0')?'94'+phone.slice(1):phone;
     const u='https://wa.me/'+(w.length>8?w:'')+'?text='+encodeURIComponent(text);
     if(window.AndroidPrinter?.openSharedLink)window.AndroidPrinter.openSharedLink(u);else window.open(u,'_blank','noopener,noreferrer');
   };btn.parentElement.append(extra);
 }
 };const obs=new MutationObserver(apply);obs.observe(shops,{childList:true});apply();}

// Compact, optional item-name suffix next to each item name field.
// Name suffix ≠ inventory/quantity unit: no stock conversion happens here.
const SUFFIXES=['','g','kg','mg','ml','L','pcs','pack','box','bottle'];
function applyNameSuffix(raw,unit){
 const name=String(raw||'').trim();if(!unit||!name)return name;
 // Do not append a second unit to an already completed item name.
 if(/\d+(?:[.,]\d+)?\s*(?:mg|kg|ml|g|l|pcs|pc|pack|box|bottle|dozen|mm|cm|m)$/i.test(name))return name;
 if(!/\d+(?:[.,]\d+)?$/.test(name))return name;
 return name+unit;
}
window.NS35_applyNameSuffix=applyNameSuffix;
function attachNameUnit(inputId,selectId){
 const inp=$(inputId);if(!inp||$(selectId))return;
 const wrap=document.createElement('div');wrap.className='ns35-name-unit-row';
 inp.parentNode.insertBefore(wrap,inp);wrap.append(inp);
 const unit=document.createElement('select');unit.id=selectId;unit.title='Optional unit in product name';unit.setAttribute('aria-label','Name unit (optional)');
 unit.innerHTML=SUFFIXES.map(u=>'<option value="'+u+'">'+(u||'None')+'</option>').join('');wrap.append(unit);
 const preview=document.createElement('small');preview.className='ns35-suffix-preview';wrap.after(preview);
 const refresh=()=>{const val=inp.value.trim(),selected=unit.value,display=applyNameSuffix(val,selected);
   preview.textContent=val&&selected?(display!==val?'Name: '+display:'Type a number at the end (e.g. Tea Bags 50)'):'';
 };
 inp.addEventListener('input',refresh);unit.addEventListener('change',refresh);
 return unit;
}
attachNameUnit('pName','ns35ProductNameUnit');
attachNameUnit('manualName','ns35ManualNameUnit');
attachNameUnit('ns33OrderItem','ns35OrderNameUnit');

// Product names are stored with the selected suffix, e.g. Tea Bags 50g.
if($('pName')){
 const priorSave=saveProduct;
 saveProduct=function(){const name=$('pName').value, unit=$('ns35ProductNameUnit').value;
   $('pName').value=applyNameSuffix(name,unit);
   const before=db.products.length;
   try{priorSave()}finally{
     if(db.products.length!==before || !$('pName').value.trim())$('ns35ProductNameUnit').value='';
   }
 };
 const priorEdit=editProduct;editProduct=function(id){priorEdit(id);$('ns35ProductNameUnit').value='';};
 const priorClear=resetProduct;resetProduct=function(){priorClear();$('ns35ProductNameUnit').value='';};
}
if($('manualName')){
 const priorManual=addManualItem;
 addManualItem=function(){const name=$('manualName').value;const before=invoiceCart.length;
  $('manualName').value=applyNameSuffix(name,$('ns35ManualNameUnit').value);
  priorManual();
  if(invoiceCart.length>before){$('manualName').value='';$('ns35ManualNameUnit').value='';}
  else $('manualName').value=name;
 };
}
// Keep the order's quantity unit separately from the optional name suffix.
const orderNameAdd=$('ns33OrderAdd');if(orderNameAdd){orderNameAdd.addEventListener('click',()=>{
 const field=$('ns33OrderItem');field.value=applyNameSuffix(field.value,$('ns35OrderNameUnit').value);
},true);}

// Editable Bill: visible item picker including optional custom unit, not a fragile prompt dialog.
const editor=$('ns33EditOverlay'),btnAdd=$('ns33EditAdd');if(editor&&btnAdd){
 const box=document.createElement('div');box.id='ns35EditPicker';box.className='ns35-edit-picker';box.innerHTML=`<div class="field"><label>Select Product / Enter Item</label><input id="ns35EditNewName" list="ns35EditProductList" placeholder="Product name or SKU"><datalist id="ns35EditProductList"></datalist></div>
 <div class="row"><div class="field"><label>Quantity</label><input id="ns35EditNewQty" type="number" min="0.001" step="any" value="1"></div><div class="field"><label>Unit</label><select id="ns35EditNewUnit">${unitNames.map(u=>'<option>'+u+'</option>').join('')}</select></div><div class="field"><label>Rate</label><input id="ns35EditNewRate" type="number" min="0" step="0.01" value="0"></div></div>`;
 btnAdd.parentNode.insertBefore(box,btnAdd);btnAdd.textContent='+ Add Item to Bill';
 attachNameUnit('ns35EditNewName','ns35EditNameUnit');
 const redrawProductList=()=>{$('ns35EditProductList').innerHTML=db.products.map(p=>'<option value="'+html(p.name)+'"></option>').join('')};
 $('ns35EditNewName').addEventListener('focus',redrawProductList);
 $('ns35EditNewName').addEventListener('change',()=>{const p=db.products.find(x=>x.name.toLowerCase()===$('ns35EditNewName').value.toLowerCase()||x.sku===$('ns35EditNewName').value);if(p){$('ns35EditNewUnit').value=p.baseUnit||'pcs';$('ns35EditNewRate').value=p.price||0}});
 // v3.3 editor owns a private array, so let its add handler ask for product via prompt? Avoid prompt with temporary direct prompt override,
 // pass selected input and fill extra qty/rate through visible edit row events.
 btnAdd.onclick=()=>{
  const entered=$('ns35EditNewName').value.trim(),name=applyNameSuffix(entered,$('ns35EditNameUnit').value),q=Number($('ns35EditNewQty').value),u=$('ns35EditNewUnit').value,rate=Number($('ns35EditNewRate').value);
  if(!name||!Number.isFinite(q)||q<=0||!Number.isFinite(rate)||rate<0)return toast('Enter valid item, quantity and rate');
  const p=db.products.find(x=>x.name.toLowerCase()===name.toLowerCase()||x.sku===name);
  const oldInvoice=previewInvoice && db.invoices.find(x=>x.id===previewInvoice.id);
  // For stock bills products must already exist. For manual bills free text is allowed.
  const editing=db.invoices.find(x=>x.id===window.NS33_currentEditId?.());
  const inv=editing||oldInvoice;
  if(inv?.mode==='stock'&&!p)return toast('Choose an existing product for stock bills');
  const base=p?.baseUnit||u;
  const groups={g:['mass',1],kg:['mass',1000],mg:['mass',0.001],ml:['volume',1],L:['volume',1000],pcs:['count',1],dozen:['count',12],pack:['package',1],box:['package',1],bottle:['package',1],bag:['package',1],m:['length',1000],cm:['length',10],mm:['length',1]};
  if(p&&(!groups[base]||!groups[u]||groups[base][0]!==groups[u][0]))return toast('Unit incompatible with product stock unit');
  const ratio=p?groups[u][1]/groups[base][1]:1;
  const added=window.NS33_appendEditLine?.({id:uid(),productId:p?.id||null,name:p?.name||name,qty:q*ratio,displayQty:q,rate:rate/ratio,unit:u,baseUnit:base});
  if(!added)return toast('Open an invoice for editing first');
  $('ns35EditNewName').value='';$('ns35EditNewQty').value='1';$('ns35EditNewRate').value='0';$('ns35EditNameUnit').value='';
 };
 const commit=$('ns33EditCommit');if(commit){
 const plus=document.createElement('button');plus.type='button';plus.className='secondary';plus.textContent='Save & Print';commit.after(plus);
 plus.onclick=()=>{const was=previewInvoice?.id, count=db.invoiceEdits?.length||0;commit.click();if((db.invoiceEdits?.length||0)>count && previewInvoice?.id===was){
    setTimeout(()=>{if(window.NS21_printNow)window.NS21_printNow();else printSystem()},100);
  }};
 }
}

// Replace broken prompt-based Reset with visible confirmation dialog and clear all local data.
const reset=$('ns33Reset');if(reset){reset.onclick=()=>{
 if(typeof NS2_needAdmin==='function'&&!NS2_needAdmin())return;
 if($('ns35ResetOverlay')){$('ns35ResetOverlay').classList.add('show');return}
 const cover=document.createElement('div');cover.className='overlay show';cover.id='ns35ResetOverlay';cover.innerHTML='<div class="modal ns35-reset-modal"><h2>Reset All Local Data</h2><p>Deletes products, stock, invoices, orders, GRNs and local shop locations on THIS device. Business branding remains unchanged. Cloud records will not be deleted.</p><label>Type <b>RESET ALL</b> to confirm</label><input id="ns35ResetCode" placeholder="RESET ALL" autocomplete="off"><label class="ns35-label-checkbox"><input id="ns35ResetCheck" type="checkbox"> I understand this cannot be undone</label><div class="actions"><button type="button" class="secondary" id="ns35ResetCancel">Cancel</button><button type="button" class="danger" id="ns35ResetConfirm">Erase This Device</button></div></div>';
 document.body.append(cover);$('ns35ResetCancel').onclick=()=>cover.classList.remove('show');
 $('ns35ResetConfirm').onclick=async()=>{if($('ns35ResetCode').value!=='RESET ALL'||!$('ns35ResetCheck').checked)return toast('Enter RESET ALL and confirm');
  try{const preservedBusinessSettings={...(db.settings||{})};localStorage.clear();localStorage.setItem(STORAGE,JSON.stringify({...initial(),settings:preservedBusinessSettings}));sessionStorage.clear();if(window.caches){const keys=await caches.keys();await Promise.all(keys.map(k=>caches.delete(k)))}
   toast('Local records erased');location.reload();}
  catch(e){toast('Reset error: '+e.message)}
 };
 }};

const css=document.createElement('style');css.textContent=`.ns35-label-checkbox{display:flex;align-items:center;gap:9px;font-size:12px;color:#41536d;margin:10px 0}.ns35-label-checkbox input{width:auto}.ns35-edit-picker{background:#f2f7ff;border:1px solid #cfe0fc;padding:10px;border-radius:13px;margin:8px 0}.ns35-reset-modal{max-width:500px}.ns35-reset-modal p{line-height:1.55;color:#5b6478}#ns35EditPicker .row{gap:7px}#ns35EditPicker .row>.field{flex:1;min-width:75px}.ns35-rep{font-size:11px;font-weight:700;margin-top:3px}.ns35-order-row-price{max-width:85px}.ns35-name-unit-row{display:flex;gap:7px;align-items:stretch;width:100%}.ns35-name-unit-row input{flex:1;min-width:0}.ns35-name-unit-row select{width:84px;flex:0 0 84px;border-radius:9px;border:1px solid #cbd5e1;background:#eef5ff;font-weight:750;font-size:13px;color:#153060;padding:6px}.ns35-suffix-preview{display:block;min-height:0;font-size:11px;color:#2563eb;margin-top:4px}`;document.head.append(css);
})();
