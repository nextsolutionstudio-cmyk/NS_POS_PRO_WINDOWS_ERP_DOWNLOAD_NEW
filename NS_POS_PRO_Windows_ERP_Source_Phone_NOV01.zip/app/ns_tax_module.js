/* NS POS PRO - Optional configurable tax billing module, 2026.
 * Default OFF; tax rates are manually set by the admin, not official rates.
 * Does not change previously saved invoices or their amounts.
 */
(function(){
'use strict';
const by=id=>document.getElementById(id);
const cash=v=>Math.round((Number(v)||0)*100)/100;
const bounded=v=>Math.min(100,Math.max(0,Number(v)||0));
const textSafe=s=>String(s||'Tax').replace(/[\r\n<>]/g,' ').trim().slice(0,30)||'Tax';
const cfg=()=>({enabled:db.settings.nsTax?.enabled===true,
 rate:bounded(db.settings.nsTax?.rate),
 mode:db.settings.nsTax?.mode==='inclusive'?'inclusive':'exclusive',
 label:textSafe(db.settings.nsTax?.label)});
function compute(subtotal,discount,rate,mode,applied){
 const afterDiscount=cash(Math.max(0,(Number(subtotal)||0)-(Number(discount)||0)));
 const pct=bounded(rate),active=applied===true&&pct>0;
 const inclusive=mode==='inclusive';
 const taxAmount=active?cash(inclusive?afterDiscount*pct/(100+pct):afterDiscount*pct/100):0;
 const total=cash(afterDiscount+(active&&!inclusive?taxAmount:0));
 return {taxApplied:active,taxMode:inclusive?'inclusive':'exclusive',taxRate:active?pct:0,
   taxAmount,taxBase:cash(inclusive?afterDiscount-taxAmount:afterDiscount),total};
}
window.NSTax={compute,getConfig:cfg};
const lang=()=>window.NSLang?.get?.()||localStorage.getItem('nspos_ui_lang')||'en';
const messages={en:{settings:'Tax Settings (Admin)',enable:'Enable tax',rate:'Tax rate (%)',label:'Tax name / label',mode:'Price mode',exclusive:'Add tax on top of price (exclusive)',inclusive:'Tax already included in selling price (inclusive)',save:'Save Tax Settings',hint:'Set the percentage applicable to your business. Default is OFF (0%). Verify any tax obligations with your accountant.',apply:'Apply tax to this bill',taxable:'Taxable amount',tax:'Tax',noTax:'Tax disabled in Settings',summary:'Tax amount',today:'Today tax',all:'Tax total before returns'},
si:{settings:'බදු සැකසුම් (Admin)',enable:'බදු ක්‍රියාත්මක කරන්න',rate:'බදු අනුපාතය (%)',label:'බදු නාමය',mode:'මිල ගණනය කරන ආකාරය',exclusive:'මිලට බදු එකතු කරන්න',inclusive:'මිලට දැනටමත් බදු ඇතුළත්',save:'බදු සැකසුම් සුරකින්න',hint:'ඔබේ ව්‍යාපාරයට අදාළ බදු අනුපාතය ඇතුළත් කරන්න. මුලදී බදු OFF (0%).',apply:'මෙම බිල්පතට බදු අය කරන්න',taxable:'බදු අය කළ හැකි මුදල',tax:'බදු',noTax:'සැකසුම් තුළ බදු අක්‍රියයි',summary:'බදු මුදල',today:'අද බදු',all:'මුළු බදු (ආපසු භාරගැනීම් පෙර)'},
ta:{settings:'வரி அமைப்புகள் (Admin)',enable:'வரியை இயக்கவும்',rate:'வரி விகிதம் (%)',label:'வரி பெயர்',mode:'விலை கணக்கிடும் முறை',exclusive:'விலைக்கு மேலாக வரி சேர்க்கவும்',inclusive:'விலையில் வரி ஏற்கனவே அடங்கியுள்ளது',save:'வரி அமைப்புகளைச் சேமி',hint:'உங்கள் வணிகத்திற்கான சரியான வரி விகிதத்தைத் தரவும். தொடக்கத்தில் வரி OFF (0%).',apply:'இந்த பில்லில் வரி சேர்க்கவும்',taxable:'வரிக்குட்பட்ட தொகை',tax:'வரி',noTax:'அமைப்புகளில் வரி முடக்கப்பட்டுள்ளது',summary:'வரி தொகை',today:'இன்றைய வரி',all:'மொத்த வரி (திருப்பம் முன்பு)'}};
const t=k=>(messages[lang()]||messages.en)[k]||messages.en[k]||k;
const settingHtml=`<div class="panel" id="nsTaxSettings" data-ns2-admin="1" style="display:none;border:1px solid #c9d8ff;background:linear-gradient(155deg,#f5faff,#fff)">
<h2 id="nsTaxTitle">Tax Settings (Admin)</h2>
<label class="row" style="gap:12px;margin-bottom:12px"><input type="checkbox" id="nsTaxEnabled" style="width:20px;height:20px"><strong id="nsTaxEnableLabel">Enable tax</strong></label>
<div class="row"><div class="field"><label id="nsTaxRateLabel">Tax rate (%)</label><input id="nsTaxRate" type="number" min="0" max="100" step="0.01" inputmode="decimal" value="0"></div>
<div class="field"><label id="nsTaxNameLabel">Tax name / label</label><input id="nsTaxName" value="Tax" maxlength="30" placeholder="Tax / VAT"></div></div>
<div class="field"><label id="nsTaxModeLabel">Price mode</label><select id="nsTaxMode"><option value="exclusive">Add tax on top of price (exclusive)</option><option value="inclusive">Tax already included in selling price (inclusive)</option></select></div>
<button class="primary" type="button" id="nsTaxSave">Save Tax Settings</button>
<div class="hint" id="nsTaxHint" style="margin-top:12px">Set the percentage applicable to your business.</div>
<div class="notice" id="nsTaxSummary" style="margin-top:12px"></div></div>`;
const billHtml=`<div id="nsTaxBill" class="panel" style="border:1px solid #d9e7fa;background:#f5f9ff;padding:12px;margin:12px 0">
<label class="row" style="gap:10px;margin-bottom:8px"><input id="iTaxApply" type="checkbox" style="width:21px;height:21px"><strong id="nsTaxApplyLabel">Apply tax to this bill</strong></label>
<div class="row" style="justify-content:space-between;font-size:13px"><span id="nsTaxBillLabel">Tax</span><b id="nsTaxBillAmount">Rs. 0.00</b></div>
<div class="hint" id="nsTaxBillHint"></div></div>`;
const invoice=by('invoice'),settings=by('settings');
if(!invoice||!settings)return;
const beforeTotal=by('invoiceTotal')?.closest('.grand');
if(!beforeTotal)return;
beforeTotal.insertAdjacentHTML('beforebegin',billHtml);
const firstSettings=settings.querySelector('.panel');
firstSettings?.insertAdjacentHTML('afterend',settingHtml);
function refreshLanguage(){
 const mappings={nsTaxTitle:'settings',nsTaxEnableLabel:'enable',nsTaxRateLabel:'rate',nsTaxNameLabel:'label',nsTaxModeLabel:'mode',nsTaxSave:'save',nsTaxHint:'hint',nsTaxApplyLabel:'apply'};
 for(const [id,key] of Object.entries(mappings))if(by(id))by(id).textContent=t(key);
 const options=by('nsTaxMode')?.options;if(options){options[0].textContent=t('exclusive');options[1].textContent=t('inclusive');}
}
function refreshSettings(){const c=cfg();
 for(const [id,v] of [['nsTaxEnabled',c.enabled],['nsTaxRate',c.rate],['nsTaxName',c.label],['nsTaxMode',c.mode]]){
 const field=by(id);if(!field)continue;
 if(id==='nsTaxEnabled')field.checked=v;
 else if(document.activeElement!==field)field.value=String(v);
 }
 const invoices=db.invoices||[],sameDay=new Date().toDateString();
 const sum=arr=>cash(arr.reduce((a,v)=>a+(v.taxApplied===true?Number(v.taxAmount)||0:0),0));
 by('nsTaxSummary').textContent=`${t('today')}: ${money(sum(invoices.filter(i=>new Date(i.date).toDateString()===sameDay)))} · ${t('all')}: ${money(sum(invoices))}`;
 refreshLanguage();
}
function updateBill(){const c=cfg(),check=by('iTaxApply');if(!check)return;
 check.disabled=!c.enabled || c.rate<=0;
 const result=compute(invoiceCart.reduce((sum,l)=>sum+(Number(l.qty)||0)*(Number(l.rate)||0),0),by('iDiscount')?.value,c.rate,c.mode,check.checked&&c.enabled);
 by('nsTaxBillAmount').textContent=money(result.taxAmount);
 by('nsTaxBillLabel').textContent=textSafe(c.label)+' ('+c.rate+'%'+(c.mode==='inclusive'?' incl.':'')+')';
 by('nsTaxBillHint').textContent=!c.enabled?t('noTax'):c.mode==='inclusive'?t('inclusive'):t('exclusive');
 refreshLanguage();
}
function applyTaxConfig(){const c=cfg();by('iTaxApply').checked=c.enabled&&c.rate>0;updateBill();}
by('iTaxApply').addEventListener('change',()=>{renderInvoiceLines(false);updateBill();});
by('nsTaxSave').addEventListener('click',()=>{
 if(typeof NS2_needAdmin!=='function'||!NS2_needAdmin())return;
 const raw=Number(by('nsTaxRate').value);
 if(!Number.isFinite(raw)||raw<0||raw>100)return toast('Tax rate must be between 0 and 100%');
 const next={enabled:by('nsTaxEnabled').checked,rate:cash(raw),mode:by('nsTaxMode').value==='inclusive'?'inclusive':'exclusive',label:textSafe(by('nsTaxName').value)};
 const old=db.settings.nsTax;db.settings.nsTax=next;if(!save()){db.settings.nsTax=old;return}
 applyTaxConfig();refreshSettings();renderInvoiceLines(false);toast('Tax settings saved');
});
// Preserve the existing invoice data model and its save flow; tax metadata is frozen when saving.
const previousTotals=totals;
totals=function(){const result=previousTotals(),c=cfg();const tax=compute(result.subtotal,result.discount,c.rate,c.mode,c.enabled&&by('iTaxApply')?.checked===true);
 return {...result,...tax,taxLabel:textSafe(c.label),balance:cash(tax.total-result.paid)};
};
const previousRender=renderInvoiceLines;
renderInvoiceLines=function(...args){const res=previousRender.apply(this,args);updateBill();return res;};
const previousClear=clearInvoice;
clearInvoice=function(...args){const result=previousClear.apply(this,args);applyTaxConfig();return result;};
const previousShow=showPreview;
showPreview=function(...args){const result=previousShow.apply(this,args);const inv=previewInvoice;
 if(inv?.taxApplied===true&&Number(inv.taxRate)>0){
   for(const id of ['receiptPreview','printZone']){
     const paper=by(id)?.querySelector('.invoice-paper');if(!paper)continue;
     const discount=[...paper.querySelectorAll('div')].find(x=>x.childElementCount===0&&/^Discount:/.test((x.textContent||'').trim()));
     if(discount){const base=document.createElement('div');base.textContent=`Taxable: ${money(inv.taxBase)}`;
       const rate=document.createElement('div');rate.textContent=`${textSafe(inv.taxLabel)} ${Number(inv.taxRate).toFixed(2)}%${inv.taxMode==='inclusive'?' (included)':''}: ${money(inv.taxAmount)}`;
       discount.insertAdjacentElement('afterend',base);base.insertAdjacentElement('afterend',rate);
     }
   }
 }
 return result;
};
// Text-only thermal printer paths use several aliases; each must show the frozen invoice tax.
const decorated=new WeakMap();
function decorateReceipt(base){if(typeof base!=='function')return base;if(decorated.has(base))return decorated.get(base);
 const fn=function(inv){let body=String(base.apply(this,arguments));if(!inv?.taxApplied||!(Number(inv.taxRate)>0))return body;
 const label=textSafe(inv.taxLabel),amount=(Number(inv.taxAmount)||0).toFixed(2),rate=Number(inv.taxRate).toFixed(2);
 const row='Taxable: Rs. '+(Number(inv.taxBase)||0).toFixed(2)+'\n'+label+' '+rate+'%'+(inv.taxMode==='inclusive'?' (incl.)':'')+': Rs. '+amount+'\n';
 const match=body.match(/^.*Discount:.*(?:\r?\n|$)/mi);if(match){const start=match.index+match[0].length;return body.slice(0,start)+row+body.slice(start)}
 return body.replace(/TOTAL:/,'Tax: Rs. '+amount+'\nTOTAL:');};decorated.set(base,fn);return fn;
}
if(typeof textReceipt==='function')textReceipt=decorateReceipt(textReceipt);
for(const k of ['NS28_textReceipt','NS27_textReceipt'])if(typeof window[k]==='function')window[k]=decorateReceipt(window[k]);
const previousRenderAll=renderAll;
renderAll=function(...args){const r=previousRenderAll.apply(this,args);refreshSettings();updateBill();return r;};
by('nsLangSelect')?.addEventListener('change',()=>{refreshSettings();updateBill()});
// No tax active by default. Historical invoices stay unchanged; no recalculation on reprint.
applyTaxConfig();refreshSettings();if(typeof NS2_roles==='function')NS2_roles();
})();
