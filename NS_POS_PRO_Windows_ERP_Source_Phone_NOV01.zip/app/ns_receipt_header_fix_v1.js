/* NS POS PRO Receipt Header Fix v1 — use one owner-managed contact block.
   Presentation-only: saved sales, invoices, inventory and tenant credentials are untouched. */
(function () {
  'use strict';
  function formatWebsite(value) {
    let site=String(value||'').trim();
    if(!site)return '';
    site=site.replace(/^https?:\/\//i,'').replace(/^\/\//,'').replace(/\/$/,'');
    if(site && !/^www\./i.test(site))site='www.'+site;
    return site;
  }
  window.NSPOSReceiptWebsite=formatWebsite;
  function uniquePhones(b) {
    const phones=[b.phone,b.phone2,b.phone3].map(x=>String(x||'').trim()).filter(Boolean);
    return [...new Set(phones)].join(' / ');
  }
  function currentBusiness(inv){
    // After an Owner refresh, use the current configured identity for the
    // displayed header, including the newly uploaded business logo.
    return {...(inv?.business||{}),...(typeof db!=='undefined'&&db.settings?db.settings:{})};
  }
  function addText(root,tag,txt){
    if(!txt)return;
    const e=document.createElement(tag);e.textContent=String(txt);root.appendChild(e);
  }
  function refreshHeader(){
    const inv=typeof previewInvoice!=='undefined'?previewInvoice:null;
    if(!inv)return;
    const b=currentBusiness(inv);
    for(const id of ['receiptPreview','printZone']){
      const container=document.getElementById(id);
      const heading=container?.querySelector('.invoice-paper > .center');
      if(!heading)continue;
      // Replacing the heading removes older patches that appended duplicate
      // email, phone and website lines or accidentally overwrote website with Tel.
      heading.replaceChildren();
      if(b.logo && db?.settings?.receiptLogo !== false){
        const img=document.createElement('img');img.src=b.logo;img.alt='Business logo';heading.appendChild(img);
      }
      addText(heading,'h2',b.name||'Business');
      addText(heading,'div',b.address);
      const phone=uniquePhones(b);if(phone)addText(heading,'div','Tel: '+phone);
      if(b.email)addText(heading,'div','Email: '+b.email);
      if(b.website)addText(heading,'div','Web: '+formatWebsite(b.website));
      heading.style.textAlign='center';heading.style.width='100%';
      heading.querySelectorAll('div').forEach(e=>{e.style.textAlign='center';e.style.width='100%';e.style.lineHeight='1.35';e.style.overflowWrap='anywhere'});
    }
  }
  if(typeof window.showPreview==='function'){
    const original=window.showPreview;
    window.showPreview=function(...args){const result=original.apply(this,args);refreshHeader();return result;};
  }
  if(typeof window.textReceipt==='function'){
    const original=window.textReceipt;
    window.textReceipt=function(invoice){
      if(!invoice)return original.apply(this,arguments);
      const b=currentBusiness(invoice);
      b.website=formatWebsite(b.website);
      // A temporary copy ensures stored historical invoice data is unchanged.
      return original.call(this,{...invoice,business:b});
    };
  }
})();
