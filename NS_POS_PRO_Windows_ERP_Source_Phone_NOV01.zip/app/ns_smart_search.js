/* NS POS PRO Smart Search: local/offline multi-language query UI. */
(()=>{'use strict';
const get=(id)=>document.getElementById(id);
const tr={
 en:{search:'🔎 Search products, bills, customers or phone...',all:'Quick search',no:'No matching items',prod:'Product',bill:'Invoice',customer:'Customer',open:'Open',use:'Select',edit:'Edit',billitem:'Search product by name or barcode',noproduct:'No products found',cancel:'Clear'},
 si:{search:'🔎 භාණ්ඩ, බිල්පත්, පාරිභෝගිකයන් සොයන්න...',all:'ඉක්මන් සෙවීම',no:'ගැළපෙන ප්‍රතිඵල නැහැ',prod:'භාණ්ඩය',bill:'බිල්පත',customer:'පාරිභෝගිකයා',open:'විවෘත',use:'තෝරන්න',edit:'සංස්කරණය',billitem:'නම හෝ බාර්කෝඩ් අනුව භාණ්ඩය සොයන්න',noproduct:'භාණ්ඩ හමු නොවීය',cancel:'හිස් කරන්න'},
 ta:{search:'🔎 பொருட்கள், ரசீதுகள், வாடிக்கையாளர்களைத் தேடுங்கள்...',all:'விரைவு தேடல்',no:'பொருத்தமான முடிவுகள் இல்லை',prod:'பொருள்',bill:'ரசீது',customer:'வாடிக்கையாளர்',open:'திற',use:'தேர்வு',edit:'திருத்து',billitem:'பெயர் அல்லது பார்கோடு மூலம் பொருளைத் தேடு',noproduct:'பொருட்கள் இல்லை',cancel:'அழி'}
};
const lang=()=>['en','si','ta'].includes(window.NSLang?.get?.())?window.NSLang.get():['en','si','ta'].includes(localStorage.getItem('nspos_ui_lang'))?localStorage.getItem('nspos_ui_lang'):'en';
const words=()=>tr[lang()];
const norm=s=>String(s??'').normalize('NFKC').toLocaleLowerCase().trim();
const contains=(hay,q)=>norm(hay).includes(q);
const text=(tag,cls,str)=>{const el=document.createElement(tag);el.className=cls||'';el.textContent=str;return el;};
const state={open:false,rows:[]};
const bar=document.createElement('div');bar.id='nsSmartSearch';
bar.innerHTML='<div class="nss-box"><span class="nss-icon" aria-hidden="true">🔎</span><input id="nsSmartInput" type="search" autocomplete="off" spellcheck="false" aria-controls="nsSmartResults" aria-label="Quick Search"><button type="button" class="nss-close" id="nsSmartClear" aria-label="Clear">✕</button></div><div class="nss-results" id="nsSmartResults" role="listbox" aria-label="Search Results"></div>';
const tabs=get('tabs');if(tabs)tabs.after(bar);else document.body.prepend(bar);
const inp=get('nsSmartInput'),results=get('nsSmartResults'),clearBtn=get('nsSmartClear');
const style=document.createElement('style');style.textContent='\n/* Smart Search – responsive, usable on mobile and multilingual. */\n#nsSmartSearch{position:relative;z-index:28;margin:10px auto 14px;padding:0 12px;max-width:1300px;box-sizing:border-box}\n#nsSmartSearch .nss-box{display:flex;align-items:center;gap:9px;background:#fff;border:1.5px solid #d7e4fa;border-radius:16px;box-shadow:0 4px 20px #143f8619;padding:8px 10px;color:#1d4689}\n#nsSmartSearch .nss-box:focus-within{border-color:#2984e9;box-shadow:0 0 0 3px #3f8fff20}\n#nsSmartSearch .nss-icon{font-size:20px;padding-left:3px}\n#nsSmartSearch input{flex:1;min-width:0;max-width:none;border:0!important;box-shadow:none!important;background:transparent!important;outline:none!important;font-size:15px;color:#19335f;padding:8px 0;line-height:1.5}\n#nsSmartSearch .nss-close{border:0;background:#eef5ff;color:#2455a3;font-weight:800;border-radius:10px;padding:6px 10px;min-height:34px}\n#nsSmartSearch .nss-results{display:none;position:absolute;top:calc(100% + 5px);left:12px;right:12px;z-index:100;background:#fff;box-shadow:0 16px 45px #08225144;border:1px solid #cfdef2;border-radius:16px;max-height:min(58vh,500px);overflow-y:auto;overscroll-behavior:contain;padding:6px}\n#nsSmartSearch .nss-results.show{display:block}\n#nsSmartSearch .nss-result{display:flex;gap:8px;align-items:center;padding:11px 8px;border-bottom:1px solid #edf1f8}\n#nsSmartSearch .nss-result:last-child{border-bottom:0}\n#nsSmartSearch .nss-content{flex:1;min-width:0;overflow-wrap:anywhere}\n#nsSmartSearch .nss-title{color:#173563;font-size:14px;font-weight:800}\n#nsSmartSearch .nss-meta{color:#667d9f;font-size:12px;margin-top:3px}\n#nsSmartSearch .nss-result button{flex-shrink:0;border:0!important;background:#e5efff;color:#1647aa;border-radius:10px;min-width:55px;min-height:40px;font-weight:800;font-size:12px;padding:5px 8px}\n#nsSmartSearch .nss-result button.nss-primary{background:linear-gradient(110deg,#174ac7,#0b92db);color:white}\n#nsSmartSearch .nss-empty{padding:20px;text-align:center;color:#607996}\n#nsBillSearchWrap{padding:9px 11px 7px;border-radius:12px;background:#ecf5ff;border:1px solid #d2e6ff;margin:11px 0 8px;max-width:100%}\n#nsBillSearchWrap label{display:block;color:#163c7b;font-weight:800;font-size:13px;margin-bottom:5px}\n#nsBillProductSearch{width:100%;min-height:42px;padding:10px 12px;border:1px solid #b4cce7;background:#fff;color:#14365e;border-radius:10px;box-sizing:border-box;font-size:15px}\n@media(max-width:680px){#nsSmartSearch{padding:0 7px;margin:7px auto 11px}#nsSmartSearch .nss-results{left:6px;right:6px}#nsSmartSearch .nss-result{padding:10px 5px}#nsSmartSearch .nss-result button{min-width:49px}#nsSmartSearch input{font-size:14px}}\n@media print{#nsSmartSearch,#nsBillSearchWrap{display:none!important}}\n';document.head.append(style);
const navigateTo=id=>{if(typeof navigate==='function')navigate(id);};
function rows(){
 const q=norm(inp.value);if(!q)return [];
 let matches=[];
 // Read only business data from the current logged-in device/database.
 if(typeof db==='undefined'||!db)return [];
 for(const p of (Array.isArray(db.products)?db.products:[])){
  if(contains(p.name+' '+(p.sku||''),q))matches.push({kind:'prod',id:p.id,title:p.name,subtitle:[p.sku||'',Number(p.stock||0)+' stock','Rs. '+Number(p.price||0).toFixed(2)].filter(Boolean).join(' · ')});
  if(matches.filter(x=>x.kind==='prod').length>=7)break;
 }
 let bills=0;for(const b of [...(Array.isArray(db.invoices)?db.invoices:[])].reverse()){
  if(contains([b.number,b.customer,b.phone].join(' '),q)){
   matches.push({kind:'bill',id:b.id,title:b.number||'Invoice',subtitle:[b.customer||'',b.phone||'',Number(b.total||0).toFixed(2)].filter(Boolean).join(' · ')});
   if(++bills>=6)break;
  }
 }
 let customers=0,seen=new Set();for(const b of [...(Array.isArray(db.invoices)?db.invoices:[])].reverse()){
  const name=String(b.customer||'').trim(),phone=String(b.phone||'').trim();if(!name&&!phone)continue;
  const key=norm(name+'|'+phone);if(seen.has(key))continue;seen.add(key);
  if(contains(name+' '+phone,q)){
   matches.push({kind:'customer',id:key,title:name||phone,subtitle:phone,name,phone});
   if(++customers>=4)break;
  }
 }
 return matches;
}
function closeResults(){state.open=false;results.classList.remove('show');inp.setAttribute('aria-expanded','false');}
function refresh(){
 inp.placeholder=words().search;
 clearBtn.setAttribute('aria-label',words().cancel);
 const label=get('nsBillSearchLabel'),billInput=get('nsBillProductSearch');if(label)label.textContent='🔎 '+words().billitem;if(billInput)billInput.placeholder=words().billitem;
 results.replaceChildren();const query=norm(inp.value);
 if(!query){closeResults();state.rows=[];return}
 state.rows=rows();
 for(const r of state.rows){
  const row=text('div','nss-result','');
  const icon=text('span','nss-kind',r.kind==='prod'?'📦':r.kind==='bill'?'🧾':'👤');icon.setAttribute('aria-hidden','true');
  const content=text('div','nss-content','');const title=text('div','nss-title',r.title),subtitle=text('div','nss-meta',words()[r.kind]+' · '+r.subtitle);content.append(title,subtitle);row.append(icon,content);
  const btn=text('button','nss-primary',r.kind==='prod'?words().use:words().open);
  btn.type='button';btn.addEventListener('click',()=>openResult(r));row.append(btn);results.append(row);
 }
 if(!state.rows.length)results.append(text('div','nss-empty',words().no));
 state.open=true;results.classList.add('show');inp.setAttribute('aria-expanded','true');
}
function openResult(r){
 closeResults();inp.value='';
 if(r.kind==='prod'){
  navigateTo('invoice');
  if(get('iMode')&&get('iMode').value!=='stock'){get('iMode').value='stock';if(typeof modeChanged==='function')modeChanged()}
  if(typeof populateSelects==='function')populateSelects();
  const select=get('iProduct');if(select){select.value=r.id;}
  const qty=get('iQty');if(qty)qty.value='1';
  // User taps existing "Add Item" to prevent accidental or duplicate billing.
  if(select){select.scrollIntoView({behavior:'smooth',block:'center'});select.focus({preventScroll:true})}
 }else if(r.kind==='bill'){
  navigateTo('history');if(typeof openInvoice==='function')openInvoice(r.id);
 }else if(r.kind==='customer'){
  navigateTo('invoice');if(get('iCustomer'))get('iCustomer').value=r.name;if(get('iPhone'))get('iPhone').value=r.phone;
  get('iCustomer')?.scrollIntoView({behavior:'smooth',block:'center'});
 }
}
inp.addEventListener('input',refresh);
inp.addEventListener('keydown',e=>{if(e.key==='Escape'){inp.value='';refresh();inp.blur()}else if(e.key==='Enter'&&state.rows.length){e.preventDefault();openResult(state.rows[0])}});
clearBtn.addEventListener('click',()=>{inp.value='';refresh();inp.focus()});
document.addEventListener('click',e=>{if(!bar.contains(e.target))closeResults()});
// Bill-specific search: filter product select, no data mutation, works offline.
const productSelect=get('iProduct');
if(productSelect){
 const wrap=document.createElement('div');wrap.id='nsBillSearchWrap';
 wrap.innerHTML='<label id="nsBillSearchLabel" for="nsBillProductSearch"></label><input type="search" id="nsBillProductSearch" autocomplete="off">';
 const field=productSelect.closest('.field');field?.parentElement?.before(wrap);
 const billInput=get('nsBillProductSearch');
 const filter=()=>{
  const q=norm(billInput.value);const selected=productSelect.value;
  const arr=(typeof db!=='undefined' && Array.isArray(db?.products)?db.products:[]).filter(p=>!q||contains(p.name+' '+(p.sku||''),q));
  // Build elements instead of interpolating names into HTML.
  productSelect.replaceChildren(new Option(words().use+' '+words().prod,'',true,false));
  for(const p of arr)productSelect.add(new Option(p.name+' ('+Number(p.stock||0)+' stock)',String(p.id)));
  if(arr.some(p=>String(p.id)===selected))productSelect.value=selected;
  else if(q&&arr.length===1)productSelect.value=String(arr[0].id);
  else productSelect.value='';
 };
 billInput.addEventListener('input',filter);
 // After base app renders select options, reapply the active search without observers/loops.
 const originalPopulate=typeof populateSelects==='function'?populateSelects:null;
 if(originalPopulate){
  try{populateSelects=function(){originalPopulate();if(get('nsBillProductSearch')?.value)filter()}}catch(e){}
 }
}
const selector=get('nsLangSelect');selector?.addEventListener('change',()=>setTimeout(refresh,0));
window.addEventListener('pageshow',refresh);
refresh();
})();
