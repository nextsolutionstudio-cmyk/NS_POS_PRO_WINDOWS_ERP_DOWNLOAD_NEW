/* NS POS PRO Retail / Wholesale / Distribution quick workspace.
   No universal-business selector; existing role permissions remain authoritative. */
(()=>{'use strict';
const shortcuts=[
 ['🧾','New Bill','invoice','blue'],
 ['🏪','Customer Shops','shops','teal'],
 ['📍','Shops Map','shops','purple'],
 ['📦','Wholesale Stock','wholesale','pink','admin'],
 ['🚚','Delivery Stock','delivery','orange'],
 ['💰','Credit Collection','credit','green'],
 ['📋','Invoices','history','indigo'],
 ['📦','Stock / Products','products','pink','admin'],
 ['📥','Purchase / GRN','grn','slate','admin']
];
const style=document.createElement('style');style.textContent=`
#nsRetailHub{margin:14px 0;padding:13px;border-radius:18px;background:#edf5ff;color:#19395e;border:1px solid #d3e2f5}
#nsRetailHub .nsrhTitle{font-size:20px;font-weight:850;margin-bottom:5px}
#nsRetailHub .nsrhSub{font-size:12px;opacity:.9;margin-bottom:12px}#nsRetailHub summary{cursor:pointer;display:flex;gap:10px;align-items:center;font-size:16px;font-weight:800;padding:7px 5px;list-style:none}#nsRetailHub summary::-webkit-details-marker{display:none}#nsRetailHub .nsrhInner{padding:8px 2px 3px}
#nsRetailHub .nsrhGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}
#nsRetailHub .nsrhAction{border:1px solid #d7e5f7;border-radius:15px;background:#fff;color:#102a57;padding:14px 7px;display:flex;align-items:center;flex-direction:column;gap:7px;font-size:12px;font-weight:800;cursor:pointer;min-height:91px;box-shadow:0 5px 14px #03133b33}
#nsRetailHub .nsrhAction span{font-size:28px}
#nsRetailHub .nsrhAction:focus-visible{outline:3px solid #ffd84e;outline-offset:3px}
#nsRetailHub .nsrhNotice{font-size:12px;margin-top:11px;min-height:15px}
`;document.head.appendChild(style);
function install(){const dash=document.getElementById('dashboard');if(!dash||document.getElementById('nsRetailHub'))return;
 const hub=document.createElement('details');hub.id='nsRetailHub';hub.setAttribute('aria-label','Retail wholesale and distribution shortcuts');
 hub.innerHTML='<summary>🧰 Quick Tools / ඉක්මන් මෙවලම් / விரைவு கருவிகள்　⌄</summary><div class="nsrhInner"><div class="nsrhSub">Extra shortcuts — expand only when needed. Role permissions still apply.</div><div class="nsrhGrid"></div><div class="nsrhNotice" role="status" aria-live="polite"></div></div>'; 
 const grid=hub.querySelector('.nsrhGrid');
 shortcuts.forEach(([emoji,label,page,color,role])=>{const b=document.createElement('button');b.type='button';b.className='nsrhAction nsrh-'+color;b.innerHTML='<span aria-hidden="true">'+emoji+'</span>'+label;
 b.onclick=()=>{const notice=hub.querySelector('.nsrhNotice');if(typeof window.navigate!=='function'){notice.textContent='Navigation is not ready yet';return}
 const dest=document.getElementById(page);if(!dest){notice.textContent=label+' is not available in this version. Existing POS features were not changed.';return}
 if(role==='admin' && typeof window.isAdmin==='function' && !window.isAdmin()){notice.textContent='Admin access required';return}
 window.navigate(page);};grid.appendChild(b)});
 const profile=document.getElementById('nsRepPanel');if(profile)profile.insertAdjacentElement('afterend',hub);else dash.insertBefore(hub,dash.firstChild);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
})();
