/* NS POS PRO v3.4: Admin-managed branding (no owner subscription/renewal). */
(()=>{
  'use strict';
  const get=(id)=>document.getElementById(id);
  const baseRender=renderSettings;
  renderSettings=function(){baseRender();const s=db.settings||{};if(get('sEmail')&&document.activeElement!==get('sEmail'))get('sEmail').value=s.email||'';if(get('sWebsite')&&document.activeElement!==get('sWebsite'))get('sWebsite').value=s.website||'';};
  const baseSave=saveSettings;
  saveSettings=function(){if(typeof NS2_needAdmin==='function'&&!NS2_needAdmin())return;const email=(get('sEmail')?.value||'').trim();const website=(get('sWebsite')?.value||'').trim();if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return toast('Enter a valid business email');if(website&&!/^https?:\/\//i.test(website))return toast('Website must begin with https://');baseSave();db.settings.email=email;db.settings.website=website;save();renderSettings();};
  const baseLogo=uploadLogo;
  uploadLogo=function(input){if(typeof NS2_needAdmin==='function'&&!NS2_needAdmin())return;return baseLogo(input);};
  renderSettings();
})();
