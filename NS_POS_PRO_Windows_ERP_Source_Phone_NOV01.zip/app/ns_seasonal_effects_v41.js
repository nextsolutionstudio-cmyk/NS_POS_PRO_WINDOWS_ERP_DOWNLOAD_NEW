/* NS POS PRO v4.1 - decorative seasonal effects, no billing or printer changes */
(()=>{'use strict';
 const id='ns-seasonal-overlay-v41',cssid='ns-seasonal-css-v41';
 const safeEffects=new Set(['none','snow','christmas','new_year','vesak']);
 const clamp=(v,a,b)=>Math.min(b,Math.max(a,Number(v)||a));
 function today(){let d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}
 function active(c){let d=today();return !!(c.enabled && (!c.starts_on||c.starts_on<=d) && (!c.ends_on||c.ends_on>=d) && !matchMedia('(prefers-reduced-motion: reduce)').matches)}
 function ensureStyles(){if(document.getElementById(cssid))return;let s=document.createElement('style');s.id=cssid;s.textContent=`
 #${id}{position:fixed;inset:0;pointer-events:none;overflow:hidden;z-index:9000;contain:layout style paint}
 #${id} .nsfx{position:absolute;top:-6%;color:#e8f7ff;opacity:.8;will-change:transform;animation:nsfxfall var(--dur) linear infinite;animation-delay:var(--delay);left:var(--left);font-size:var(--size);text-shadow:0 1px 3px #6687b5}
 #${id}.new_year .nsfx{color:var(--particle-color);text-shadow:none;border-radius:2px}
 #${id}.vesak .nsfx{color:#ffc74d;opacity:.72;text-shadow:0 0 10px #ffbc44}
 #${id} .nstag{position:absolute;top:70px;right:12px;background:#122850bd;color:white;padding:4px 9px;border-radius:12px;font:600 12px Arial,sans-serif}
 @keyframes nsfxfall{from{transform:translate3d(0,-8vh,0) rotate(0deg)}to{transform:translate3d(var(--drift),115vh,0) rotate(220deg)}}
 @media(prefers-reduced-motion:reduce){#${id}{display:none}}
 `;document.head.appendChild(s)}
 function apply(raw){const c={...raw};if(!safeEffects.has(c.effect))c.effect='none';let old=document.getElementById(id);if(old)old.remove();
  if(c.effect==='none'||!active(c))return;
  ensureStyles();let panel=document.createElement('div');panel.id=id;panel.className=c.effect;
  let count=clamp(c.density,10,50),char=c.effect==='new_year'?'■':c.effect==='vesak'?'✦':'❄';
  // Do not make animations clickable or interfere with payment/printing.
  for(let i=0;i<count;i++){let x=document.createElement('span');x.className='nsfx';x.textContent=char;
   x.style.setProperty('--left',(i*97.3/count+(i*17%11))%100+'%');
   x.style.setProperty('--size',(c.effect==='new_year'?5:8)+(i*7%11)+'px');
   x.style.setProperty('--delay',(-1*(i*2.31%24)).toFixed(2)+'s');
   x.style.setProperty('--dur',(12+i*3%13)+'s');
   x.style.setProperty('--drift',((i*13%17)-8)+'vw');
   if(c.effect==='new_year')x.style.setProperty('--particle-color',['#ffce38','#66e3ff','#ed76d4','#b4ff8a'][i%4]);
   panel.appendChild(x)}
  if(c.effect==='christmas'){let x=document.createElement('div');x.className='nstag';x.textContent='🎄 Merry Christmas';panel.appendChild(x)}
  document.body.appendChild(panel)
 }
 window.NSSeasonalUI={apply,clear:()=>{document.getElementById(id)?.remove()}};
})();
