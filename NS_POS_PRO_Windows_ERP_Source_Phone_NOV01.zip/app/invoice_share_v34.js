/* NS POS PRO v3.4 - WhatsApp invoice sharing, saved invoices only */
(()=>{
'use strict';
const receiptActions=document.querySelector('#previewModal .actions');
if(!receiptActions)return;
const btn=document.createElement('button');btn.type='button';btn.id='ns34ShareInvoiceWhatsApp';
btn.className='secondary';btn.textContent='🟢 Share Invoice via WhatsApp';receiptActions.append(btn);
const format=v=>(Number(v)||0).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2});
function textFor(inv){
 const business=inv.business||db.settings||{};
 const lines=(inv.lines||[]).map(l=>{
    let base=Number(l.qty)||0,amount=base*(Number(l.rate)||0);
    let display=(l.displayQty??l.qty)+' '+(l.unit||'pcs');
    return '• '+(l.name||'Item')+' — '+display+' = Rs. '+format(amount);
 });
 return [business.name||'Business','INVOICE: '+inv.number,
 'Date: '+new Date(inv.date||Date.now()).toLocaleString(),
 'Customer: '+(inv.customer||'Walk-in Customer'),
 inv.customerAddress?'Address: '+inv.customerAddress:'',
 '',...lines,'','Subtotal: Rs. '+format(inv.subtotal),
 'Discount: Rs. '+format(inv.discount),'TOTAL: Rs. '+format(inv.total),
 'Paid: Rs. '+format(inv.paid),'Balance: Rs. '+format(inv.balance),
 'Thank you!'].filter(x=>x!==null).join('\n');
}
btn.textContent='🟢 Share Bill JPG via WhatsApp';
btn.onclick=async()=>{
 const inv=previewInvoice;
 if(!inv||!db.invoices.some(i=>i.id===inv.id))return toast('Save the invoice before sharing');
 if(btn.disabled)return;
 btn.disabled=true;
 const previous=btn.textContent;
 btn.textContent='⏳ Preparing Bill JPG...';
 try{
   if(typeof window.NS35_makeInvoiceJpg!=='function')throw new Error('JPG generator unavailable');
   const dataUrl=await window.NS35_makeInvoiceJpg(inv);
   const name='NS-Invoice-'+String(inv.number||'bill').replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,60)+'.jpg';
   if(window.AndroidPrinter&&typeof window.AndroidPrinter.shareJpeg==='function'){
     // Native bridge opens Android's share UI with the actual image attachment.
     window.AndroidPrinter.shareJpeg(name,dataUrl);
     return;
   }
   if(navigator.share&&navigator.canShare){
     const blob=await (await fetch(dataUrl)).blob();
     const file=new File([blob],name,{type:'image/jpeg'});
     if(navigator.canShare({files:[file]})){
       await navigator.share({files:[file],title:'Invoice '+(inv.number||'')});
       return;
     }
   }
   // Browser fallback: never imply the JPG is attached when only a text link opens.
   if(typeof window.NS24_saveJpg==='function'){
     await window.NS24_saveJpg();
     toast('JPG saved. Attach the saved image in WhatsApp.');
   }else throw new Error('Image sharing not supported on this device');
 }catch(err){
   if(err&&err.name==='AbortError')return;
   toast('WhatsApp JPG share failed: '+(err?.message||String(err)));
 }finally{btn.disabled=false;btn.textContent=previous;}
};
})();
