/* NS POS PRO v2.9 - Shared Shop GPS Directory
 * Separate, optional Cloudflare Worker + D1 login. No subscription system.
 * Stores ONLY shop locations in the cloud; invoices/stock remain device-local.
 */
(() => {
'use strict';
const kSettings='ns_shop_location_cfg_v29',kSession='ns_shop_location_session_v29';
let config=read(kSettings,{url:'',slug:''}),session=read(kSession,null);
let shops=[],online=false,lastSync='',busy=false,editId='',pendingGPS=false;
function pendingKey(){return 'ns_shop_pending_v32_'+encodeURIComponent(String(window.db?.settings?.name||'NS-POS').toLowerCase().trim())}
function pendingList(){const p=read(pendingKey(),[]);return Array.isArray(p)?p:[]}
function savePending(list){write(pendingKey(),list)}
function mergeLocal(items){const byId=new Map((items||[]).map(x=>[x.id,x]));pendingList().forEach(x=>byId.set(x.id,x));return [...byId.values()]}
function el(id){return document.getElementById(id)}
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key))||fallback}catch(e){return fallback}}
function write(key,data){localStorage.setItem(key,JSON.stringify(data))}
function e(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function digits(n){return Number(n).toFixed(6)}
function key(){return 'ns_shop_directory_'+encodeURIComponent(config.url+'|'+config.slug)}
function restoreCache(){let cached=read(key(),[]);if(!Array.isArray(cached))cached=[];shops=mergeLocal(cached)}
function okMessage(t){const box=el('nsLocMessage');if(box){box.textContent=t;box.style.color='#245187'}}
function errMessage(t){const box=el('nsLocMessage');if(box){box.textContent=t;box.style.color='#ba263f'}}
async function call(path,method='GET',body=null,authenticated=true){
 if(!/^https:\/\/[^\s/]+/.test(config.url))throw Error('Enter HTTPS Worker URL in Cloud Location Settings');
 const controller=new AbortController(),tm=setTimeout(()=>controller.abort(),12000);
 try{
  const r=await fetch(config.url.replace(/\/$/,'')+path,{method,headers:{'Content-Type':'application/json',...(authenticated&&session?.token?{'Authorization':'Bearer '+session.token}:{})},body:body===null?undefined:JSON.stringify(body),signal:controller.signal,cache:'no-store'});
  const data=await r.json();if(!r.ok)throw Error(data.error||'Server error '+r.status);
  return data;
 }finally{clearTimeout(tm)}
}
function template(){
 const nav=el('tabs');if(!nav||!document.querySelector('main'))return;
 const button=document.createElement('button');button.dataset.page='shops';button.textContent='📍 Shops Map';button.addEventListener('click',()=>navigate('shops'));nav.append(button);
 const panel=document.createElement('section');panel.className='page';panel.id='shops';
 panel.innerHTML=`
 <div class="panel ns32-shops-header"><div class="row"><h2>📍 Shops Map</h2><span class="pill" id="nsLocState">Device only</span></div>
 <div id="nsLocMessage" class="hint ns32-loc-message" aria-live="polite"></div></div>
 <div class="panel ns32-form"><h2>🏪 Save Shop</h2>
  <div class="row"><div class="field"><label>Shop Name *</label><input id="nsLocName" placeholder="Shop name" maxlength="120"></div><div class="field"><label>Phone</label><input id="nsLocPhone" type="tel" placeholder="Phone number"></div></div>
  <div class="field"><label>Address</label><input id="nsLocAddress" placeholder="Road, town"></div>
  <div class="field"><label>Delivery Notes</label><textarea id="nsLocNotes" placeholder="Landmark / delivery note" rows="2"></textarea></div>
  <div class="ns32-location-actions"><button class="primary" type="button" id="nsLocGPS">📍 Location</button><button class="secondary" type="button" id="nsLocShowPin">🗺️ View Pin</button></div>
  <div id="nsLocPinInfo" class="ns32-pin-info">No location selected</div>
  <div class="row ns32-coords"><div class="field"><label>Latitude</label><input id="nsLocLat" inputmode="decimal" placeholder="Latitude"></div><div class="field"><label>Longitude</label><input id="nsLocLon" inputmode="decimal" placeholder="Longitude"></div></div>
  <div class="actions"><button class="primary ns32-save" type="button" id="nsLocSave">💾 Save Location</button><button class="secondary" type="button" id="nsLocClear">Clear</button></div>
 </div>
 <div class="panel"><div class="row"><h2>🗂 Saved Shops</h2><button class="secondary sm" type="button" id="nsLocRefresh">↻ Sync</button></div>
  <div class="field"><input id="nsLocSearch" placeholder="Search shops" aria-label="Search shops"></div>
  <div class="hint" id="nsLocSyncInfo"></div><div id="nsLocResults"></div>
 </div>
 <div class="panel"><details id="nsLocSetup"><summary><b>☁ Cloud Sync</b></summary>
  <div class="row" style="margin-top:12px"><div class="field"><label>Server URL</label><input id="nsLocUrl" placeholder="https://example.workers.dev" autocomplete="off"></div><div class="field"><label>Business Code</label><input id="nsLocSlug" placeholder="business-code"></div></div>
  <div class="row"><div class="field"><label>Username</label><input id="nsLocUser" autocomplete="username" placeholder="Username"></div><div class="field"><label>Password</label><input id="nsLocPassword" type="password" autocomplete="current-password" placeholder="Password"></div></div>
  <div class="actions"><button class="primary" id="nsLocLogin" type="button">Cloud Login</button><button class="secondary" id="nsLocLogout" type="button">Log out</button></div>
  <div class="hint" id="nsLocWho"></div>
 </details></div>
 <div class="panel" id="nsLocUsersPanel" style="display:none"><h2>👥 Cloud Rep Accounts</h2>
  <div class="row"><div class="field"><label>Rep Name</label><input id="nsLocNewName" placeholder="Rep name"></div><div class="field"><label>Username</label><input id="nsLocNewUser" placeholder="Username"></div><div class="field"><label>Password</label><input id="nsLocNewPassword" type="password" autocomplete="new-password" placeholder="10+ characters"></div></div>
  <button class="secondary" type="button" id="nsLocAddUser">+ Add Rep</button><div class="hint" id="nsLocUsers"></div>
 </div>`;
 document.querySelector('main').append(panel);
 const inv=el('invoice');if(inv){const actions=inv.querySelector('.panel'); if(actions){const n=document.createElement('div');n.className='row';n.style.marginBottom='12px';n.innerHTML='<button class="secondary sm" id="nsLocSelectForBill" type="button">📍 Choose Saved Shop for Bill</button>';actions.insertBefore(n,actions.firstElementChild);el('nsLocSelectForBill').onclick=()=>navigate('shops')}}
 el('nsLocLogin').onclick=login;el('nsLocLogout').onclick=logout;el('nsLocSave').onclick=saveShop;el('nsLocGPS').onclick=gps;el('nsLocShowPin').onclick=showCapturedPin;el('nsLocClear').onclick=clearForm;el('nsLocRefresh').onclick=refresh;el('nsLocSearch').addEventListener('input',render);el('nsLocAddUser').onclick=addUser;['nsLocLat','nsLocLon'].forEach(id=>el(id).addEventListener('input',updatePinInfo));
 el('nsLocUrl').value=config.url;el('nsLocSlug').value=config.slug;
 restoreCache();render();renderSession();updatePinInfo();if(session?.token)refresh();
}
function renderSession(){const isActive=!!session?.token;el('nsLocWho').textContent=isActive?(session.user.name+' · '+session.user.business):'Connect to share locations between phones';
 el('nsLocState').textContent=isActive?(online?'☁ Synced':'📱 Offline'):'📱 Device only';
 el('nsLocUsersPanel').style.display=isActive&&session.user.role==='admin'?'':'none';

}
async function login(){if(busy)return;config={url:el('nsLocUrl').value.trim().replace(/\/$/,''),slug:el('nsLocSlug').value.trim().toLowerCase()};
 if(!config.url.startsWith('https://')||!config.slug)return errMessage('HTTPS Worker URL + Business Code are required');
 const username=el('nsLocUser').value.trim(),password=el('nsLocPassword').value;
 if(!username||!password)return errMessage('Enter cloud username and password');
 busy=true;okMessage('Connecting…');try{
   const data=await call('/login','POST',{business_slug:config.slug,username,password},false);
   session={token:data.token,user:data.user,expires:data.expires};write(kSettings,config);write(kSession,session);el('nsLocPassword').value='';online=true;restoreCache();renderSession();el('nsLocSetup').open=false;okMessage('Connected');await refresh();
 }catch(ex){online=false;errMessage(ex.message||'Login failed')}finally{busy=false}
}
async function logout(){if(session?.token){try{await call('/logout','POST')}catch(e){}}session=null;localStorage.removeItem(kSession);online=false;restoreCache();renderSession();render();okMessage('Signed out')}
async function pushPending(){
 if(!session?.token)return;
 const pending=pendingList();if(!pending.length)return;
 const remaining=[];
 for(const item of pending){try{await call('/shops','POST',item)}catch(ex){remaining.push(item)}}
 savePending(remaining);
}
async function refresh(){
 if(!session?.token){restoreCache();render();renderSession();return okMessage('Saved on this device')}
 try{
  await pushPending();
  const data=await call('/shops');
  const cloud=Array.isArray(data.shops)?data.shops:[];
  online=true;lastSync=data.synced_at||new Date().toISOString();
  write(key(),cloud);shops=mergeLocal(cloud);
  okMessage(pendingList().length?'Some pins saved on device':'Locations synced');
 }catch(ex){online=false;restoreCache();errMessage('Sync unavailable · Saved pins stay on this device')}
 render();renderSession();if(session?.user?.role==='admin'&&online)loadUsers();
}

function clearForm(){editId='';for(const id of ['nsLocName','nsLocPhone','nsLocAddress','nsLocNotes','nsLocLat','nsLocLon'])el(id).value='';updatePinInfo();okMessage('')}
function editShop(id){const s=shops.find(x=>x.id===id);if(!s)return;editId=id;el('nsLocName').value=s.name;el('nsLocPhone').value=s.phone||'';el('nsLocAddress').value=s.address||'';el('nsLocNotes').value=s.notes||'';el('nsLocLat').value=s.lat;el('nsLocLon').value=s.lon;navigate('shops');el('nsLocName').scrollIntoView({behavior:'smooth',block:'center'});updatePinInfo();okMessage('Editing '+s.name)}
async function saveShop(){
 const latText=el('nsLocLat').value.trim(),lonText=el('nsLocLon').value.trim();
 const item={id:editId||'shop-'+(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2)),name:el('nsLocName').value.trim(),phone:el('nsLocPhone').value.trim(),address:el('nsLocAddress').value.trim(),notes:el('nsLocNotes').value.trim(),lat:Number(latText),lon:Number(lonText)};
 if(!item.name)return errMessage('Enter Shop Name');
 if(!latText||!lonText||!Number.isFinite(item.lat)||!Number.isFinite(item.lon)||Math.abs(item.lat)>90||Math.abs(item.lon)>180)return errMessage('Tap Location first');
 el('nsLocSave').disabled=true;
 try{
  if(session?.token){
   try{await call('/shops','POST',item);await refresh();clearForm();return okMessage('Shop saved & synced')}
   catch(ex){online=false;}
  }
  const pending=pendingList();const ix=pending.findIndex(s=>s.id===item.id);
  if(ix===-1)pending.push(item);else pending[ix]=item;
  savePending(pending);
  shops=mergeLocal(shops);render();renderSession();clearForm();
  okMessage('Saved on this device'+(session?.token?' · Sync pending':''));
 }finally{el('nsLocSave').disabled=false}
}

const kArchivedShops='ns_shop_admin_archived_v1';
function shopArchived(){const ids=read(kArchivedShops,[]);return Array.isArray(ids)?ids:[]}
function adminCanManageShop(){return typeof NS2_admin==='function'&&NS2_admin()&&window.NSCloud?.getRole?.()!=='rep'}
function adminArchiveShop(id){
 if(!adminCanManageShop())return errMessage('Admin PIN required to manage shop data');
 const item=shops.find(s=>s.id===id);if(!item)return;
 const pending=pendingList(),isLocal=pending.some(x=>x.id===id);
 const reason=prompt('Reason to '+(isLocal?'delete local draft':'archive synced shop')+' '+item.name+' (5+ characters):');
 if(reason===null)return;if(reason.trim().length<5)return errMessage('Enter a reason (5+ characters)');
 if(!confirm(isLocal?'Delete this UN-SYNCED local shop?':'Hide this SYNCED shop on THIS DEVICE only? Cloud copy will remain.'))return;
 if(isLocal){savePending(pending.filter(x=>x.id!==id));const remaining=read(key(),[]).filter(x=>x.id!==id);write(key(),remaining);shops=shops.filter(x=>x.id!==id)}
 else{const ids=new Set(shopArchived());ids.add(id);write(kArchivedShops,[...ids]);}
 const audits=read('ns_shop_admin_audit_v1',[]);audits.unshift({id,at:new Date().toISOString(),action:isLocal?'delete-local':'archive-local',reason:reason.trim(),by:NS2_USER?.name||'Admin',name:item.name});write('ns_shop_admin_audit_v1',audits.slice(0,200));
 render();okMessage(isLocal?'Unsynced shop deleted on this device':'Shop archived on this device; cloud record remains');
}
function adminRestoreShop(id){if(!adminCanManageShop())return errMessage('Admin PIN required');write(kArchivedShops,shopArchived().filter(x=>x!==id));render();okMessage('Shop restored on this device')}
function render(){
 if(!el('nsLocResults'))return;
 const q=(el('nsLocSearch').value||'').toLowerCase().trim();
 const rows=shops.filter(s=>(s.name+' '+s.phone+' '+s.address+' '+s.notes).toLowerCase().includes(q) && (!shopArchived().includes(s.id)||q));
 const local=new Set(pendingList().map(s=>s.id));
 el('nsLocSyncInfo').textContent=rows.length+' shop'+(rows.length===1?'':'s');
 el('nsLocResults').innerHTML=rows.length?rows.map(s=>`<div class="ns-shop-card"><div class="row"><strong>🏪 ${e(s.name)}</strong><span class="pill right">${local.has(s.id)?'📱 Device only':'☁ Synced'}</span></div><div class="hint">${e(s.address||'')}${s.phone?' · '+e(s.phone):''}</div>${s.notes?`<div class="hint">${e(s.notes)}</div>`:''}<div class="row" style="margin-top:8px"><button type="button" class="primary sm" data-shop-action="route" data-id="${e(s.id)}">↗ Navigate</button><button type="button" class="secondary sm" data-shop-action="map" data-id="${e(s.id)}">🗺 Google Maps</button><button type="button" class="secondary sm" data-shop-action="share" data-id="${e(s.id)}">🟢 Share Location</button><button type="button" class="secondary sm" data-shop-action="bill" data-id="${e(s.id)}">🧾 Use on Bill</button><button type="button" class="secondary sm" data-shop-action="edit" data-id="${e(s.id)}">Edit</button>${adminCanManageShop()?`<button type="button" class="secondary sm" data-shop-action="${shopArchived().includes(s.id)?'restore':'archive'}" data-id="${e(s.id)}">${shopArchived().includes(s.id)?'Restore':'Archive / Delete Local'}</button>`:''}</div></div>`).join(''):'<div class="empty">No saved shops</div>';
 el('nsLocResults').querySelectorAll('button[data-shop-action]').forEach(b=>b.addEventListener('click',()=>{const s=shops.find(x=>x.id===b.dataset.id);if(!s)return;({route:()=>directions(s),map:()=>showMap(s),share:()=>shareLocation(s),bill:()=>useOnBill(s),edit:()=>editShop(s.id),archive:()=>adminArchiveShop(s.id),restore:()=>adminRestoreShop(s.id)})[b.dataset.shopAction]();}));
}
function openMapsURL(url){if(window.AndroidPrinter?.openMaps)window.AndroidPrinter.openMaps(url);else window.open(url,'_blank','noopener,noreferrer')}
function mapPin(s){return 'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(Number(s.lat)+','+Number(s.lon))}
function shareLocation(s){
 const lat=Number(s.lat),lon=Number(s.lon);
 if(!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)
   return errMessage('Save a valid shop GPS location before sharing');
 const text=[
   '🏪 '+String(s.name||'Shop'),
   s.address?'Address: '+String(s.address):'',
   '📍 '+mapPin({lat,lon})
 ].filter(Boolean).join('\n');
 const url='https://api.whatsapp.com/send?text='+encodeURIComponent(text);
 try{
   if(window.AndroidPrinter&&typeof window.AndroidPrinter.openSharedLink==='function'){
     window.AndroidPrinter.openSharedLink(url);
   }else{
     window.open(url,'_blank','noopener,noreferrer');
   }
 }catch(err){errMessage('Cannot open WhatsApp: '+(err?.message||String(err)));}
}
function directions(s){if(!Number.isFinite(Number(s.lat))||!Number.isFinite(Number(s.lon)))return errMessage('No GPS Pin');openMapsURL('https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(Number(s.lat)+','+Number(s.lon))+'&travelmode=driving')}
function showMap(s){if(!Number.isFinite(Number(s.lat))||!Number.isFinite(Number(s.lon)))return errMessage('No GPS Pin');openMapsURL(mapPin(s))}
function pinFromFields(){const la=el('nsLocLat').value.trim(),lo=el('nsLocLon').value.trim();if(!la||!lo)return null;const lat=Number(la),lon=Number(lo);return Number.isFinite(lat)&&Number.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180?{lat,lon}:null}
function updatePinInfo(){const p=pinFromFields();el('nsLocPinInfo').textContent=p?'📍 '+digits(p.lat)+', '+digits(p.lon):'No location selected';}
function showCapturedPin(){const p=pinFromFields();if(!p)return errMessage('Tap Location first');showMap(p)}

function useOnBill(s){if(el('iCustomer'))el('iCustomer').value=s.name;if(el('iPhone'))el('iPhone').value=s.phone||'';okMessage('Selected '+s.name+' for invoice');navigate('invoice')}
function gps(){pendingGPS=true;okMessage('Getting GPS…');if(window.AndroidPrinter?.getShopLocation){window.AndroidPrinter.getShopLocation();return}
 if(!navigator.geolocation){pendingGPS=false;return errMessage('GPS unavailable')}
 navigator.geolocation.getCurrentPosition(p=>locationOK(p.coords.latitude,p.coords.longitude,p.coords.accuracy),ex=>{pendingGPS=false;errMessage('GPS unavailable: '+ex.message)},{enableHighAccuracy:true,timeout:20000,maximumAge:15000});
}
function locationOK(lat,lon,accuracy){pendingGPS=false;if(!Number.isFinite(Number(lat))||!Number.isFinite(Number(lon)))return errMessage('Invalid GPS');el('nsLocLat').value=digits(lat);el('nsLocLon').value=digits(lon);updatePinInfo();okMessage('GPS ready · Accuracy ~'+Math.round(accuracy||0)+'m · Save Location');if(window.AndroidPrinter?.openMaps)showCapturedPin()}
window.NSLOC_locationOK=locationOK;
window.NSLOC_locationError=(msg)=>{pendingGPS=false;errMessage('GPS error: '+msg)};
async function loadUsers(){try{const result=await call('/users');el('nsLocUsers').innerHTML=result.users.map(u=>'<div class="ns-shop-user"><b>'+e(u.display_name)+'</b> · '+e(u.username)+' · '+e(u.role)+'</div>').join('')}catch(e){}}
async function addUser(){if(session?.user?.role!=='admin')return errMessage('Cloud Admin only');const username=el('nsLocNewUser').value.trim(),display_name=el('nsLocNewName').value.trim(),password=el('nsLocNewPassword').value;
 try{await call('/users','POST',{username,display_name,password});['nsLocNewName','nsLocNewUser','nsLocNewPassword'].forEach(id=>el(id).value='');okMessage('Rep cloud account created. Share business code, username and password privately.');await loadUsers();}
 catch(ex){errMessage(ex.message)}
}
function init(){template()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
