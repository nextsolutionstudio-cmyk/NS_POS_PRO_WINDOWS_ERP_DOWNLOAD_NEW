/* NS POS PRO LIFETIME v2.4 JPG RECEIPT — no external dependencies */
(function(){
 'use strict';
 const g=id=>document.getElementById(id);
 const moneyNum=n=>Number(n||0).toFixed(2);
 const notDraft=()=>{
   if(typeof previewInvoice==='undefined'||!previewInvoice)return false;
   return db.invoices.some(i=>i.id===previewInvoice.id) ||
      (previewInvoice.kind==='return' && db.returns?.some(r=>'return-'+r.id===previewInvoice.id));
 };
 function safeName(s){return String(s||'receipt').replace(/[^\w-]/g,'_').slice(0,70);}
 function loadImg(data){return new Promise(resolve=>{
   if(!data||!/^data:image\//.test(data))return resolve(null);
   const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>resolve(null);img.src=data;
 });}
 async function makeJpg(inv){
   const b=inv.business||db.settings||{};
   const width=576, left=26, right=550, contentW=width-left*2, pad=12;
   const cvMeasure=document.createElement('canvas');const measure=cvMeasure.getContext('2d');
   const entries=[];
   const font=(sz=19,bold=false)=>`${bold?'bold ':''}${sz}px Arial, Noto Sans Sinhala, sans-serif`;
   function wrap(text,maxWidth,sz=19,bold=false){
     measure.font=font(sz,bold);let parts=String(text||'').split(/\s+/),res=[],line='';
     for(let word of parts){
       if(!word)continue;
       let t=line?line+' '+word:word;
       if(measure.measureText(t).width<=maxWidth){line=t;continue;}
       if(line){res.push(line);line='';}
       // Break long SKU/words in a Unicode-aware manner
       let token='';for(let char of Array.from(word)){
         if(token && measure.measureText(token+char).width>maxWidth){res.push(token);token='';}
         token+=char;
       }
       line=token;
     }
     if(line)res.push(line);
     return res.length?res:[''];
   }
   function text(t,opt={}){const {sz=19,bold=false,align='left',line=27,margin=0}=opt;
      for(const ln of wrap(t,opt.maxWidth||contentW,sz,bold))entries.push({k:'text',ln,sz,bold,align,line,margin});}
   function space(px=12){entries.push({k:'space',px});}
   function hr(){entries.push({k:'line'});}
   text(b.name||'BUSINESS',{sz:34,bold:true,align:'center',line:43});
   if(b.address)text(b.address,{sz:18,align:'center',line:26});
   for(const phone of [b.phone,b.phone2,b.phone3].filter(Boolean))text('Tel: '+phone,{sz:20,align:'center'});
   hr();
   text('INVOICE: '+(inv.number||''),{bold:true,sz:20});
   text('DATE: '+new Date(inv.date||Date.now()).toLocaleString(),{sz:18});
   text('CUSTOMER: '+(inv.customer||'Cash Customer'),{sz:20,bold:true});
   if(inv.phone)text('PHONE: '+inv.phone,{sz:19});
   if(inv.customerAddress)text('DELIVERY: '+inv.customerAddress,{sz:18});
   if(b.email)text('Email: '+b.email,{sz:17,align:'center'});
   if(b.website)text('Web: '+b.website,{sz:17,align:'center'});
   hr();
   text('ITEM', {sz:17,bold:true});
   for(const item of (inv.lines||[])){
     text(item.name||'Item',{sz:20,bold:true,line:29});
     const line=`${item.displayQty??item.qty} ${item.unit||'pcs'} x ${moneyNum(item.displayQty?Number(item.qty||0)*Number(item.rate||0)/Number(item.displayQty):item.rate)} = Rs. ${moneyNum(Number(item.qty||0)*Number(item.rate||0))}`;
     text(line,{sz:18,align:'right',line:25});space(5);
   }
   hr();
   text('SUBTOTAL: Rs. '+moneyNum(inv.subtotal),{sz:21,bold:true,align:'right'});
   text('DISCOUNT: Rs. '+moneyNum(inv.discount),{sz:19,align:'right'});
   if(inv.taxApplied===true && Number(inv.taxRate)>0){
     text('Taxable: Rs. '+moneyNum(inv.taxBase),{sz:18,align:'right'});
     const taxLabel=String(inv.taxLabel||'Tax').replace(/[\r\n]/g,' ').slice(0,24);
     text(taxLabel+' '+Number(inv.taxRate).toFixed(2)+'%'+(inv.taxMode==='inclusive'?' (incl.)':'')+': Rs. '+moneyNum(inv.taxAmount),{sz:20,align:'right'});
   }
   text('TOTAL: Rs. '+moneyNum(inv.total),{sz:24,bold:true,line:34,align:'right'});
   text('PAID: Rs. '+moneyNum(inv.paid),{sz:19,align:'right'});
   text('BALANCE: Rs. '+moneyNum(inv.balance),{sz:21,bold:true,align:'right'});
   text('PAYMENT: '+(inv.payment||'Cash'),{sz:19});
   if(inv.rep||inv.repName)text('SALES REP: '+(inv.rep||inv.repName),{sz:18});
   if(inv.cheque?.number)text('CHEQUE: '+inv.cheque.number,{sz:18});
   hr();text(inv.note||b.footer||'Thank you! Visit again.',{sz:21,align:'center'});
   space(10);text('© Next Solution Studio · All rights reserved.',{sz:15,align:'center',line:23});space(15);
   const logo=await loadImg(db.settings.receiptLogo === false ? '' : b.logo);
   const logoH=logo?Math.min(125,Math.round(logo.height/Math.max(1,logo.width)*280)):0;
   // Pre-measure to avoid huge canvases, then draw at 2x resolution for clear sharing/printing.
   let height=26+(logo?logoH+14:0);
   for(const en of entries){height+=en.k==='text'?en.line+en.margin:en.k==='line'?21:en.px;}
   height+=20;
   const scale=height>3000?1.5:2;
   const canvas=document.createElement('canvas');canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale);
   const ctx=canvas.getContext('2d');if(!ctx)throw Error('Canvas unavailable');
   ctx.scale(scale,scale);ctx.fillStyle='#fff';ctx.fillRect(0,0,width,height);
   let y=28;
   if(logo){let w=Math.min(280,Math.round(logo.width*Math.min(logoH/logo.height,280/logo.width)));
      ctx.drawImage(logo,(width-w)/2,y,w,logoH);y+=logoH+14;}
   for(const en of entries){
     if(en.k==='space'){y+=en.px;continue;}
     if(en.k==='line'){ctx.strokeStyle='#666';ctx.lineWidth=1;ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(left,y+10);ctx.lineTo(right,y+10);ctx.stroke();ctx.setLineDash([]);y+=21;continue;}
     ctx.fillStyle='#111';ctx.font=font(en.sz,en.bold);ctx.textAlign=en.align;ctx.textBaseline='alphabetic';
     const xx=en.align==='center'?width/2:en.align==='right'?right:left;
     ctx.fillText(en.ln,xx,y+en.sz);y+=en.line+en.margin;
   }
   return canvas.toDataURL('image/jpeg',0.92);
 }
 window.NS35_makeInvoiceJpg=makeJpg;
 function ios(){return /iPad|iPhone|iPod/.test(navigator.userAgent)}
 function downloadJpg(name,dataUrl){
   const a=document.createElement('a');a.href=dataUrl;a.download=name;document.body.appendChild(a);a.click();a.remove();
 }
 async function shareOrSaveJpg(name,dataUrl){
   if(window.NSDesktop && typeof window.NSDesktop.saveJpg==='function'){
     const result=await window.NSDesktop.saveJpg(name,dataUrl);
     if(result?.saved)toast('JPG saved: '+result.path);
     else if(result?.error)throw Error(result.error);
     return;
   }
   if(window.AndroidPrinter && typeof AndroidPrinter.saveJpeg==='function'){
     AndroidPrinter.saveJpeg(name,dataUrl);return;
   }
   if(ios() && navigator.share && navigator.canShare){
     try{
       const response=await fetch(dataUrl);const blob=await response.blob();
       const file=new File([blob],name,{type:'image/jpeg'});
       if(navigator.canShare({files:[file]})){await navigator.share({files:[file],title:'Invoice '+name});return;}
     }catch(e){if(e.name==='AbortError')return;}
   }
   downloadJpg(name,dataUrl);
   if(ios()){
      // Safari/PWA downloads can be accessed in Files, Share sheet may support Save Image.
      toast('JPG downloaded. Open Downloads / Files, or share the image to Photos.');
   } else toast('JPG bill downloaded.');
 }
 window.NS24_saveJpg=async function(){
   if(!notDraft())return toast('Save Bill before exporting JPG.');
   let btn=g('ns24SaveJpg');if(btn?.disabled)return;
   if(btn){btn.disabled=true;btn.textContent='⏳ Creating JPG…';}
   try{
      const data=await makeJpg(previewInvoice),name='NS-Invoice-'+safeName(previewInvoice.number)+'.jpg';
      await shareOrSaveJpg(name,data);
   }catch(e){toast('JPG error: '+e.message);}
   finally{if(btn){btn.disabled=false;btn.textContent='🖼 Save Bill JPG';}}
 };
 const zone=g('ns21PrintNow')?.parentNode || g('btPrintButton')?.parentNode;
 if(zone){const button=document.createElement('button');button.type='button';button.id='ns24SaveJpg';button.className='secondary';button.textContent='🖼 Save Bill JPG';button.addEventListener('click',NS24_saveJpg);zone.appendChild(button);}
 const hint=g('ns21PrintInfo');if(hint)hint.textContent='If Bluetooth printing fails, tap Save Bill JPG. Android: choose a Files folder; iPhone: Share/Files. Printing works only in ESC/POS receipt mode.';
 const t=g('ns21TestPrint');if(t)t.textContent='🧾 Test Text Only (no logo)';
})();
