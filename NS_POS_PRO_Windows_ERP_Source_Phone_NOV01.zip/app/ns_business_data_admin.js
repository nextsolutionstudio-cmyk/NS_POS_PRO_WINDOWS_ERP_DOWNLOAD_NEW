/* NS POS PRO: tenant-local Admin Business Data Manager.
   Financial source transactions are audit-preserved; developer code and cloud subscriptions are never edited. */
(()=>{'use strict';
const $m=id=>document.getElementById(id);
const isAdmin=()=>typeof NS2_admin==='function' && NS2_admin() && (!window.NSCloud?.getRole || window.NSCloud.getRole()!=='rep');
const E=v=>esc(v);
const dict={en:{title:'Admin · Business Data',sub:'Edit or remove records added by your business. Developer features and subscriptions are protected.',products:'Products',orders:'Orders',grns:'GRN / Stock History',bills:'Bills',shops:'Customer Shops',audit:'Audit Log',arch:'Archive',restore:'Restore',del:'Delete',edit:'Edit',reverse:'Reverse GRN',void:'Void / Edit Bill',note:'Financial history cannot be erased. Use Edit / Void with an audit reason.',backup:'Backup Business Data',empty:'No records',data:'Manage Data'},si:{title:'පරිපාලක · ව්‍යාපාරික දත්ත',sub:'ඔබේ ව්‍යාපාරය ඇතුළත් කළ දත්ත වෙනස් කරන්න හෝ ඉවත් කරන්න. Developer Features හා Subscription ආරක්ෂිතයි.',products:'භාණ්ඩ',orders:'ඇණවුම්',grns:'GRN / තොග ඉතිහාසය',bills:'බිල්පත්',shops:'වෙළෙඳසැල්',audit:'වෙනස්කම් ඉතිහාසය',arch:'සඟවන්න',restore:'නැවත පෙන්වන්න',del:'මකන්න',edit:'වෙනස් කරන්න',reverse:'GRN අවලංගු කරන්න',void:'බිල්පත අවලංගු / වෙනස්',note:'ගිණුම් ඉතිහාසය මකා නොදමයි. හේතුවක් සහිතව Edit / Void කරන්න.',backup:'දත්ත Backup කරන්න',empty:'දත්ත නැහැ',data:'දත්ත පාලනය'},ta:{title:'நிர்வாகி · வணிகத் தரவு',sub:'உங்கள் வணிகத்தில் சேர்த்த பதிவுகளை திருத்தலாம் அல்லது நீக்கலாம். Developer அம்சங்கள் மற்றும் Subscription பாதுகாக்கப்படும்.',products:'பொருட்கள்',orders:'ஆர்டர்கள்',grns:'GRN / இருப்பு வரலாறு',bills:'பில்கள்',shops:'கடைகள்',audit:'மாற்ற வரலாறு',arch:'மறை',restore:'மீட்டமை',del:'நீக்கு',edit:'திருத்து',reverse:'GRN ரத்து',void:'பில் ரத்து / திருத்து',note:'கணக்கு பதிவுகள் அழிக்கப்படாது. காரணத்துடன் Edit / Void செய்யவும்.',backup:'தரவு காப்பு',empty:'பதிவுகள் இல்லை',data:'தரவு மேலாண்மை'}};
const L=()=>dict[window.NSLang?.get?.()||localStorage.getItem('nspos_ui_lang')||'en']||dict.en;
const who=()=>NS2_USER?.name||'Business Admin';
const stamp=()=>new Date().toISOString();
let tab='products';
function guard(){if(!isAdmin()){toast('Business Admin access required');return false}return true}
function update(mut){const old=JSON.stringify(db);try{mut();if(!save()){db=JSON.parse(old);return false}renderAll();draw();return true}catch(ex){db=JSON.parse(old);toast('Could not save: '+ex.message);return false}}
function log(type,action,item,reason,before){db.adminDataAudit=Array.isArray(db.adminDataAudit)?db.adminDataAudit:[];db.adminDataAudit.unshift({id:uid(),at:stamp(),type,action,item,reason,by:who(),before});}
function askReason(action,name){const reply=prompt(action+' — '+name+'\nEnter a reason (at least 5 characters):');if(reply===null)return null;if(reply.trim().length<5){toast('Enter a reason (minimum 5 characters)');return null}return reply.trim()}
function dependency(product){const id=product.id;const sales=db.invoices?.some(i=>i.lines?.some(l=>l.productId===id));const received=db.grns?.some(g=>g.lines?.some(l=>l.productId===id));const vehicle=db.vehicleLedger?.some(x=>x.productId===id);const stock=Number(product.stock)||0;const orders=db.orders?.some(o=>o.lines?.some(l=>l.productId===id||l.name===product.name));return !!(sales||received||vehicle||orders||stock!==0)}
function productAction(action,id){if(!guard())return;const p=db.products.find(x=>x.id===id);if(!p)return;
 if(action==='edit'){editProduct(id);return}
 if(action==='archive'||action==='restore'){const v=action==='archive';const reason=askReason(v?'Archive product':'Restore product',p.name);if(!reason)return;update(()=>{log('product',action,p.name,reason,{...p});p.adminArchived=v;p.adminChangedAt=stamp()});return}
 if(action==='delete'){
   if(dependency(p))return toast('Product used by stock, orders, GRN or bills. Archive it instead.');
   const reason=askReason('Permanently delete unused product',p.name);if(!reason)return;
   if(!confirm('Delete product '+p.name+'? You must have a backup.'))return;
   update(()=>{log('product','delete',p.name,reason,{...p});db.products=db.products.filter(x=>x.id!==id)});
 }
}
function orderAction(action,id){if(!guard())return;const o=db.orders?.find(x=>x.id===id);if(!o)return;
 if(action==='edit'){navigate('orders');const edit=document.querySelector('[data-order-edit="'+CSS.escape(id)+'"]');if(edit)edit.click();return}
 if(action==='delete'){
   if(o.status==='Delivered')return toast('Delivered orders have history. Change status to Cancelled, do not delete.');
   const reason=askReason('Delete customer order',o.number||o.shop);if(!reason)return;
   if(!confirm('Delete order '+o.number+'? This will be kept in audit history.'))return;
   update(()=>{log('order','delete',o.number||o.id,reason,structuredClone(o));db.orders=db.orders.filter(x=>x.id!==id)});
 }
}
function reverseGrn(id){if(!guard())return;const g=db.grns.find(x=>x.id===id);if(!g||g.reversedAt)return;
 const changes=new Map();for(const l of g.lines||[])if(l.productId)changes.set(l.productId,(changes.get(l.productId)||0)+Number(l.qty||0));
 for(const [pid,qty] of changes){const product=db.products.find(p=>p.id===pid);if(!product||Number(product.stock||0)<qty-1e-7)return toast('Insufficient stock to reverse GRN; reconcile sold/transfer stock first.');}
 const reason=askReason('Reverse GRN',g.ref||g.id);if(!reason)return;
 if(!confirm('Reverse GRN and subtract received stock? The GRN history is kept.'))return;
 update(()=>{for(const [pid,qty] of changes){let p=db.products.find(p=>p.id===pid);p.stock=Math.round((Number(p.stock)-qty)*1000)/1000}log('grn','reverse',g.ref||g.id,reason,structuredClone(g));g.reversedAt=stamp();g.reversedBy=who();g.reverseReason=reason});
}
function renderRows(){const lang=L();if(tab==='products')return db.products.map(p=>`<div class="ns-admin-row"><div><b>${E(p.name)}</b><small>${E(p.sku||'')} · ${money(p.price)} · Qty ${E(p.stock)} ${p.adminArchived?'(Archived)':''}</small></div><div class="ns-admin-actions"><button data-what="edit-product" data-id="${E(p.id)}">${lang.edit}</button><button data-what="${p.adminArchived?'restore':'archive'}-product" data-id="${E(p.id)}">${p.adminArchived?lang.restore:lang.arch}</button><button class="danger" data-what="delete-product" data-id="${E(p.id)}">${lang.del}</button></div></div>`).join('');
 if(tab==='orders')return (db.orders||[]).map(o=>`<div class="ns-admin-row"><div><b>${E(o.number||o.shop)}</b><small>${E(o.shop||'')} · ${E(o.status||'Pending')}</small></div><div class="ns-admin-actions"><button data-what="edit-order" data-id="${E(o.id)}">${lang.edit}</button><button class="danger" data-what="delete-order" data-id="${E(o.id)}">${lang.del}</button></div></div>`).join('');
 if(tab==='grns')return (db.grns||[]).map(g=>`<div class="ns-admin-row"><div><b>${E(g.ref||'GRN')}</b><small>${E(g.supplier||'')} · ${money(g.total)} · ${g.reversedAt?'REVERSED':'Saved'}</small></div><div class="ns-admin-actions">${g.reversedAt?'':`<button data-what="reverse-grn" data-id="${E(g.id)}">${lang.reverse}</button>`}</div></div>`).join('');
 if(tab==='bills')return `<p>${E(lang.note)}</p><button data-what="go-bills">${lang.void}</button><p>Returns, credit collections and cheques remain audit-protected.</p>`;
 if(tab==='shops')return `<p>Open Shops Map to edit business-created shop details. Synced shops require server-side delete permissions; an offline deletion will not erase the cloud record.</p><button data-what="go-shops">${lang.shops}</button>`;
 if(tab==='audit')return (db.adminDataAudit||[]).slice(0,120).map(a=>`<div class="ns-admin-row"><div><b>${E(a.action)} · ${E(a.type)}</b><small>${E(a.item)} · ${E(a.by)} · ${E(a.at)}</small><small>${E(a.reason)}</small></div></div>`).join('');return ''}
function draw(){const box=$m('nsBusinessManager');if(!box)return;if(!isAdmin()){box.hidden=true;return}box.hidden=false;const lang=L();$m('nsAdminTitle').textContent=lang.title;$m('nsAdminSub').textContent=lang.sub;$m('nsAdminBackup').textContent=lang.backup;
 box.querySelectorAll('[data-admin-tab]').forEach(b=>{b.textContent=lang[b.dataset.adminTab];b.classList.toggle('active',tab===b.dataset.adminTab)});
 $m('nsAdminRows').innerHTML=renderRows()||`<p>${lang.empty}</p>`;
}
function init(){const settings=$m('settings');if(!settings)return;const sec=document.createElement('div');sec.id='nsBusinessManager';sec.className='panel';sec.hidden=true;
 sec.innerHTML=`<h2 id="nsAdminTitle">Admin · Business Data</h2><p id="nsAdminSub" class="hint"></p><div class="ns-admin-tabs">${['products','orders','grns','bills','shops','audit'].map(v=>`<button class="secondary sm" type="button" data-admin-tab="${v}">${v}</button>`).join('')}</div><div id="nsAdminRows"></div><button class="secondary" id="nsAdminBackup" type="button">Backup Business Data</button><p class="hint">Device-local operations only. Cloud/synced records require their own server-authorized endpoints. This screen does not change developer app code, subscriptions or tenants.</p>`;
 settings.append(sec);
 const style=document.createElement('style');style.textContent=`#nsBusinessManager .ns-admin-tabs{display:flex;gap:5px;flex-wrap:wrap;margin:13px 0}#nsBusinessManager .ns-admin-tabs button.active{background:#1449a0;color:#fff}#nsBusinessManager .ns-admin-row{display:flex;justify-content:space-between;gap:9px;padding:13px 0;border-bottom:1px solid #dfe7f1;flex-wrap:wrap}#nsBusinessManager .ns-admin-row small{display:block;color:#64748b;margin-top:4px;word-break:break-word}#nsBusinessManager .ns-admin-actions{display:flex;gap:5px;flex-wrap:wrap}#nsBusinessManager .ns-admin-actions button{padding:7px 9px;border-radius:8px;border:1px solid #bed1e8;background:#f3f8ff;color:#123f75}#nsBusinessManager .ns-admin-actions button.danger{background:#fff2f2;color:#a12332;border-color:#f9c8c8}`;document.head.append(style);
 sec.addEventListener('click',e=>{let t=e.target.closest('button');if(!t||!guard())return;const ty=t.dataset.what,id=t.dataset.id;
 if(t.dataset.adminTab){tab=t.dataset.adminTab;draw()}
 else if(ty==='go-bills')navigate('history');else if(ty==='go-shops')navigate('shops');
 else if(ty==='reverse-grn')reverseGrn(id);
 else if(ty?.endsWith('-product'))productAction(ty.replace('-product',''),id);
 else if(ty?.endsWith('-order'))orderAction(ty.replace('-order',''),id);
 });$m('nsAdminBackup').onclick=()=>{if(guard())backupData()};
 const oldRender=renderAll;renderAll=function(){oldRender();draw()};
 const oldProductOptions=populateSelects;populateSelects=function(){oldProductOptions();for(const id of ['iProduct','grnProduct']){const select=$m(id);if(select){[...select.options].forEach(opt=>{const product=db.products.find(p=>p.id===opt.value);if(product?.adminArchived)opt.remove()})}}};
 const oldSaveGRN=saveGRN; // Existing GRN handler remains admin-restricted by upgrade.js.
 const oldHistory=renderHistory;renderHistory=function(){oldHistory();};
 const oldDashboard=renderDashboard;renderDashboard=function(){oldDashboard();$m('mProducts').textContent=db.products.filter(p=>!p.adminArchived).length;};
 draw();}
init();window.NSBusinessData={isAdmin,render:draw,productAction};
})();
