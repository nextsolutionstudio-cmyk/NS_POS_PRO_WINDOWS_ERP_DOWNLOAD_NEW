/* NS POS PRO - printer connection diagnostics; read-only, no extra receipt. */
(()=>{'use strict';
const panel=document.getElementById('bluetoothPanel');
if(!panel)return;
const host=document.createElement('div');
host.className='panel';
host.style.cssText='margin-top:12px;padding:14px;border:1px solid #bed6ff;border-radius:14px;background:#eef5ff;color:#12325b';
host.innerHTML='<div style="font-weight:800;margin-bottom:8px">🖨 Printer Connection Check</div>'+
'<p style="margin:0 0 8px;font-size:13px">Pair XP-P301A / XP-P502A once in Phone Settings → Bluetooth. Allow Nearby Devices permission.</p>'+
'<button type="button" id="nsPrinterCheckBtn" class="secondary">🔍 Check Paired Printers</button>'+
'<p id="nsPrinterDiagnostic" aria-live="polite" style="white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px;margin:9px 0 0">Printer check not run yet.</p>';
panel.appendChild(host);
const status=document.getElementById('nsPrinterDiagnostic');
window.NSPRINTER_diagnostic=function(message){status.textContent=String(message||'No results');};
document.getElementById('nsPrinterCheckBtn').addEventListener('click',()=>{
  status.textContent='Checking phone Bluetooth paired devices…';
  if(window.AndroidPrinter && typeof AndroidPrinter.printerDiagnostics==='function'){
    try{AndroidPrinter.printerDiagnostics();}catch(e){status.textContent='Check failed: '+e.message;}
  }else status.textContent='Native Bluetooth print bridge not found. Please install the new Customer Android APK; browser mode cannot access Bluetooth Classic printers.';
});
})();
