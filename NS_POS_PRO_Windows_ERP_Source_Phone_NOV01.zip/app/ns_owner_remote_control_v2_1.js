/* NS POS PRO Customer Control Receiver v2.1 (Android/WebView + Windows/Electron).
   Requires the authenticated NSCloud.repCall adapter and NS OWNER v2 Cloudflare endpoints.
   No owner credentials, arbitrary code, remote wipe, silent install, or direct printer commands.
   Module toggles are UX controls, NOT a replacement for server-side authorization.
*/
(()=>{'use strict';
 const SESSION='nspos_cloud_v1_daily_session';
 const PREFIX='nspos_remote_control_v21_';
 const DEVICE_KEY='nspos_remote_random_device_v21';
 const FEATURE_PAGES={billing:['invoice'],orders:['orders'],grn:['grn'],reports:['reports'],returns:['returns'],customer_credit:['credit','customerCredit'],rep_accounts:['team'],delivery:['delivery'],wholesale:['wholesale'],loyalty:['loyalty']};
 const FEATURE_KEYS=Object.keys(FEATURE_PAGES);
 const APP_VERSION=window.NS_OWNER_CUSTOMER_VERSION||'4.8.1';
 let business='',revision=-1,settings=null,releases=[],pending=false,lastSync=0,heartbeatSent=0;
 const el=id=>document.getElementById(id);
 const isoDate=n=>new Date(n).toLocaleString();
 function session(){try{return JSON.parse(localStorage.getItem(SESSION)||'null')}catch(_){return null}}
 function tenant(){return String(session()?.auth?.tenant?.id||'').trim()}
 function canUseOffline(){
  const s=session(),t=s?.auth?.tenant,now=Date.now(),verified=Number(s?.verifiedAt||0);
  return t?.status==='active' && Date.parse(t.expires_at)>now && verified>0 && now>=verified-300000 && now<verified+7*86400000;
 }
 function notice(msg,ok){const x=el('nsOwnerControlStatus');if(x){x.textContent=msg;x.style.color=ok?'#087847':'#a14a12'}}
 function safeSettings(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid remote settings');
  const f={};for(const k of FEATURE_KEYS)f[k]=raw.features?.[k]!==false;
  const r=raw.receipt||{},p=raw.printer||{},a=raw.appearance||{};
  return {features:f,receipt:{paper_width:['58','80','auto'].includes(r.paper_width)?r.paper_width:'auto',website_display:r.website_display==='full'?'full':'www',dedupe_contacts:r.dedupe_contacts!==false,invoice_prefix:/^[A-Z0-9_-]{1,10}$/.test(r.invoice_prefix||'')?r.invoice_prefix:'INV',footer_note:String(r.footer_note||'').slice(0,140)},printer:{technology:['auto','bluetooth','usb','lan'].includes(p.technology)?p.technology:'auto',paper_width:['58','80','auto'].includes(p.paper_width)?p.paper_width:'auto',auto_print:p.auto_print===true},appearance:{language:['en','si','ta'].includes(a.language)?a.language:'en',theme:['blue','dark','light'].includes(a.theme)?a.theme:'blue'}};
 }
 function allowedPage(page){for(const [f,pages] of Object.entries(FEATURE_PAGES))if(pages.includes(page)&&settings?.features[f]===false)return false;return true}
 function applyFeatures(){
  const nodes=document.querySelectorAll('[onclick*="navigate("], [data-page]');
  for(const node of nodes){const m=/navigate\(['"]([^'"]+)['"]\)/.exec(node.getAttribute('onclick')||'');const page=m?.[1]||node.dataset?.page;
   if(!page)continue;
   if(!allowedPage(page))node.setAttribute('data-ns-owner-remote-hidden','yes');
   else if(node.getAttribute('data-ns-owner-remote-hidden')==='yes')node.removeAttribute('data-ns-owner-remote-hidden');
  }
  for(const pg of document.querySelectorAll('.page')){
   if(!allowedPage(pg.id))pg.setAttribute('data-ns-owner-remote-hidden','yes');
   else if(pg.getAttribute('data-ns-owner-remote-hidden')==='yes')pg.removeAttribute('data-ns-owner-remote-hidden');
  }
  const current=document.querySelector('.page.active');
  if(current && !allowedPage(current.id) && typeof window.navigate==='function')window.navigate('dashboard');
  const list=el('nsOwnerDisabledFeatures');if(list)list.textContent=settings ? FEATURE_KEYS.filter(k=>settings.features[k]===false).join(', ')||'None':'Not synced yet';
 }
 function apply(raw,code,rev,offline){
  if(!code||code!==tenant())return false;
  settings=safeSettings(raw);business=code;revision=rev;
  // Read-only config accessible by supported receipt, printer and theme adapters.
  window.NSOwnerPreferences=Object.freeze({...settings,businessCode:code,revision:rev});
  document.documentElement.dataset.nsOwnerTheme=settings.appearance.theme;
  applyFeatures();
  try{window.dispatchEvent(new CustomEvent('ns-owner-controls-updated',{detail:{businessCode:code,revision:rev,settings}}))}catch(_){}
  notice((offline?'Offline cached settings':'Owner settings synced')+' · Business '+code+' · Revision '+rev,true);
  const printer=el('nsOwnerPrinterPreference');if(printer)printer.textContent=settings.printer.technology+' · '+settings.printer.paper_width+'mm preference (hardware connection must be configured on this device)';
  return true;
 }
 function reset(){
  business='';revision=-1;settings=null;releases=[];lastSync=0;
  delete window.NSOwnerPreferences;
  document.documentElement.removeAttribute('data-ns-owner-theme');
  applyFeatures();renderReleases();notice('Customer Cloud Login required',false);
 }
 function fromCache(code){
  if(!code||!canUseOffline())return false;
  try{const obj=JSON.parse(localStorage.getItem(PREFIX+code)||'null');if(obj?.businessCode===code && Number.isSafeInteger(obj.revision) && obj.savedAt<=Date.now() && obj.savedAt>Date.now()-7*86400000)return apply(obj.settings,code,obj.revision,true)}catch(_){}
  return false;
 }
 function reportError(e){const msg=String(e?.message||e||'Unknown problem').slice(0,130);notice('Owner sync unavailable: '+msg,false)}
 function platform(){if(window.NSDesktopPrinter)return 'windows';if(window.AndroidPrinter)return 'android';return 'web'}
 function randomId(){
  let id=localStorage.getItem(DEVICE_KEY);if(/^[a-f0-9]{32}$/.test(id||''))return id;
  const bytes=new Uint8Array(16);if(!globalThis.crypto?.getRandomValues)return '';
  globalThis.crypto.getRandomValues(bytes);id=Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');localStorage.setItem(DEVICE_KEY,id);return id;
 }
 async function heartbeat(){
  if(el('nsOwnerHealthOptIn')?.checked!==true || !business || !navigator.onLine)return;
  if(Date.now()-heartbeatSent<30*60*1000)return;
  const did=randomId();if(!did)return notice('Device monitoring needs secure random ID support',false);
  try{
   await window.NSCloud.repCall('/v1/business/device-heartbeat','POST',{device_id:did,platform:platform(),app_version:APP_VERSION,printer_type:settings?.printer.technology||'unknown',printer_status:'not verified',last_error:''});
   heartbeatSent=Date.now();notice('Owner settings synced · device status sent with permission',true);
  }catch(e){reportError(e)}
 }
 function releaseLink(x){
  try{const u=new URL(x?.download_url);return u.protocol==='https:' && !!u.hostname && !u.username && !u.password ? u.href : ''}catch(_){return ''}
 }
 function renderReleases(){
  const root=el('nsOwnerReleaseList');if(!root)return;root.replaceChildren();
  const valid=releases.filter(x=>x.platform===platform() && releaseLink(x)).slice(0,3);
  if(!valid.length){root.textContent='No new version notices';return}
  for(const r of valid){
   const row=document.createElement('div');row.style='margin:7px 0;padding:8px;border:1px solid #dce5f1;border-radius:9px';
   const title=document.createElement('div');title.textContent='New '+r.platform+' release: '+String(r.version||'').slice(0,40);title.style.fontWeight='700';row.append(title);
   const note=document.createElement('div');note.textContent=String(r.notes||'').slice(0,250);row.append(note);
   const btn=document.createElement('button');btn.type='button';btn.className='secondary sm';btn.textContent='View update link';btn.onclick=()=>{
    if(!confirm('Open this HTTPS update page? Install only a signed release you trust.'))return;
    const url=releaseLink(r);if(!url)return;
    if(window.AndroidPrinter?.openSharedLink)window.AndroidPrinter.openSharedLink(url);
    else if(window.NSDesktop)window.prompt('Copy this HTTPS update link and open it in your browser:',url);
    else window.open(url,'_blank','noopener,noreferrer');
   };row.append(btn);root.append(row);
  }
 }
 async function sync(force=false){
  if(pending)return false;
  const code=tenant();if(code!==business)reset();
  if(!code){notice('Sign in to the Customer Cloud account',false);return false}
  if(!navigator.onLine){if(fromCache(code))return true;notice('Offline · no valid cached controls for this business',false);return false}
  if(!window.NSCloud?.repCall){notice('Cloud login module missing',false);return false}
  if(!force&&Date.now()-lastSync<45*1000)return true;
  pending=true;notice('Checking Owner settings for '+code+'…');
  try{
   const response=await window.NSCloud.repCall('/v1/business/control');
   if(!Number.isSafeInteger(response?.revision)||response.revision<0)throw Error('Cloud control revision invalid');
   if(code!==tenant())throw Error('Cloud customer account changed');
   apply(response.settings,code,response.revision,false);lastSync=Date.now();
   localStorage.setItem(PREFIX+code,JSON.stringify({businessCode:code,revision,savedAt:Date.now(),settings:response.settings}));
   try{const r=await window.NSCloud.repCall('/v1/business/releases');releases=Array.isArray(r.releases)?r.releases:[];renderReleases()}catch(e){releases=[];renderReleases()}
   await heartbeat();return true;
  }catch(e){
   reportError(e);
   // Do not fall back to cache on HTTP denial. Only reuse it during an actual offline session.
   if(!navigator.onLine)return fromCache(code);
   return false;
  }finally{pending=false}
 }
 function installPanel(){
  const parent=el('settings');if(!parent||el('nsOwnerControlPanel'))return;
  const box=document.createElement('div');box.id='nsOwnerControlPanel';box.className='panel';
  box.innerHTML='<h2>🛡 Developer Owner Remote Control</h2><p class="hint">Features and preferences for the signed-in business only. Does not overwrite stored invoices or stock.</p><p id="nsOwnerControlStatus" role="status">Cloud login required</p><p><b>Hidden modules:</b> <span id="nsOwnerDisabledFeatures">Not synced yet</span></p><p><b>Printer preference:</b> <span id="nsOwnerPrinterPreference">Not synced yet</span></p><button type="button" id="nsOwnerRefresh" class="secondary">↻ Refresh Owner Settings</button><label style="display:block;margin:12px 0;line-height:1.5"><input id="nsOwnerHealthOptIn" type="checkbox"> Share app version and printer preference/status with Developer Owner (no location, IMEI or invoice data)</label><h3>📦 Owner Update Notices</h3><div id="nsOwnerReleaseList">No notices yet</div>';
  parent.append(box);
  el('nsOwnerRefresh').onclick=()=>sync(true);
  const checkbox=el('nsOwnerHealthOptIn');checkbox.checked=localStorage.getItem('ns_owner_health_optin')==='yes';
  checkbox.onchange=()=>{localStorage.setItem('ns_owner_health_optin',checkbox.checked?'yes':'no');if(checkbox.checked)heartbeatSent=0,void heartbeat()};
  applyFeatures();
 }
 function init(){
  const css=document.createElement('style');css.textContent='[data-ns-owner-remote-hidden="yes"]{display:none!important}';document.head.append(css);
  installPanel();
  const previousNavigate=window.navigate;
  if(typeof previousNavigate==='function')window.navigate=function(page,...args){if(!allowedPage(page)){if(typeof window.toast==='function')window.toast('This module is disabled by Developer Owner');else alert('Module disabled by Developer Owner');return false}const result=previousNavigate.call(this,page,...args);applyFeatures();return result};
  // Cached config may be restored only for the same current business, within local subscription grace.
  const code=tenant();if(code){fromCache(code);setTimeout(()=>void sync(),3800)}
  window.addEventListener('ns-cloud-verified',()=>{heartbeatSent=0;void sync(true)});
  window.addEventListener('ns-cloud-logout',reset);
  window.addEventListener('online',()=>void sync(true));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void sync()});
  setInterval(()=>{if(!document.hidden)void sync()},90000);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
 window.NSOwnerRemote={sync:()=>sync(true),getState:()=>({business,revision,settings,releases}),isAllowedPage:allowedPage};
})();
