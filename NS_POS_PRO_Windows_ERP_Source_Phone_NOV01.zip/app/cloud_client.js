/* NS POS PRO Cloud Edition: paid, online-only cloud reporting adapter.
   Cloud snapshots are per-device projections. They do NOT implement authoritative shared stock or distributed transactions. */
(()=>{'use strict';
const KEY='nspos_cloud_v1', CACHE=KEY+'_daily_session', $c=id=>document.getElementById(id), today=()=>Date.now();
const FIXED_API='https://ns-pos-pro-cloud.nextsolutionstudio.workers.dev';
const DAY=86400000, GRACE=7*DAY, CHECK_INTERVAL=10*60*1000;
let api=FIXED_API, auth=null, verifiedUntil=0, syncTimer=null, licenseTimer=null, busy=false;
let verifiedAt=0, loginAt=0, seenAt=0;
let rev=Number(localStorage.getItem(KEY+'_rev')||0), device=localStorage.getItem(KEY+'_device');
if(!device){device=typeof crypto.randomUUID==='function'?crypto.randomUUID():'nspos-'+Date.now()+'-'+Math.random().toString(36).slice(2);localStorage.setItem(KEY+'_device',device)}
try{const cached=JSON.parse(localStorage.getItem(CACHE)||'null');if(cached && cached.auth && cached.auth.token){auth=cached.auth;verifiedAt=Number(cached.verifiedAt)||0;loginAt=Number(cached.loginAt)||0;seenAt=Number(cached.seenAt)||0}}catch(e){}
function keep(){seenAt=Math.max(seenAt,today());try{localStorage.setItem(CACHE,JSON.stringify({auth,verifiedAt,loginAt,seenAt}))}catch(e){}}
function forget(){auth=null;loginAt=0;verifiedAt=0;verifiedUntil=0;localStorage.removeItem(CACHE)}
function clockOk(){return today()>=seenAt-5*60*1000 && today()>=verifiedAt-5*60*1000}
function validExpiry(){const n=Date.parse(auth?.tenant?.expires_at||'');return auth?.tenant?.status==='active' && Number.isFinite(n) && n>today()?n:0}
function offlineAllowed(){return !!auth?.token && verifiedAt>0 && clockOk() && today()>=verifiedAt && today()<=verifiedAt+GRACE && !!validExpiry()}
function dailyLoginDue(){return !loginAt || !clockOk() || today()-loginAt>=DAY}
function currentGuard(){return !!auth && today()<verifiedUntil && !!validExpiry()}
const safe=t=>String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notice(text){let n=$c('cloudNotice');if(n)n.textContent=text}
function showGate(reason='Cloud sign in required'){let e=$c('cloudGate');if(!e)return; e.style.display='flex';notice(reason)}
function hideGate(){$c('cloudGate').style.display='none'}
async function call(path,method='GET',payload){
 if(!/^https:\/\//.test(api)&&!/^http:\/\/localhost/.test(api))throw Error('Cloud URL must be HTTPS');
 let res;const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),15000);
 try{res=await fetch(api.replace(/\/$/,'')+path,{method,signal:controller.signal,headers:{'Content-Type':'application/json',...(auth?{'Authorization':'Bearer '+auth.token}:{})},body:payload?JSON.stringify(payload):undefined})}
 catch(e){const err=Error('No Internet / cloud connection. Offline billing can continue if your subscription was verified recently.');err.offline=true;throw err}
 finally{clearTimeout(timeout)}
 let result;try{result=await res.json()}catch(e){throw Error('Cloud returned an invalid response')}
 if(!res.ok){const err=Error(result.error||('Request failed '+res.status));err.httpStatus=res.status;throw err}
 return result;
}
function setLogin(v){let s=$c('cloudLoginSection');if(s)s.style.display=v?'':'none'}
function install(){const gate=document.createElement('div');gate.id='cloudGate';gate.style='position:fixed;inset:0;background:linear-gradient(140deg,#152459ef,#353798ef);display:flex;align-items:center;justify-content:center;z-index:999999;overflow:auto;padding:15px';gate.innerHTML=`<div class="ns-cloud-shell"><div class="ns-cloud-hero"><img src="./next_solution_blue_logo.jpg" alt="Next Solution Studio" class="ns-cloud-logo"><h2>NS POS <span>PRO</span></h2><p>Smart Business · One Connected POS</p><div class="ns-cloud-perks">☁ Cloud Subscription &nbsp; · &nbsp; 🧾 Billing & GRN &nbsp; · &nbsp; 📦 Stock</div></div><div class="ns-cloud-card"><div class="ns-cloud-symbol">☁ 🔒</div><h2>Business Login</h2><p id="cloudNotice" class="ns-cloud-note">Sign in to your active subscription</p><div id="cloudLoginSection"><label>Username</label><input id="cloudEmail" type="text" autocomplete="username" placeholder="Enter Username"><label>Password</label><div style="display:flex;align-items:center;gap:8px"><input id="cloudPassword" style="flex:1;min-width:0" type="password" autocomplete="current-password" placeholder="Enter Password"><button type="button" id="cloudEye" aria-label="Show password" aria-pressed="false" style="min-width:44px;min-height:44px;border-radius:10px;background:#eaf0ff;color:#153d85;border:0;font-size:21px" onclick="const p=document.getElementById('cloudPassword');const v=p.type==='password';p.type=v?'text':'password';this.textContent=v?'◉':'👁';this.setAttribute('aria-pressed',String(v));this.setAttribute('aria-label',v?'Hide password':'Show password')">👁</button></div><button class="ns-cloud-primary" onclick="NSCloud.login()">↪ Sign In to POS</button></div><div class="ns-cloud-renew"><h3>💳 Subscription &amp; Renewal</h3><button type="button" class="ns-cloud-secondary" onclick="NSCloud.closeSubscription()">✕ Back to App</button><p id="cloudExpiry">Your subscription is managed by the developer.</p><div class="ns-wa-slip-guide"><h3>📷 Send Payment Slip via WhatsApp</h3><p>Open WhatsApp, tap <b>📎 Attach → Gallery</b>, select the bank slip photo, then tap <b>Send</b>.</p><p>WhatsApp විවෘත කර 📎 Attach → Gallery → Slip Photo → Send කරන්න.</p><p>WhatsApp திறந்து 📎 Attach → Gallery → ரசீது படம் → Send செய்யவும்.</p></div><button class="ns-cloud-whatsapp" type="button" onclick="NSCloud.whatsappRenew()">💬 Open WhatsApp &amp; Send Slip</button><p class="ns-cloud-help">The slip is NOT attached automatically. Please attach and send it yourself. Developer approval is required for renewal.</p></div></div></div>`;document.body.append(gate);

 const menu=document.createElement('div');menu.id='cloudTopMenu';menu.style='position:fixed;right:10px;top:52px;z-index:9995;font-family:Arial,sans-serif';menu.innerHTML='<button type="button" id="cloudMenuToggle" aria-label="Cloud account menu" aria-expanded="false" style="background:#173f91;color:white;border:0;border-radius:11px;padding:10px 13px;box-shadow:0 3px 10px #0003">☁ ☰</button><div id="cloudMenuItems" style="display:none;position:absolute;right:0;top:45px;min-width:205px;background:white;border:1px solid #dce5f4;border-radius:12px;padding:7px;box-shadow:0 7px 20px #0003"><button type="button" onclick="NSCloud.syncNow()">☁ Sync</button><button type="button" onclick="NSCloud.reports()">📊 Reports</button><button type="button" onclick="NSCloud.switchStaff()">👥 Admin / Rep PIN</button><button type="button" onclick="NSCloud.confirmLogout()">↪ Cloud Log out</button></div>';document.body.append(menu);const toggle=menu.querySelector('#cloudMenuToggle'),items=menu.querySelector('#cloudMenuItems');toggle.onclick=()=>{const opened=items.style.display!=='none';items.style.display=opened?'none':'block';toggle.setAttribute('aria-expanded',String(!opened))};items.querySelectorAll('button').forEach(b=>{b.style='display:block;width:100%;background:white;color:#17315b;border:0;padding:11px;text-align:left;font-size:15px'});
 const style=document.createElement('style');style.textContent='#cloudGate .ns-cloud-card label,#cloudGate .ns-cloud-card h2,#cloudGate .ns-cloud-card h3{color:#fff!important}#cloudGate .ns-cloud-card .ns-cloud-note,#cloudGate .ns-cloud-card .ns-cloud-help{color:#e4ebff!important}#cloudGate input{color:#172b4d!important;background:#fff!important}.ns-wa-slip-guide{border:1px solid #79e1be;background:#ffffff17;border-radius:12px;padding:12px;margin:12px 0}.ns-wa-slip-guide h3{font-size:16px!important}.ns-wa-slip-guide p{line-height:1.55!important;font-size:13px!important;color:#f5fbff!important}.ns-cloud-whatsapp{min-height:52px}';document.head.append(style);

 const settings=document.getElementById('settings');if(settings){const panel=document.createElement('div');panel.className='panel';panel.innerHTML='<h2>☁ Cloud Subscription</h2><p class="hint">Subscription price, expiry, server address and block/unblock are controlled by NS POS PRO Developer Owner only.</p><p id="cloudSettingsStatus">Login required</p><button class="secondary" type="button" onclick="NSCloud.openSubscription()">View Subscription / Bank Transfer</button>';settings.insertBefore(panel,settings.firstChild);}
 const overlay=document.createElement('div');overlay.id='cloudReports';overlay.style='display:none;position:fixed;inset:0;z-index:99998;background:#eff4fc;overflow:auto;padding:15px;font-family:Arial,sans-serif;color:#17315b';overlay.innerHTML='<div style="max-width:1100px;margin:auto;background:white;border-radius:16px;padding:18px"><button onclick="document.getElementById(\'cloudReports\').style.display=\'none\'" style="float:right">Close</button><h2>Rep Cloud Reports</h2><p>Reports reflect each device’s most recently uploaded snapshot, not authoritative merged warehouse stock.</p><div id="cloudReportsInner"></div></div>';document.body.append(overlay);
 showGate('Sign in to the online Cloud Subscription edition');}
async function login(){
 try{
  api=FIXED_API;
  const username=$c('cloudEmail').value.trim().toLowerCase(),password=$c('cloudPassword').value;
  if(!username || !password)throw Error('Enter username and password');
  const r=await call('/v1/auth/login','POST',{username,password});
  auth={token:r.token,role:r.role,tenant:r.tenant,uid:r.user.id,businessCode:r.tenant.id};
  verifiedAt=0;loginAt=today();
  $c('cloudPassword').value='';
  if(await check()){keep();schedulePush()}
 }catch(e){$c('cloudPassword').value='';showGate(e.message);setLogin(true)}
}
function offlineMode(reason){
 if(!offlineAllowed())return false;
 verifiedUntil=Math.min(validExpiry(),verifiedAt+GRACE);
 hideGate();setLogin(false);
 const s=$c('cloudSettingsStatus');if(s)s.textContent='Offline billing available · Last verified '+new Date(verifiedAt).toLocaleString()+' · Expires '+auth.tenant.expires_at.slice(0,10);
 notice('Offline billing enabled. Sync will resume when internet returns.');
 return true;
}
async function check(){
 if(!auth){showGate('Cloud sign in required');setLogin(true);return false}
 try{
  const r=await call('/v1/auth/me');
  if(!r.tenant)throw Error('Business not found');
  auth.tenant=r.tenant;
  const expiry=Date.parse(r.tenant.expires_at),remaining=expiry-today(),days=Math.ceil(remaining/DAY);
  $c('cloudExpiry').textContent='Business: '+r.tenant.name+' · Expiry: '+r.tenant.expires_at.slice(0,10)+' · '+Math.max(days,0)+' days left.';
  const ss=$c('cloudSettingsStatus');if(ss)ss.textContent=$c('cloudExpiry').textContent;
  if(r.tenant.status!=='active'||remaining<=0){forget();showGate('Subscription expired or blocked. Contact developer via WhatsApp.');setLogin(true);return false}
  verifiedAt=today();verifiedUntil=Math.min(expiry,verifiedAt+GRACE);keep();hideGate();setLogin(false);window.dispatchEvent(new Event('ns-cloud-verified'));
  if(days>=1&&days<=7){const key=KEY+'_reminder_'+r.tenant.id+'_'+r.tenant.expires_at+'_'+days;if(localStorage.getItem(key)!=='shown'){localStorage.setItem(key,'shown');alert('NS POS subscription: '+days+' day(s) remaining. Please arrange your renewal before expiry.')}}
  return true;
 }catch(e){
  if(e.offline && offlineMode(e.message))return true;
  verifiedUntil=0;
  if(e.httpStatus===401||e.httpStatus===403){forget();setLogin(true);showGate('Cloud login expired or account disabled. Sign in again.');return false}
  showGate(e.offline?'No Internet. Connect to verify your subscription or use a recently verified device.':'Cloud validation failed: '+e.message);
  if(!auth)setLogin(true);
  return false;
 }
}
function snapshot(){let s=typeof db!=='undefined'?db:{};const pick=(key,max)=>Array.isArray(s[key])?s[key].slice(0,max):[];return {summary:{business:s.settings?.name||'',time:new Date().toISOString()},invoices:pick('invoices',120),orders:pick('orders',120),products:pick('products',500).map(p=>({...p,image:undefined,logo:undefined})),shops:pick('shops',150),vehicleLedger:pick('vehicleLedger',200),creditPayments:pick('creditPayments',200),returns:pick('returns',100),grns:pick('grns',50),cheques:pick('cheques',100),repClosings:pick('repClosings',90)}}
async function syncNow(){
 if(auth?.role==='hr')return toast('HR cannot synchronize POS snapshots');
 if(!auth)return showGate('Sign in first');if(busy)return;
 if(!navigator.onLine){toast('Offline: billing is saved locally; sync will resume when Internet returns');return}
 busy=true;
 try{
  if(!await check())return;
  rev++;localStorage.setItem(KEY+'_rev',String(rev));const data=snapshot(),size=JSON.stringify(data).length;
  if(size>840000)throw Error('Snapshot larger than Cloud limit. Export local backup and reduce old records.');
  await call('/v1/sync/push','POST',{deviceId:device,revision:rev,snapshot:data});
  if(window.NSERPCloud && auth.role!=='hr')await window.NSERPCloud.uploadInvoices();
  toast('Cloud sync complete');
 }catch(e){toast(e.offline?'Offline: changes kept on device; sync later':'Sync not uploaded: '+e.message)}finally{busy=false}
}
function schedulePush(){if(syncTimer)clearTimeout(syncTimer);syncTimer=setTimeout(()=>{syncNow()},1400)}
function confirmLogout(){if(confirm('Log out of NS POS PRO? Save any unfinished bill first.'))logout()}
function logout(){if(auth){call('/v1/auth/logout','POST').catch(()=>{});}forget();window.dispatchEvent(new Event('ns-cloud-logout'));setLogin(true);showGate('Signed out of Cloud');}
function switchStaff(){const menu=$c('cloudMenuItems');if(menu)menu.style.display='none';if(typeof NS2_logout==='function')NS2_logout();else toast('Reopen app for local PIN login');}
function whatsappRenew(){
 const url='https://wa.me/message/JAKD2IUS5QKIH1';
 try{
  if(window.AndroidPrinter && typeof window.AndroidPrinter.openSharedLink==='function'){
   window.AndroidPrinter.openSharedLink(url);
   return;
  }
  window.location.href=url;
 }catch(e){notice('Could not open WhatsApp. Please try again.');}
}
async function reports(){if(!auth||auth.role!=='admin')return toast('Business Admin only');try{const r=await call('/v1/sync/reports'),el=$c('cloudReportsInner');el.innerHTML=r.devices.map(d=>{let p=d.payload||{},sum=(p.invoices||[]).reduce((n,i)=>n+Number(i.total||0),0),credit=(p.invoices||[]).reduce((n,i)=>n+Math.max(0,Number(i.total||0)-Number(i.paid||0)),0);let bills=(p.invoices||[]).slice(0,10).map(i=>`<tr><td>${safe(i.number)}</td><td>${safe(i.customer)}</td><td>${Number(i.total||0).toFixed(2)}</td></tr>`).join('');return `<section style="border:1px solid #dce7f8;border-radius:12px;padding:12px;margin:12px 0"><h3>${safe(d.email)}</h3><p>Last Sync: ${safe(d.updated_at)} · Device ${safe(d.device_id.slice(0,8))}</p><b>Invoices: ${(p.invoices||[]).length} · Value Rs. ${sum.toFixed(2)} · Open Balance Rs. ${credit.toFixed(2)} · Shops: ${(p.shops||[]).length} · Orders: ${(p.orders||[]).length}</b><table style="width:100%;text-align:left;font-size:13px;margin-top:10px"><tr><th>Invoice</th><th>Customer</th><th>Amount</th></tr>${bills}</table></section>`}).join('')||'No devices have synced yet';$c('cloudReports').style.display='block';}catch(e){toast(e.message)}}
function guard(){return currentGuard() && $c('cloudGate').style.display==='none'}
// The base application declares `save` as const, so assigning to it throws and
// prevents the entire subscription UI from being installed. Keep it intact.
// Block user interaction while the subscription gate is visible, and use the
// existing navigation function for additional validation.
document.addEventListener('click',event=>{
  if(guard())return;
  const gate=$c('cloudGate');
  if(gate && !gate.contains(event.target)){
    event.preventDefault();event.stopImmediatePropagation();
    showGate('Cloud subscription sign-in or verification required');
  }
},true);

let baseNavigate=navigate;navigate=function(p){if(!guard()){showGate('Sign in to active Cloud subscription first');return}return baseNavigate(p)};
install();
// Cached server token is retained between Android WebView launches (password is never stored).
// Cloud username/password is requested once each rolling 24h when online; staff PIN remains local.
(async()=>{
 if(!auth){setLogin(true);showGate('Sign in to NS POS PRO Cloud');return}
 if(dailyLoginDue() && navigator.onLine){setLogin(true);showGate('Daily Cloud verification: enter username and password');return}
 if(!navigator.onLine){if(offlineMode())return;setLogin(true);showGate('Internet required for initial subscription verification');return}
 await check();
})();
licenseTimer=setInterval(()=>{if(auth && navigator.onLine && !dailyLoginDue())check();else if(auth && !navigator.onLine && !offlineAllowed()){verifiedUntil=0;showGate('Offline grace period or subscription has expired. Reconnect to verify.')}},CHECK_INTERVAL);
window.addEventListener('online',async()=>{if(!auth)return;if(dailyLoginDue()){setLogin(true);showGate('Daily Cloud sign in required');return}if(await check())schedulePush()});
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&auth){if(navigator.onLine&&dailyLoginDue()){setLogin(true);showGate('Daily Cloud sign in required')}else if(navigator.onLine)check();else offlineMode()}});
window.NSCloud={login,check,repCall:async(path,method,payload)=>{if(!auth||!currentGuard()||!navigator.onLine)throw Error('Online Cloud connection required');return call(path,method,payload)},getRole:()=>auth?.role||null,getBusinessCode:()=>auth?.businessCode||null,getUserId:()=>auth?.uid||null,syncNow,logout,confirmLogout,switchStaff,whatsappRenew,reports,openSubscription:()=>{showGate('Subscription & WhatsApp payment slip');setLogin(!auth)},closeSubscription:()=>{if(guard()||currentGuard())hideGate()}};
})();
