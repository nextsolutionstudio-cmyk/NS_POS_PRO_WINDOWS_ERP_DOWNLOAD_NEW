/* v4.5: business-authenticated Cloud ERP sync. No tenant ids, roles or secrets are trusted from the request body.
 * Local changes use an on-device outbox. Conflicts stop uploads; cloud never silently overwrites edits.
 * Historical local HR records are NEVER uploaded without clicking Import Local ERP.
 */
(()=>{'use strict';
const prefix='nspos_erp_cloud_v45_', kinds=['employees','attendance','payroll','entries','config'];
const storeKey=()=>{try{const v=JSON.parse(localStorage.getItem('nspos_cloud_v1_daily_session')||'null');return v?.auth?.tenant?.id||''}catch(_){return ''}};
const role=()=>window.NSCloud?.getRole?.()||'';
const allow=k=>role()==='admin'||(role()==='hr'&&['employees','attendance','payroll'].includes(k));
const call=(path,method='GET',data)=>window.NSCloud.repCall(path,method,data);
const msg=v=>{const el=document.getElementById('erpCloudStatus');if(el)el.textContent=v;try{toast(v)}catch(_){}};
const pending=()=>{try{return JSON.parse(localStorage.getItem(prefix+storeKey()+'_pending')||'[]')}catch(_){return []}};
const writePending=items=>localStorage.setItem(prefix+storeKey()+'_pending',JSON.stringify(items));
const revisions=()=>{try{return JSON.parse(localStorage.getItem(prefix+storeKey()+'_revisions')||'{}')}catch(_){return {}}};
const setRevisions=r=>localStorage.setItem(prefix+storeKey()+'_revisions',JSON.stringify(r));
let syncing=false,report=null;
function normalItems(d,kind){if(kind==='config')return [{id:'singleton',value:d.config}];return (d[kind]||[]).map(x=>({id:x.id,value:x}))}
function queueDiff(before,after){if(!storeKey())return;let list=pending(),ver=revisions();for(const kind of kinds){if(!allow(kind))continue;
 const prev=new Map(normalItems(before,kind).map(v=>[v.id,JSON.stringify(v.value)]));
 for(const entry of normalItems(after,kind)){if(prev.get(entry.id)===JSON.stringify(entry.value))continue;
  const key=kind+'|'+entry.id;const old=list.find(x=>x.key===key);
  if(old)old.value=entry.value;
  else list.push({key,kind,id:entry.id,value:entry.value,expectedRevision:Number(ver[key]||0)});
 }
 }writePending(list);const el=document.getElementById('erpCloudStatus');if(el)el.textContent=list.length+' ERP change(s) queued locally. Tap Cloud Sync when online.';}
function invoiceSummary(inv){const lines=Array.isArray(inv.lines)?inv.lines:[],allReturns=(db.returns||[]).filter(r=>r.invoiceId===inv.id);let cogs=0,unknown=0,returnValue=0,returnCost=0;
 for(const l of lines){const qty=Number(l.qty)||0,cost=l.costAtSale;
  if(cost===null||cost===undefined||!Number.isFinite(Number(cost)))unknown++;
  else cogs+=qty*Number(cost);
 }
 for(const r of allReturns){const ratio=Number(inv.total)>0?1-(Number(inv.taxAmount)||0)/Number(inv.total):1;
  returnValue+=(Number(r.refund)||0)*ratio;
  if(r.restock)for(const line of r.lines||[]){const original=lines.find(l=>l.id===line.lineId);
   if(original&&original.costAtSale!==null&&original.costAtSale!==undefined&&Number.isFinite(Number(original.costAtSale)))returnCost+=(Number(line.qty)||0)*Number(original.costAtSale);else unknown++;
  }
 }
 return {id:String(inv.id||''),date:String(inv.date||''),branch:String(inv.branch||db.settings?.branch||db.settings?.name||'Main Branch').slice(0,65),
  salesExTax:Math.max(0,Math.round(((Number(inv.total)||0)-(Number(inv.taxAmount)||0)-returnValue)*100)/100),
  cost:Math.max(0,Math.round((cogs-returnCost)*100)/100),tax:Math.max(0,Number(inv.taxAmount)||0),costUnknown:unknown,voided:!!inv.voidedAt};
}
async function uploadInvoices(){if(role()==='hr')return;const all=(db.invoices||[]).map(invoiceSummary).filter(x=>x.id&&x.date);
 let sent=0;for(let i=0;i<all.length;i+=50){const part=all.slice(i,i+50),r=await call('/v1/erp/sales','PUT',{deviceId:localStorage.getItem('nspos_cloud_v1_device')||'missing',invoices:part});if(r.conflicts?.length)throw Error(r.conflicts.length+' invoice IDs belong to other devices. Resolve before merging.');sent+=r.sent||0}
 return sent;}
async function fetchRemote(){const map={},rev={};for(const kind of kinds){if(!allow(kind))continue;
 const r=await call('/v1/erp/records?kind='+encodeURIComponent(kind));map[kind]=r.records;
 for(const item of r.records)rev[kind+'|'+item.id]=item.revision;
 }return {map,rev};}
async function sync({importLocal=false}={}){if(syncing)return;const t=storeKey();if(!t)return msg('Cloud login required');if(!navigator.onLine)return msg('Offline: pending changes kept in this phone');if(!['admin','hr'].includes(role()))return msg('Admin or HR Cloud Login required');
 syncing=true;const btn=document.getElementById('erpCloudSyncBtn');if(btn)btn.disabled=true;
 try{let queue=pending(),version=revisions();
  const existing=window.NSERP?.getLocalData?.();
  if(!importLocal&&existing){const pendingKeys=new Set(queue.map(x=>x.key));const unknown=['employees','attendance','payroll','entries'].filter(allow).flatMap(k=>normalItems(existing,k).filter(x=>!version[k+'|'+x.id]&&!pendingKeys.has(k+'|'+x.id)));
   if(unknown.length)throw Error(unknown.length+' existing local record(s) have never been sent to Cloud. Use Import existing local ERP with explicit approval; Cloud Sync will not erase them');}
  if(importLocal){const d=window.NSERP?.getLocalData?.();if(!d)throw Error('Open HR/Accounts first');
   const count=['employees','attendance','payroll','entries'].filter(allow).reduce((sum,k)=>sum+(d[k]?.length||0),0);
   if(!confirm(`Upload ${count} existing local ERP records to this business's Cloud? This includes employee/payroll details and may conflict with records from another device. Continue only with authorized data.`))return;
   const extra=[];for(const kind of kinds){if(!allow(kind))continue;for(const item of normalItems(d,kind))extra.push({key:kind+'|'+item.id,kind,id:item.id,value:item.value,expectedRevision:Number(version[kind+'|'+item.id]||0)})}
   const keys=new Set(queue.map(x=>x.key));queue.push(...extra.filter(x=>!keys.has(x.key)));writePending(queue);
  }
  let completed=0;
  for(const item of [...queue]){if(!allow(item.kind))continue;
   const r=await call('/v1/erp/records?kind='+encodeURIComponent(item.kind),'PUT',{id:item.id,expectedRevision:item.expectedRevision,value:item.value});
   version[item.key]=r.revision;setRevisions(version);
   queue=queue.filter(x=>x.key!==item.key);writePending(queue);completed++;
  }
  // Only pull remote after every pending local mutation was acknowledged.
  const remote=await fetchRemote();
  const d=window.NSERP?.getLocalData?.();if(d){const merged=JSON.parse(JSON.stringify(d));for(const k of kinds){if(!allow(k))continue;
    const records=remote.map[k]||[];if(k==='config')merged.config=records[0]?.value||merged.config;else merged[k]=records.map(x=>x.value);
   }
   if(!window.NSERP.replaceFromCloud(merged))throw Error('Cloud received records but local storage could not be updated');
  }
  version={...version,...remote.rev};setRevisions(version);
  const invoices=await uploadInvoices();msg('Cloud Sync complete · ERP changes: '+completed+' · Sales summaries checked: '+invoices+'.');
 }catch(e){msg('Cloud Sync stopped: '+e.message+'. Local changes retained; do not overwrite other devices.')}finally{syncing=false;if(btn)btn.disabled=false;}
}
async function getProfit(period='month',date=new Date().toISOString().slice(0,10)){
 if(role()!=='admin')return msg('Business Cloud Admin only');try{report=await call('/v1/erp/profit?period='+encodeURIComponent(period)+'&date='+encodeURIComponent(date));
 const target=document.getElementById('erpCloudProfit');if(!target)return;
 const f=n=>'Rs. '+Number(n||0).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2});
 const t=report.total;target.innerHTML='<h3>☁ Cloud Multi-Counter Profit · '+period.toUpperCase()+'</h3>'+
 '<p>Sales ex tax: <b>'+f(t.sales)+'</b> · COGS: '+(t.unknown?'Not fully known':f(t.cogs))+' · Other income: '+f(t.otherIncome)+'</p>'+
 '<p>Expenses: '+f(t.expenses)+' · Payroll: '+f(t.payroll)+' · Estimated Net: <b>'+(t.net===null?'Unavailable – missing product cost':f(t.net))+'</b></p>'+
 '<p>Cloud-acknowledged bills: '+t.invoices+' · Missing-cost bills: '+t.unknown+'</p>'+
 '<table><thead><tr><th>Branch</th><th>Bills</th><th>Sales ex tax</th><th>COGS</th></tr></thead><tbody>'+report.branches.map(b=>'<tr><td>'+String(b.branch).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]))+'</td><td>'+b.invoices+'</td><td>'+f(b.sales)+'</td><td>'+(b.unknown?'Missing cost':f(b.cogs))+'</td></tr>').join('')+'</tbody></table>'+
 '<p class="erp-warning">Not a certified accounting statement. Offline/unuploaded invoices, incomplete history and other expenses may be missing. Reconcile with accountant before tax filing.</p>';
 }catch(e){msg('Cannot load Cloud profit: '+e.message)}
}
function authChanged(){if(role()==='hr' && typeof NS2_USER!=='undefined'){
  NS2_USER={id:'cloud-hr-'+window.NSCloud.getUserId(),name:'Cloud HR',role:'hr'};
  if(typeof NS2_authRender==='function')NS2_authRender();if(typeof NS2_roles==='function')NS2_roles();
  setTimeout(()=>{if(window.NSERP?.open)window.NSERP.open()},0);
 }else if(role()!== 'hr' && typeof NS2_USER!=='undefined' && NS2_USER?.id?.startsWith('cloud-hr-')){NS2_USER=null;NS2_authRender();NS2_roles();}
}
window.addEventListener('ns-cloud-verified',authChanged);
window.addEventListener('ns-cloud-logout',()=>{if(typeof NS2_USER!=='undefined'&&NS2_USER?.id?.startsWith('cloud-hr-')){NS2_USER=null;NS2_authRender();NS2_roles()}});
window.NSERPCloud={queueDiff,sync,importLocal:()=>sync({importLocal:true}),getProfit,invoiceSummary,uploadInvoices};
})();
