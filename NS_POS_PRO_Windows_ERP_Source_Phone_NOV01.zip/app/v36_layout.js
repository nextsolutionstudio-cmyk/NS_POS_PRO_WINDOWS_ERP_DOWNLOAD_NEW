/* NS POS PRO v3.6 – clean readable data entry for Orders and Manual Billing.
   This file contains presentation changes only. Existing stock, invoice and
   order-save calculations are left intact. */
(() => {
  'use strict';
  const byId = id => document.getElementById(id);
  const field = id => byId(id)?.closest('.field');
  function makeField(label, inputNode, klass = '') {
    const div = document.createElement('div');
    div.className = 'field ' + klass;
    const caption = document.createElement('label');
    caption.textContent = label;
    div.append(caption, inputNode);
    return div;
  }
  // Manual billing: full-width product/service name. Optional name suffix and
  // amount move BELOW, instead of competing for the same narrow phone row.
  const manualName = byId('manualName');
  const rate = byId('manualRate');
  if (manualName && rate && !byId('ns36ManualDetails')) {
    const parentRow = manualName.closest('.row');
    const nameField = field('manualName');
    const rateField = field('manualRate');
    const parent = parentRow?.parentElement;
    if (parent && nameField && rateField) {
      parentRow.classList.add('ns36-name-row');
      nameField.classList.add('ns36-name-full');
      const detailsRow = document.createElement('div');
      detailsRow.id = 'ns36ManualDetails';
      detailsRow.className = 'row ns36-details-row';
      parentRow.after(detailsRow);
      const nameUnit = byId('ns35ManualNameUnit');
      if (nameUnit) {
        const unitField = makeField('Name Unit (optional)', nameUnit, 'ns36-unit-field');
        detailsRow.append(unitField);
      }
      detailsRow.append(rateField);
      manualName.setAttribute('autocomplete', 'off');
      manualName.placeholder = 'Enter full product / service name';
      manualName.setAttribute('aria-label', 'Manual item name');
    }
  }
  // Orders: make Product / Item a full-width input instead of squeezing it into
  // one row alongside Qty, Unit and Rate on small devices.
  const orderName = byId('ns33OrderItem');
  if (orderName && !byId('ns36OrderDetails')) {
    const nameRow = orderName.closest('.row');
    const nameField = field('ns33OrderItem');
    const parent = nameRow?.parentElement;
    if (nameRow && parent && nameField) {
      nameRow.classList.add('ns36-name-row');
      nameField.classList.add('ns36-name-full');
      const detailsRow = document.createElement('div');
      detailsRow.id = 'ns36OrderDetails';
      detailsRow.className = 'row ns36-details-row';
      nameRow.after(detailsRow);
      for (const id of ['ns33OrderQty','ns33OrderUnit','ns35OrderPrice']) {
        const f = field(id);
        if (f) detailsRow.append(f);
      }
      const nameUnit = byId('ns35OrderNameUnit');
      if (nameUnit) detailsRow.prepend(makeField('Name Unit (optional)', nameUnit, 'ns36-unit-field'));
      orderName.placeholder = 'Type full product / item name';
      orderName.setAttribute('aria-label', 'Order product or item name');
      const unit = byId('ns33OrderUnit');
      if (unit) {
        const selected = unit.value;
        const preferred = ['pcs','g','kg','mg','ml','L','bottle','pack','box','dozen','bag','m','cm','mm'];
        const options = [...unit.options];
        options.sort((a,b) => preferred.indexOf(a.value) - preferred.indexOf(b.value));
        unit.replaceChildren(...options);
        unit.value = selected || 'pcs';
      }
    }
  }
  const style = document.createElement('style');
  style.textContent = `
    #manualAdd .ns36-name-row, #orders .ns36-name-row {
      display:block; width:100%;
    }
    .ns36-name-row > .ns36-name-full {width:100%;max-width:none;min-width:0;flex:1 1 100%;}
    .ns36-name-row #manualName, .ns36-name-row #ns33OrderItem {
      width:100%;max-width:100%;min-width:0;display:block;font-size:16px;
      min-height:52px;padding:12px 14px;
    }
    .ns36-name-row .ns35-name-unit-row {display:block;width:100%;}
    .ns36-name-row .ns35-name-unit-row input {width:100%;max-width:100%;min-width:0;}
    .ns36-details-row {display:flex; flex-wrap:wrap;gap:10px;align-items:flex-start;margin:4px 0 12px;}
    .ns36-details-row > .field {flex:1 1 145px;min-width:130px;max-width:none;}
    .ns36-details-row > .field label {font-size:13px;}
    .ns36-details-row .ns36-unit-field select {width:100%;max-width:100%;height:48px;flex:auto;}
    @media(max-width:520px){
      #manualAdd .ns36-details-row>.field {flex:1 1 calc(50% - 10px);min-width:0;}
      #ns36OrderDetails>.field {flex:1 1 calc(50% - 10px);min-width:0;}
      #ns36OrderDetails>.field select, #ns36OrderDetails>.field input {min-width:0;max-width:100%;}
    }
  `;
  document.head.append(style);
})();
