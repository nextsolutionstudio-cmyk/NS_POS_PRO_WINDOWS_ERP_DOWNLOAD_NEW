/* NS POS PRO v4.0: fast, bounded, role-aware saved-bill listing. UI only. */
(() => {
  'use strict';
  const input=document.getElementById('historySearch');
  const list=document.getElementById('historyList');
  if(!input||!list)return;
  const PAGE=30;
  let limit=PAGE, lastQuery='', searchTimer=null;
  const norm=s=>String(s??'').normalize('NFKC').toLocaleLowerCase().trim();
  const validAdmin=()=>typeof NS2_admin==='function' ? !!NS2_admin() : false;
  const allowed=inv=>validAdmin() || (typeof NS2_USER!=='undefined' && inv.repId===NS2_USER?.id);
  const make=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e};
  const action=(parent,label,fn,cls='secondary sm')=>{const b=make('button',cls,label);b.type='button';b.addEventListener('click',fn);parent.append(b);return b};
  // Override the chained renderers to avoid rendering the full history 4+ times.
  renderHistory=function(){
    if(!document.getElementById('history')?.classList.contains('active'))return;
    const q=norm(input.value);
    if(q!==lastQuery){lastQuery=q;limit=PAGE}
    const invoices=Array.isArray(db?.invoices)?db.invoices:[];
    const matched=[];
    for(const inv of invoices){
      if(!allowed(inv))continue;
      if(q&&!norm([inv.number,inv.customer,inv.phone,inv.rep].join(' ')).includes(q))continue;
      matched.push(inv);
    }
    const total=matched.length, visible=matched.slice(0,limit);
    const returnedById=new Map();
    if(Array.isArray(db?.returns))for(const r of db.returns){if(r.invoiceId)returnedById.set(r.invoiceId,(returnedById.get(r.invoiceId)||0)+Number(r.refund||0))}
    const hasReturns=new Set((db?.returns||[]).map(x=>x.invoiceId));
    const hasPayments=new Set([...(db?.creditPayments||[]),...(db?.cheques||[])].map(x=>x.invoiceId));
    const frag=document.createDocumentFragment();
    if(!total)frag.append(make('div','empty',q?'No matching bills':'No invoices yet'));
    for(const inv of visible){
      const entry=make('div','ns2-entry');
      const header=make('div','row');header.append(make('b','',inv.number||''),make('span','pill',inv.payment||inv.mode||''),make('b','right',typeof money==='function'?money(inv.total):inv.total));entry.append(header);
      const returned=returnedById.get(inv.id)||0;
      const date=inv.date?new Date(inv.date).toLocaleString():'';
      entry.append(make('div','hint',[inv.customer||'',inv.rep||'',date,returned?'Returned '+(typeof money==='function'?money(returned):returned):''].filter(Boolean).join(' · ')));
      action(entry,'View / Reprint',()=>openInvoice(inv.id));
      if(validAdmin()&&typeof NS2_startReturn==='function')action(entry,'↩ Return',()=>NS2_startReturn(inv.id));
      if((validAdmin()||(typeof NS2_USER!=='undefined' && inv.repId===NS2_USER?.id))&&typeof startEdit==='function')action(entry,'✏ Edit Bill',()=>startEdit(inv.id));
      if(validAdmin() && window.NSBillVoid?.voidBill){
        if(inv.voidedAt){entry.append(make('span','pill bad','VOID · '+(inv.voidReason||'')))}
        else action(entry,'Void Bill',()=>window.NSBillVoid.voidBill(inv.id),'danger sm');
      }
      frag.append(entry);
    }
    if(total>limit){
      const more=make('div','ns-history-more');
      more.append(make('span','hint',`Showing ${visible.length} of ${total} bills`));
      action(more,'Load 30 more',()=>{limit+=PAGE;renderHistory()});
      frag.append(more);
    }else if(total){frag.append(make('div','hint',`${total} bill(s) found`))}
    list.replaceChildren(frag);
  };
  // Remove inline handler: prevent a full query + DOM build for each keystroke.
  input.removeAttribute('oninput');
  input.setAttribute('type','search');
  input.placeholder='Search bill number / customer / phone';
  input.addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>renderHistory(),180)});
  const style=document.createElement('style');
  style.textContent='body:has(#history.active) #nsSmartSearch{display:none!important}.ns-history-more{padding:15px 0;text-align:center;display:flex;justify-content:center;align-items:center;flex-wrap:wrap;gap:12px}.ns-history-more button{min-height:42px}';
  document.head.append(style);
  renderHistory();
})();
