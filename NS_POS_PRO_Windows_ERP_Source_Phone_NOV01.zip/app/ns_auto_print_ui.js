/* Print once. No manual printer 1/2/3 selection at billing time.
 * Android chooses a reachable paired Xprinter; Windows companion uses OS default.
 */
(()=>{'use strict';
const p=document.getElementById('bluetoothPanel');
if(p){
  // Legacy device-picking controls are no longer part of normal checkout.
  const list=document.getElementById('printerList');if(list)list.style.display='none';
  for(const button of p.querySelectorAll('button')){
    const label=(button.textContent||'').toLowerCase();
    if(label.includes('find paired')||label.includes('select'))button.style.display='none';
  }
  let title=p.querySelector('h2');if(title)title.textContent='🖨 Automatic Receipt Printing';
  const info=document.createElement('p');info.className='hint';
  info.textContent='Android: pair XP-P301A or XP-P502A in phone Bluetooth settings once, then tap Print Bill. Windows: set XP-80T as the Default Printer in Windows Settings. No selection at checkout.';
  p.prepend(info);
}
const button=document.getElementById('ns21PrintNow');
if(button)button.textContent='🖨 Print Bill';
})();
