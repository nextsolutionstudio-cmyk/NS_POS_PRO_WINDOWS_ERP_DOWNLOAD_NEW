/* Core POS daily backup uploader. Requires Cloud Admin login, owner opt-in and online POS.
   Does not read PINs/passwords/session tokens. The export is NOT a replacement for complete
   off-device ERP backups or a checked end-to-end restore workflow. */
(()=>{'use strict';
 const DAY_MS=86400000;
 let uploading=false;
 const allowedKeys=['settings','products','grns','invoices','counter','orders','shops','vehicleLedger','creditPayments','returns','cheques','repClosings','expenses','suppliers','stockTransfers'];
 const bannedFields=/^(password|password_hash|password_salt|pin|pin_hash|secret|token|session|auth|access_token|refresh_token|api_key)$/i;
 function cleanse(value,depth=0){
  if(depth>16)return null;
  if(value===null||typeof value==='number'||typeof value==='boolean'||typeof value==='string')return value;
  if(Array.isArray(value))return value.map(v=>cleanse(v,depth+1));
  if(typeof value==='object'){
   const out={};for(const [k,v] of Object.entries(value)){if(!bannedFields.test(k))out[k]=cleanse(v,depth+1)}
   return out;
  }
  return null;
 }
 function buildSnapshot(){
  if(typeof db==='undefined')throw Error('POS database not loaded');
  const data={};for(const key of allowedKeys){if(Object.prototype.hasOwnProperty.call(db,key))data[key]=cleanse(db[key])}
  for(const key of ['products','invoices','grns'])if(!Array.isArray(data[key]))data[key]=[];
  return {schema_version:1,source:'ns-pos-core-local-db',captured_at:new Date().toISOString(),data};
 }
 function businessCode(){return window.NSCloud?.getBusinessCode?.()||''}
 const dateKey=()=>new Date().toISOString().slice(0,10); // UTC date; one per UTC day
 async function tick(){
  if(uploading||!navigator.onLine||!window.NSCloud?.repCall||window.NSCloud.getRole?.()!=='admin')return;
  const code=businessCode();if(!code)return;
  const key='nspos_core_daily_backup_'+code+'_'+dateKey();
  if(localStorage.getItem(key))return;
  uploading=true;
  try{
   const policy=await window.NSCloud.repCall('/v1/business/backup-policy');
   if(!policy.policy?.cloud_enabled||!policy.policy?.consent_recorded_at)return;
   const snapshot=buildSnapshot();
   if(JSON.stringify(snapshot).length>4.7*1024*1024)throw Error('POS data too large for 5 MB backup endpoint');
   const uploaded=await window.NSCloud.repCall('/v1/business/backup-upload','POST',snapshot);
   if(!uploaded.ok)throw Error('Cloud did not confirm backup');
   localStorage.setItem(key,uploaded.backupId);
   console.info('NS POS daily core backup uploaded',uploaded.created_at);
  }catch(e){console.warn('NS POS daily backup not uploaded:',e.message)}
  finally{uploading=false}
 }
 window.addEventListener('ns-cloud-verified',()=>setTimeout(tick,3500));
 window.addEventListener('online',()=>setTimeout(tick,2500));
 setInterval(tick,30*60*1000); // retry while the app is open and a customer Admin is signed in
 setTimeout(tick,9000);
 window.NSCoreDailyBackup={checkNow:tick};
})();
