/* NS POS PRO - payment choice stability patch.
   Preserve the canonical #iPayment select and its change handlers; only replace its native picker UI.
   Avoid scroll jumps when conditional credit/cheque fields appear.
*/
(() => {
  'use strict';
  const METHODS = [
    { id:'Cash', icon:'💵', en:'Cash', si:'මුදල්', ta:'பணம்' },
    { id:'Credit', icon:'📒', en:'Credit', si:'ණයට', ta:'கடன்' },
    { id:'Card', icon:'💳', en:'Card', si:'කාඩ්', ta:'அட்டை' },
    { id:'Bank Transfer', icon:'🏦', en:'Bank Transfer', si:'බැංකු මාරුව', ta:'வங்கி பரிமாற்றம்' },
    { id:'Cheque', icon:'🧾', en:'Cheque', si:'චෙක්පත්', ta:'காசோலை' }
  ];
  const get = id => document.getElementById(id);
  const lang = () => {
    try { return window.NSLang?.get?.() || localStorage.getItem('nspos_ui_lang') || 'en'; }
    catch (_) { return 'en'; }
  };
  function init() {
    const select = get('iPayment');
    const section = get('invoice');
    if (!select || !section || get('nsPaymentChoices')) return;
    const field = select.closest('.field');
    const oldRow = field && field.closest('.row');
    if (!field || !oldRow || !oldRow.parentNode) return;

    // Keep select unchanged as the source of truth for invoices/receipts and existing listeners.
    const paymentRow = document.createElement('div');
    paymentRow.className = 'ns-payment-stable-section';
    oldRow.insertAdjacentElement('afterend', paymentRow);
    paymentRow.appendChild(field);
    field.classList.add('ns-payment-hidden-native');

    const header = document.createElement('div');
    header.className = 'ns-payment-stable-heading';
    const icon = document.createElement('span'); icon.textContent = '💳';
    const heading = document.createElement('strong');
    header.append(icon, heading);
    const choices = document.createElement('div');
    choices.id = 'nsPaymentChoices';
    choices.className = 'ns-payment-stable-options';
    choices.setAttribute('role', 'group');
    paymentRow.prepend(header);
    paymentRow.appendChild(choices);

    for (const entry of METHODS) {
      // Upgrade module adds Cheque. Show it only if the existing business logic supports it.
      if (![...select.options].some(opt => opt.value === entry.id)) continue;
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'ns-payment-option ns-payment-' + entry.id.toLowerCase().replace(/\s+/g,'-');
      button.dataset.payment = entry.id;
      button.innerHTML = `<span class="ns-payment-emoji" aria-hidden="true">${entry.icon}</span><span class="ns-payment-label"></span>`;
      button.addEventListener('click', () => {
        // Blur input to avoid mobile keyboard resize/scroll retaining a stale focus.
        if (document.activeElement && document.activeElement !== document.body &&
            /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName)) document.activeElement.blur();
        if (select.value !== entry.id) {
          select.value = entry.id;
          select.dispatchEvent(new Event('change', { bubbles: true }));
        }
        render();
      });
      choices.appendChild(button);
    }

    // Conditional sections were inserted immediately below the native select, causing
    // all the product/cart controls to move when user selected Credit/Cheque.
    // Keep them under the optional payment note instead.
    const noteField = get('iPaymentNote')?.closest('.field');
    let extraAnchor = noteField;
    for (const id of ['v38DueWrap','ns2ChequeFields']) {
      const extra = get(id);
      if (extra && extraAnchor && extraAnchor.parentNode) {
        extraAnchor.insertAdjacentElement('afterend',extra);
        extraAnchor=extra;
      }
    }

    function render() {
      const current = select.value;
      const language = lang();
      heading.textContent = language === 'si' ? 'ගෙවීමේ ක්‍රමය' : language === 'ta' ? 'கட்டண முறை' : 'Payment Method';
      choices.querySelectorAll('button').forEach(button => {
        const entry = METHODS.find(m => m.id === button.dataset.payment);
        if (!entry) return;
        button.querySelector('.ns-payment-label').textContent = entry[language] || entry.en;
        const active = entry.id === current;
        button.classList.toggle('is-selected', active);
        button.setAttribute('aria-pressed', active ? 'true' : 'false');
        button.setAttribute('aria-label', entry[language] || entry.en);
      });
    }
    select.addEventListener('change',render);
    const languageSelect = get('nsLangSelect');
    if (languageSelect) languageSelect.addEventListener('change',render);
    // Programmatic reset of payment type from the existing Save Invoice flow.
    if (typeof window.saveInvoice === 'function') {
      const prevSave = window.saveInvoice;
      window.saveInvoice = function(...args) {
        const result = prevSave.apply(this,args);
        render();
        return result;
      };
    }
    // Payment fields in this app use the same canonical select value, so history and
    // cloud payloads do not change.
    render();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once: true});
  else init();
})();
