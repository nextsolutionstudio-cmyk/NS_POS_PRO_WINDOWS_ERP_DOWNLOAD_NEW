/* Windows system-printer test. Prints only after a click; no fake success toast. */
(()=>{if(!window.NSDesktop?.testPrint || window.NSDesktopPrinter?.getStatus)return;const panel=document.getElementById('settings');if(!panel)return;
const card=document.createElement('div');card.className='panel';card.innerHTML='<h2>🖨 Windows Printer</h2><div class="actions"><button type="button" class="primary" id="ns34TestWindowsPrint">Test Print (Windows)</button><button type="button" class="secondary" id="ns34ReceiptWindowsPrint">Print Saved Bill</button></div><p class="hint">Windows printer driver required. Choose your 80mm thermal printer in the print dialog.</p>';
panel.append(card);
document.getElementById('ns34TestWindowsPrint').onclick=async()=>{const r=await window.NSDesktop.testPrint();if(r?.ok)toast('Test sent to Windows print queue');else toast(r?.error||'Print cancelled')};
document.getElementById('ns34ReceiptWindowsPrint').onclick=()=>{let inv=db.invoices?.at(-1);if(!inv)return toast('Save a bill first');previewInvoice=inv;showPreview(true);};
})();