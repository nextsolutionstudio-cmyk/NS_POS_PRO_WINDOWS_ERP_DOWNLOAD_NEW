/* Owner-managed billing appearance; no remote HTML, scripts or billing changes. */
(()=>{'use strict';
 const ROOT='nspos_cloud_v1_daily_session', STORE='nspos_bill_design_';
 const DEFAULT={theme:'ocean',layout:'cards',icons:{customer:'👤',items:'📦',pay:'💳',complete:'✅'}};
 const THEMES={ocean:['#2165d5','#168b60','#d2871c','#7653b3'],emerald:['#0e8792','#14865e','#ce7d1d','#3c74b9'],violet:['#7753c9','#3579bc','#ad5294','#5e63ba'],sunset:['#ce6940','#348b77','#bf8a29','#9a5bc3']};
 const ICONS={customer:['👤','🏪','🤝'],items:['📦','🛒','🏷️'],pay:['💳','💵','🏦'],complete:['✅','🧾','🖨️']};
 const get=id=>document.getElementById(id);
 const tenant=()=>{try{return JSON.parse(localStorage.getItem(ROOT)||'null')?.auth?.tenant?.id||''}catch(_){return ''}};
 let currentTenant='',lastAttempt=0,working=false;
 function valid(c){if(!c||typeof c!=='object')return DEFAULT;
  const icons={};for(const k of Object.keys(ICONS))icons[k]=ICONS[k].includes(c.icons?.[k])?c.icons[k]:DEFAULT.icons[k];
  return {theme:THEMES[c.theme]?c.theme:'ocean',layout:['cards','compact','simple'].includes(c.layout)?c.layout:'cards',icons};
 }
 function structure(){const invoice=get('invoice');const panel=invoice?.querySelector('.panel');if(!panel)return false;
  if(panel.dataset.nsBillCards==='1')return true;
  const steps=['customer','items','pay','complete'];
  const headings=steps.map(step=>panel.querySelector(`.ns-flow-heading[data-step="${step}"]`));
  if(headings.some(x=>!x))return false;
  // Payment UI is placed after Bill Mode by the stable-payment module; relocate to the payment card.
  const payment=panel.querySelector('.ns-payment-stable-section');
  if(payment)headings[2].insertAdjacentElement('afterend',payment);
  steps.forEach((step,i)=>{const card=document.createElement('div');card.className='ns-bill-card';card.dataset.billSection=step;
   panel.insertBefore(card,headings[i]);let node=headings[i];const stop=headings[i+1]||null;
   while(node && node!==stop){const next=node.nextSibling;card.appendChild(node);node=next;}
  });
  panel.dataset.nsBillCards='1';return true;
 }
 function paint(config){const root=get('invoice');if(!root)return;
  const c=valid(config);if(!structure())return;
  root.classList.toggle('ns-bill-compact',c.layout==='compact');root.classList.toggle('ns-bill-simple',c.layout==='simple');
  const colors=THEMES[c.theme];['customer','product','payment','finish'].forEach((k,i)=>root.style.setProperty('--ns-bill-'+k,colors[i]));
  for(const [section,icon] of Object.entries(c.icons)){
   const heading=root.querySelector(`.ns-flow-heading[data-step="${section}"] .ns-flow-step`);if(heading)heading.textContent=icon;
  }
 }
 function cached(code){try{const raw=JSON.parse(localStorage.getItem(STORE+code)||'null');return valid(raw?.design||DEFAULT)}catch(_){return DEFAULT}}
 function refreshTenant(){const code=tenant();if(code!==currentTenant){currentTenant=code;lastAttempt=0;paint(code?cached(code):DEFAULT);}return code}
 async function pull(){const code=refreshTenant();if(!code||!navigator.onLine||working||Date.now()-lastAttempt<90000||typeof window.NSCloud?.repCall!=='function')return;
  working=true;lastAttempt=Date.now();
  try{const data=await window.NSCloud.repCall('/v1/business/bill-design');if(code!==tenant())return;
   const c=valid(data?.design||DEFAULT);localStorage.setItem(STORE+code,JSON.stringify({design:c,revision:data?.revision||0}));paint(c);
  }catch(_){/* Offline, API not deployed, or session locked: retain last safe layout. */}finally{working=false}
 }
 function start(){structure();refreshTenant();void pull();
  document.addEventListener('click',e=>{if(e.target.closest('[data-page="invoice"], [onclick*="invoice"]'))setTimeout(pull,200)});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void pull()});
  window.addEventListener('online',()=>void pull());
  setInterval(()=>{refreshTenant();if(!document.hidden)void pull()},60000);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(start,20),{once:true});else setTimeout(start,20);
})();
