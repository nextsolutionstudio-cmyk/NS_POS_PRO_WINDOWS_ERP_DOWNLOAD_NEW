NS POS PRO v3.9 CLOUD LOGIN FIX (2026-10-24)

Why Create Login failed:
Cloudflare Workers production rejects PBKDF2 iterations >100,000.
The earlier worker used 160,000, causing a server-side 500.
This patch uses 100,000 and adds a private HMAC pepper.

SAFETY FIRST
1. Keep the existing D1 database, existing Worker name, and Owner Portal.
2. DO NOT re-run database migrations or delete any tables for this fix.
3. This requires a NEW secret named AUTH_PEPPER. Do not store it in source or send it in chat.
4. WARNING: any existing customer users created under the old password algorithm will NOT login with this patched version. If you already have real customer users, migrate/reset them before applying. In the reported case creating the first user failed. Owner account is not affected.
5. Keep a secure backup of AUTH_PEPPER; changing it invalidates all customer passwords.

STEPS ON WINDOWS
A. Extract this ZIP to a NEW folder.
B. Open the folder containing package.json and wrangler.toml.
C. Update database_id in wrangler.toml with the SAME real existing database ID from your old project. DO NOT create a new D1 database.
D. Open CMD in this folder.
E. npm install
F. If necessary: npx wrangler login
G. Generate a private random pepper (do not send it to anybody):
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   Copy the displayed 64-character output somewhere secure.
H. npx wrangler secret put AUTH_PEPPER
   Paste that value when prompted. If prompted to create Worker, ensure it is the existing ns-pos-pro-cloud project.
I. npm run deploy
J. Open https://ns-pos-pro-cloud.nextsolutionstudio.workers.dev/v1/health
K. Login to your existing Owner Portal and try Create Login using a NEW 12+ character customer password.
L. Check real-time logs if any error remains.

This patch changes Worker server code ONLY. No need to re-upload Owner Portal.
Workers Free CPU: 10ms/request; actual results depend on Cloudflare runtime.
Customer password processing remains security-sensitive: do not put customer-facing use into production until tests and independent security review are complete.
