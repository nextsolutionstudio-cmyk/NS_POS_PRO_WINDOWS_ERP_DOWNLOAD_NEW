import test from 'node:test';import assert from 'node:assert/strict';
import worker from '../src/worker.js';
class DB{
 constructor(){this.tenant={id:'TEST_COMPANY',name:'Test Company',status:'blocked',expires_at:'2026-01-01T00:00:00.000Z'};this.revoked=false;}
 prepare(sql){const db=this;return {bind(...values){return {
  first:async()=>sql.includes('FROM sessions')?{role:'owner',expires_at:'2099-01-01T00:00:00Z'}:sql.includes('FROM tenants')?db.tenant:null,
  run:async()=>{if(sql.includes('UPDATE tenants SET expires_at=?,status=?')){db.tenant.expires_at=values[0];db.tenant.status=values[1]};if(sql.includes('UPDATE tenants SET expires_at=? WHERE'))db.tenant.expires_at=values[0];if(sql.includes('DELETE FROM sessions'))db.revoked=true;return {meta:{changes:1}}},
  all:async()=>({results:[]})
 }}};}
 async batch(queries){for(const q of queries)await q.run();return [{meta:{changes:1}}]}
}
async function post(db,route,body){const req=new Request('https://example.com'+route,{method:'POST',headers:{Authorization:'Bearer owner-demo'},body:JSON.stringify(body)});const res=await worker.fetch(req,{DB:db});return {status:res.status,data:await res.json()}}
test('owner can issue 7-day trial and revoke old sessions',async()=>{const db=new DB(),r=await post(db,'/v1/owner/start-trial',{businessCode:'TEST_COMPANY',days:7});assert.equal(r.status,200);assert.equal(db.tenant.status,'active');assert.equal(db.revoked,true);assert.ok(Date.parse(db.tenant.expires_at)>Date.now()+6*86400000)});
test('trial duration rejected outside supported bounds',async()=>{const db=new DB(),r=await post(db,'/v1/owner/start-trial',{businessCode:'TEST_COMPANY',days:999});assert.equal(r.status,400);assert.equal(db.tenant.status,'blocked')});
test('exact trial expiry uses Sri Lanka end-of-day',async()=>{const db=new DB(),r=await post(db,'/v1/owner/set-expiry',{businessCode:'TEST_COMPANY',date:'2026-11-03'});assert.equal(r.status,200);assert.equal(db.tenant.expires_at,'2026-11-03T18:29:59.999Z')});
test('nonsensical calendar date is rejected',async()=>{const db=new DB(),r=await post(db,'/v1/owner/set-expiry',{businessCode:'TEST_COMPANY',date:'2026-02-31'});assert.equal(r.status,400)});
