import test from 'node:test';
import assert from 'node:assert/strict';
import {handleERP} from '../src/erp.js';
class MockDB {
 constructor(){this.records=new Map();this.audit=[]}
 prepare(sql){const db=this;return {bind(...params){return {async first(){if(sql.includes('FROM tenants'))return {status:'active',expires_at:'2028-01-01T00:00:00Z'};return null},async all(){if(sql.includes('FROM ns_erp_records')){const [tenant,kind]=params;return {results:[...db.records.values()].filter(x=>x.tenant===tenant&&x.kind===kind).map(x=>({id:x.id,payload:JSON.stringify(x.payload),revision:x.revision,updated_at:'now'}))}}return {results:[]}},async run(){if(sql.startsWith('INSERT OR IGNORE INTO ns_erp_records')){const [tenant,kind,id,key,payload]=params;let idx=tenant+'|'+kind+'|'+id;if(db.records.has(idx)||[...db.records.values()].some(x=>x.tenant===tenant&&x.kind===kind&&x.key===key))return {meta:{changes:0}};db.records.set(idx,{tenant,kind,id,key,payload:JSON.parse(payload),revision:1});return {meta:{changes:1}}}
 if(sql.startsWith('UPDATE ns_erp_records')){const [payload,key,at,actor,tenant,kind,id,version]=params;const r=db.records.get(tenant+'|'+kind+'|'+id);if(!r||r.revision!==version)return {meta:{changes:0}};Object.assign(r,{payload:JSON.parse(payload),key,revision:r.revision+1});return {meta:{changes:1}}}
 if(sql.startsWith('INSERT INTO ns_erp_audit')){db.audit.push(params);return {meta:{changes:1}}}
 return {meta:{changes:0}}}}}}}
}
const db=new MockDB(),env={DB:db};
const u=(role,tenant_id)=>({role,user_id:role+'-1',tenant_id});
async function req(method,kind,user,value,id='id-1',rev=0){const q='https://example.com/v1/erp/records?kind='+kind;const r=new Request(q,{method,...(method==='PUT'?{headers:{'content-type':'application/json'},body:JSON.stringify({id,expectedRevision:rev,value})}:{})});const res=await handleERP(r,env,user);return {status:res.status,data:await res.json()}}
const emp={id:'id-1',empNo:'001',name:'Test Person',basic:100000,allowance:0,epfBase:100000,active:true};
test('admin can insert then read employee within own tenant',async()=>{const a=await req('PUT','employees',u('admin','a'),emp);assert.equal(a.status,200);assert.equal(a.data.revision,1);const r=await req('GET','employees',u('admin','a'));assert.equal(r.data.records.length,1)});
test('HR role can read employee but cannot read Accounts',async()=>{const a=await req('GET','employees',u('hr','a'));assert.equal(a.status,200);const b=await req('GET','entries',u('hr','a'));assert.equal(b.status,403)});
test('Rep role cannot read payroll',async()=>{const r=await req('GET','payroll',u('rep','a'));assert.equal(r.status,403)});
test('Tenant data never crosses between businesses',async()=>{const r=await req('GET','employees',u('admin','b'));assert.equal(r.data.records.length,0)});
test('Stale update fails closed at revision check',async()=>{const x=await req('PUT','employees',u('admin','a'),{...emp,basic:110000},'id-1',1);assert.equal(x.status,200);const old=await req('PUT','employees',u('admin','a'),{...emp,basic:120000},'id-1',1);assert.equal(old.status,409)});
test('Client cannot create duplicate employee ID for same business',async()=>{const r=await req('PUT','employees',u('admin','a'),{...emp,id:'id-2'},'id-2',0);assert.equal(r.status,409)});
test('Invalid HR salary record blocked',async()=>{const r=await req('PUT','payroll',u('hr','a'),{id:'id-1',employeeId:'id-1',period:'bad',employerCost:1,net:1,gross:1,employeeEPF:1,employerEPF:1,employerETF:1,otPay:1});assert.equal(r.status,400)});
