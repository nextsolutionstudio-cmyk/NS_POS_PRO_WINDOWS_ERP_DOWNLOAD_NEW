-- Apply to the EXISTING ns-pos-cloud D1 database; retains all POS, tenants, branding, and subscription records.
-- Separate HR identities avoid rebuilding the legacy users table, which permits only admin/rep.
CREATE TABLE IF NOT EXISTS ns_erp_hr_users (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, email TEXT NOT NULL COLLATE NOCASE,
 username TEXT NOT NULL COLLATE NOCASE, password_salt TEXT NOT NULL, password_hash TEXT NOT NULL,
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
 FOREIGN KEY(tenant_id) REFERENCES tenants(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_erp_hr_username ON ns_erp_hr_users(lower(username));
CREATE UNIQUE INDEX IF NOT EXISTS idx_erp_hr_email ON ns_erp_hr_users(lower(email));
CREATE INDEX IF NOT EXISTS idx_erp_hr_tenant ON ns_erp_hr_users(tenant_id);
-- Each record is tenant-scoped, revisioned and server-authorized; never a whole-device overwrite.
CREATE TABLE IF NOT EXISTS ns_erp_records (
 tenant_id TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, natural_key TEXT NOT NULL,
 payload TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL, updated_by TEXT NOT NULL,
 PRIMARY KEY(tenant_id,kind,id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_erp_natural ON ns_erp_records(tenant_id,kind,natural_key);
CREATE INDEX IF NOT EXISTS idx_erp_kind ON ns_erp_records(tenant_id,kind,updated_at);
-- Immutable invoice identity per tenant: re-sending an invoice id updates that exact bill, not an aggregate snapshot.
CREATE TABLE IF NOT EXISTS ns_erp_sales (
 tenant_id TEXT NOT NULL, invoice_id TEXT NOT NULL, source_device TEXT NOT NULL,
 branch TEXT NOT NULL, sold_at TEXT NOT NULL, sales_ex_tax REAL NOT NULL,
 cost REAL NOT NULL, cost_unknown INTEGER NOT NULL, tax REAL NOT NULL,
 voided INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL,
 PRIMARY KEY(tenant_id,invoice_id)
);
CREATE INDEX IF NOT EXISTS idx_erp_sales_date ON ns_erp_sales(tenant_id,sold_at);
CREATE TABLE IF NOT EXISTS ns_erp_audit (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, actor TEXT NOT NULL,
 action TEXT NOT NULL, target TEXT NOT NULL, at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_erp_audit_tenant ON ns_erp_audit(tenant_id,at);
