-- Run on EXISTING Cloudflare D1 database; does not alter products, bills or users.
CREATE TABLE IF NOT EXISTS ns_remote_controls (
 business_id TEXT PRIMARY KEY NOT NULL,
 config_json TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL
);
