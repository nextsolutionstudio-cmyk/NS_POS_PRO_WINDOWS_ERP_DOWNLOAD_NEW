-- Apply ONCE to the existing ns-pos-cloud D1 database.
-- Branding is tenant-scoped. Existing POS records and customer credentials are unchanged.
CREATE TABLE IF NOT EXISTS tenant_branding (
  tenant_id TEXT PRIMARY KEY,
  phone TEXT NOT NULL DEFAULT '',
  logo_data TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id)
);
CREATE TABLE IF NOT EXISTS tenant_branding_audit (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  changed_at TEXT NOT NULL,
  changed_fields TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_branding_audit_tenant ON tenant_branding_audit(tenant_id,changed_at);
