ALTER TABLE users ADD COLUMN username TEXT COLLATE NOCASE;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_tenant_username ON users(tenant_id,username) WHERE username IS NOT NULL;
