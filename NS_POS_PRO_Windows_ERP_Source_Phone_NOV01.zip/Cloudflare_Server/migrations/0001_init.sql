CREATE TABLE IF NOT EXISTS tenants (id TEXT PRIMARY KEY, name TEXT NOT NULL, fee_lkr INTEGER NOT NULL DEFAULT 1000, expires_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, email TEXT NOT NULL COLLATE NOCASE, password_salt TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','rep')), active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, UNIQUE (tenant_id,email));
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT, tenant_id TEXT, role TEXT NOT NULL, expires_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_sessions_exp ON sessions(expires_at);
CREATE TABLE IF NOT EXISTS payment_requests (id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, user_id TEXT NOT NULL, reference TEXT, amount_lkr INTEGER NOT NULL, slip_data TEXT, status TEXT NOT NULL DEFAULT 'pending', submitted_at TEXT NOT NULL, reviewed_at TEXT, reviewed_note TEXT);
CREATE INDEX IF NOT EXISTS idx_payment_tenant ON payment_requests(tenant_id,submitted_at);
CREATE TABLE IF NOT EXISTS device_snapshots (tenant_id TEXT NOT NULL, user_id TEXT NOT NULL, device_id TEXT NOT NULL, revision INTEGER NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(tenant_id,user_id,device_id));
CREATE TABLE IF NOT EXISTS login_attempts (id TEXT PRIMARY KEY, window_start TEXT NOT NULL, fails INTEGER NOT NULL DEFAULT 0);
