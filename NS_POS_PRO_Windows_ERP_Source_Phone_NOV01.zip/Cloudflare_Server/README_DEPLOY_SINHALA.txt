NS POS PRO - Existing Cloudflare Worker update

1. BACK UP the existing D1 database before deploying. Do NOT create a new D1 database.
2. Install Node.js 20+ and unzip this project. Open terminal inside this folder.
3. Run: npm install
4. Run: npx wrangler login
5. Cloudflare Dashboard > Workers & Pages > D1 > ns-pos-cloud: copy existing database ID.
6. Replace REPLACE_WITH_YOUR_D1_DATABASE_ID in wrangler.toml with the EXISTING database ID.
7. Verify Worker name is ns-pos-pro-cloud and account matches your existing deployment.
8. Existing secrets OWNER_EMAIL, OWNER_PASSWORD, AUTH_PEPPER must remain configured. Never replace AUTH_PEPPER on a running account unless you plan a password migration.
9. Run: npx wrangler d1 migrations apply ns-pos-cloud --remote (ONLY after reviewing existing schema and backup).
10. Run: npx wrangler deploy
11. Open owner_portal.html in browser, enter existing Worker URL and owner credentials.
12. For hosted portal, upload owner_portal.html as index.html to a Cloudflare Pages site.
13. Test with a TEST business: login, user list, password reset, block/unblock, payment approve and expiry status.

IMPORTANT: Payment approvals are MANUAL. Verify actual bank deposit before Approve & Renew.
IMPORTANT: Android POS offline access may not be fully locked by server status. Test on device before commercial rollout.
IMPORTANT: 'Remove' is soft disable, not destructive delete.
