# NS POS PRO Developer Owner — Desktop Trial Control v4.6

Back up existing Cloudflare Worker/D1 first; deploy updated `src/worker.js` and `owner_portal.html`. No new D1 table is needed for the trial actions. Keep Worker secrets out of the company EXE. If current deployment predates v4.5, run only missing D1 migrations in order.

Authenticated owner endpoints (existing bearer token):

- `POST /v1/owner/start-trial` body `{"businessCode":"TEST_COMPANY","days":7}`. Supports 1–90 days from NOW, sets active, REPLACES expiry, revokes all business sessions.
- `POST /v1/owner/set-expiry` body `{"businessCode":"TEST_COMPANY","date":"2026-11-03"}`. Date is Sri Lanka end-of-day at UTC+05:30; accepts valid ISO date, updates expiry, DOES NOT silently unblock.
- Existing `POST /v1/owner/set-status` body `{"businessCode":"TEST_COMPANY","status":"blocked"}`. Blocks, revokes all tenant sessions.
- Existing `POST /v1/owner/extend` body `{"businessCode":"TEST_COMPANY","days":30}`. Extends and activates.
- Existing `POST /v1/auth/me` checks business license; Desktop app polls it every 30 seconds and requires Internet.

## Private Portal
Updated `owner_portal.html`: **3-Day Trial**, **7-Day Trial**, **14-Day Trial**, **Set Expiry**, plus existing **Block/Unblock**, `+30 Days`. Your previously installed Owner app is not automatically updated merely by deploying Worker code; update its UI or use this private portal. Never expose owner credentials, database tokens or `wrangler.toml` to trial companies.
