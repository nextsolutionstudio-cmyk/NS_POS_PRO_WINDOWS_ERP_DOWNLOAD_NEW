# NS POS PRO Customer v4.5 – Cloud HR / Accounts / Multi-Counter Profit (Source Prototype)

**වැදගත්:** මෙය Live Cloudflare deployment එකක් හෝ Phone එකක install කළ APK එකක් නොවේ. Android GitHub source project එක සහ Cloudflare Worker/D1 migration source එක අඩංගු වේ. Coding/test checks අවසන්; production rollout එකට staged testing, security review, verified backup, accounting review අවශ්‍යයි.

## අලුත් දේ

- Customer App එකේ **Developer Branding Access** unlock box ඉවත් කළ v4.4 වෙනස්කම රැකගනී; branding පාලනය Developer Owner මගින්ම සිදුකරයි.
- Employee add/edit, Attendance, OT, EPF / ETF, Salary / Payslip, Cashbook income/expenses, Daily/Monthly/Annual Profit වැනි v4.4 screens රැකගනී.
- **Cloud ERP records:** employee, attendance, payroll, expense/income සහ payroll settings – Cloudflare D1 ගබඩා කිරීම සඳහා authenticated endpoints.
- **Cloud HR login:** Adminට වෙනම HR cloud username/email සහ අවම අක්ෂර 12 password create/enable/disable කළ හැක. HRට Accounts/Profit නැත; Adminට සියල්ල.
- **Tenant isolation:** request body එකෙන් business code දීමෙන් වෙනත් ආයතනයේ records බලන්න බැහැ; server-side token වෙතින් tenant තෝරයි.
- **Optimistic revisions:** දුරකථන දෙකක් එකම record එක එකවර update කළොත් දෙවැනි update එක `409 Conflict`; දත්ත නිහඬව මකන්නේ නැහැ.
- **Offline queue:** Internet නැති වෙලාවේ phone එකේ update save වෙයි. Network පවතින විට '☁ Cloud Sync' භාවිත කළ හැක.
- **Explicit legacy import:** පෙර v4.4 Local Employee/Payroll data ඔබේ අවසරයකින් තොරව upload නොවේ; පරණ records මකා නොදමන්න sync එක නවතයි.
- **Multiple counter bill summaries:** පෙර සිට තිබෙන cloud '☁ Sync' ක්‍රියාව මඟින් device එකේ Invoice summaries (customer name/NIC නොමැතිව) upload කළ හැක. Duplicate invoice IDs source device අනුව collision පරීක්ෂා වේ.
- **Cloud Profit:** ERP Profit page එකේ Daily/Monthly/Annual period තෝරා `☁ Show All-Counter Cloud Profit` ඔබන්න. Branch/Counter data Cloud එකට upload වී තිබිය යුතුය.
- පෙර **Xprinter XP-P502A 58mm fix** වෙනස්කම් ඉවත් කරලා නැහැ (physical printer test මෙහිදී කර නොමැත).

## Install/Deploy: අනුපිළිවෙළ වැදගත්

1. දැනට වැඩ කරන Cloudflare Worker source සහ D1 data **Backup** කරන්න. Database ID/Secrets වෙනස් නොකරන්න. වැඩ කරන version එකට ආපසු යා හැකිව තබාගන්න.
2. `Cloudflare_Server/` තුළ දැනට තිබෙන Worker source එක සහ `migrations/0005_erp.sql` ඇත. **Existing** Cloudflare D1 එකට ONLY pending migrations apply කරන්න:

   ```bash
   cd Cloudflare_Server
   npm install
   npx wrangler d1 migrations apply ns-pos-cloud --remote
   npx wrangler deploy
   ```

3. Deploy කරන Worker endpoint එක දැනට App එක භාවිත කරන URL එකම බවත්, D1 binding `DB`, `AUTH_PEPPER`, `OWNER_EMAIL`, `OWNER_PASSWORD` secrets පෙර ලෙසම තියෙන බවත් තහවුරු කරන්න. **Secrets GitHub එකට upload කරන්න එපා.**
4. `android-project/` තුළ තිබෙන files (hidden `.github` folder එකත් ඇතුළුව) existing Android GitHub repository root එකට upload කරන්න. Actions → **Build NS POS PRO Recovery APK** → Run workflow.
5. Successful build එකෙන් **NS_POS_PRO_v4_5_Cloud_ERP_Debug_APK** artifact ZIP download කර extract කරන්න. APK ගොනුවක් හමු වෙයි. Existing App Uninstall කරන්න කලින් local data backup කරන්න. Debug APK signing certificates වෙනස් නම් Android update failed විය හැක; app removal දත්ත මකා දැමිය හැක.
6. පළමුව **test business / test employees** පමණක් භාවිත කරන්න. Business Admin Cloud login → Local Admin PIN login → **HR · Accounts** page → `Cloud Sync`. පෙර local HR/Accounts records තිබේ නම් `Import existing local ERP (Confirm)` ඔබන්න.
7. Admin → HR Access tab → HR Cloud Username, Email, 12+ character Password Create. HR Phone එකේ Cloud login කළ පසු HR/Payroll page බලන්න. HR account deactivate කළහොත් cloud session අවලංගු වේ.
8. **සෑම counter phone එකකම** Cloud `☁ Sync` ඔබන්න. Admin account එකක **HR · Accounts → Profit** page එකේ period තෝරලා `☁ Show All-Counter Cloud Profit` ඔබන්න.

## Testing / Guardrails

- `node --test Cloudflare_Server/tests/erp.test.mjs` – 7 backend mock tests: authorization, tenant isolation, revisions, duplicates, validation.
- Source JS files `node --check` (41 files) – pass.
- SQLite in-memory migration run (0001–0005) – pass.
- Real Cloudflare deployment, Android APK build and Bluetooth printer physical test – **not performed**.

## Accounting / Privacy Limitations

- **Cloud Profit preliminary only**, not a certified ledger. It counts only acknowledged bills still available for upload. Old invoices lacking historical purchase cost are flagged, so Net Profit should not be treated as accurate.
- Returns are currently allocated against the original sale period in cloud summary. Payroll is counted in the first day of the salary month, and daily profit may not represent true daily accrual. Invoices, payroll, expenses and branches require reconciliation.
- The app's old POS data model remains local on each device, and general stock sync is not an authoritative multi-user transaction database.
- The existing local POS PIN and local Storage are not adequate controls for regulated/sensitive payroll on a shared device. Independent staff devices and further encryption, data-retention, backups, audit reviews and security assessment are required before real salary/NIC/bank information is used.
- EPF/ETF defaults and OT divisor must be checked against applicable Sri Lankan law and individual employee classification. This package **does not submit tax or statutory returns**.
- **Never** upload real employee files, NICs, salary details, or passwords to test instances until privacy/security and permissions are reviewed.

© Developed by Next Solution Studio – NS POS PRO source prototype.
