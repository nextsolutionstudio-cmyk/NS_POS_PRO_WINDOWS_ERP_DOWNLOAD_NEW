/* Cloudflare Worker plugin for NS POS PRO Remote Branding / Seasonal UI.
 * This module MUST be wired to existing OWNER and CUSTOMER authenticated sessions.
 * It must NOT be used without the required authorization callbacks.
 */
const EFFECTS=new Set(['none','snow','christmas','new_year','vesak']);
const LIMIT=275000;
function json(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}})}
const str=(v,max=250)=>String(v??'').trim().slice(0,max);
function normalize(body){
 const b=body?.branding||{},v=body?.visuals||{},logo=str(b.logo_data,250000);
 if(logo&&(!/^data:image\/(?:png|jpeg|webp);base64,[a-zA-Z0-9+/=]+$/.test(logo)||logo.length>210000))throw Error('Logo must be an image data URL smaller than 210KB');
 const brand={name:str(b.name,100),phone:str(b.phone,40),phone2:str(b.phone2,40),phone3:str(b.phone3,40),email:str(b.email,150),website:str(b.website,200),address:str(b.address,300),logo_data:logo};
 if(!brand.name)throw Error('Business name is required');
 if(brand.email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(brand.email))throw Error('Email is not valid');
 if(brand.website&&!/^https:\/\//.test(brand.website))throw Error('Website must start with https://');
 const enabled=v.enabled===true,effect=EFFECTS.has(v.effect)?v.effect:'none';
 const date=s=>{s=str(s,10);if(s&&!/^\d{4}-\d{2}-\d{2}$/.test(s))throw Error('Dates must use YYYY-MM-DD');return s};
 const starts_on=date(v.starts_on),ends_on=date(v.ends_on);
 if(starts_on&&ends_on&&starts_on>ends_on)throw Error('End date before start date');
 const density=Math.max(10,Math.min(50,Math.round(Number(v.density)||20)));
 return {branding:brand,visuals:{enabled,effect,starts_on,ends_on,density}};
}
export async function handleRemoteControl(request,env,security){
 const u=new URL(request.url),owner=u.pathname.match(/^\/v1\/owner\/businesses\/([\w-]{1,100})\/remote-config$/);
 const customer=u.pathname==='/v1/business/remote-config';
 if(!owner&&!customer)return null;
 try{
  if(!env.DB||!security||typeof security.requireOwner!=='function'||typeof security.requireCustomer!=='function')throw Error('Remote config not fully installed: missing database or auth adapters');
  // These callbacks must verify the existing Worker auth token server-side (never trust client-supplied role or business ID).
  let businessId;
  if(owner){
   const ownerIdentity=await security.requireOwner(request,env);
   if(!ownerIdentity)return json({error:'Owner authentication required'},401);
   businessId=owner[1];
   // Optional business-existence validation should use the existing Businesses table before allowing PUT.
   if(security.businessExists&&!(await security.businessExists(businessId,env)))return json({error:'Business not found'},404);
  }else{
   if(request.method!=='GET')return json({error:'Method not allowed'},405);
   const customerIdentity=await security.requireCustomer(request,env);
   businessId=String(customerIdentity?.tenantId||'');
   if(!businessId)return json({error:'Customer tenant authentication required'},401);
  }
  if(!['GET','PUT'].includes(request.method))return json({error:'Method not allowed'},405);
  if(customer&&request.method!=='GET')return json({error:'Customer read only'},405);
  const row=await env.DB.prepare('SELECT config_json,revision FROM ns_remote_controls WHERE business_id=?').bind(businessId).first();
  if(request.method==='GET'){
   const data=row?JSON.parse(row.config_json):{branding:null,visuals:{enabled:false,effect:'none',starts_on:'',ends_on:'',density:20}};
   return json({...data,revision:Number(row?.revision||0)});
  }
  const contentLength=Number(request.headers.get('content-length')||0);if(contentLength>LIMIT)return json({error:'Request too large'},413);
  const raw=await request.text();if(raw.length>LIMIT)return json({error:'Request too large'},413);
  let body;try{body=JSON.parse(raw)}catch(_){return json({error:'Invalid JSON'},400)}
  const expected=Number(body.expected_revision);const previous=Number(row?.revision||0);
  if(!Number.isInteger(expected)||expected!==previous)return json({error:'Someone else updated this business. Reload before publishing.',current_revision:previous},409);
  let clean;try{clean=normalize(body)}catch(err){return json({error:err.message},400)}
  // Atomic optimistic concurrency: prevent simultaneous owner updates from overwriting each other.
  const now=new Date().toISOString();const data=JSON.stringify(clean);
  let result;
  if(row){result=await env.DB.prepare('UPDATE ns_remote_controls SET config_json=?,revision=revision+1,updated_at=? WHERE business_id=? AND revision=?').bind(data,now,businessId,previous).run()}
  else{result=await env.DB.prepare('INSERT OR IGNORE INTO ns_remote_controls(business_id,config_json,revision,updated_at) VALUES(?,?,1,?)').bind(businessId,data,now).run()}
  if(!result.meta?.changes)return json({error:'Concurrent edit; reload and try again'},409);
  return json({ok:true,revision:previous+1});
 }catch(err){
  // Auth adapters must throw on invalid tokens; fail closed. No token or password logged.
  const code=/auth|token|permission|forbidden|unauthorized/i.test(String(err?.message||''))?403:500;
  return json({error:code===403?'Access denied':'Remote configuration error. Check Worker deployment and D1 migration.'},code)
 }
}
