import { handleRemoteControl } from './remote-controls.js';
import { handleERP } from './erp.js';
const encoder=new TextEncoder();
const headers={'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'*','access-control-allow-headers':'Authorization, Content-Type','access-control-allow-methods':'GET, POST, OPTIONS'};
const now=()=>new Date().toISOString(),isoPlus=(d,days)=>new Date(new Date(d).getTime()+days*86400000).toISOString();
const json=(obj,code=200)=>new Response(JSON.stringify(obj),{status:code,headers});
const fail=(message,code=400)=>json({ok:false,error:message},code);
const random=()=>crypto.randomUUID()+crypto.randomUUID().replaceAll('-','');
const sha=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const b64=bytes=>btoa(String.fromCharCode(...bytes));
const un64=str=>Uint8Array.from(atob(str),c=>c.charCodeAt(0));
// Cloudflare Workers production PBKDF2 limit is 100,000 iterations.
// An independent, server-side HMAC pepper helps protect passwords if only D1 data leaks.
// Keep AUTH_PEPPER private and unchanged after customer accounts have been created.
async function hashPassword(password,salt,pepper){
 if(!pepper||pepper.length<32)throw Error('AUTH_PEPPER secret missing or too short (32+ chars)');
 const hmac=await crypto.subtle.importKey('raw',encoder.encode(pepper),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const peppered=await crypto.subtle.sign('HMAC',hmac,encoder.encode(password));
 const k=await crypto.subtle.importKey('raw',peppered,'PBKDF2',false,['deriveBits']);
 return b64(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:un64(salt),iterations:100000,hash:'SHA-256'},k,256)));
}
async function secureEqual(a,b){const A=encoder.encode(String(a)),B=encoder.encode(String(b));if(A.length!==B.length)return false;let n=0;for(let i=0;i<A.length;i++)n|=A[i]^B[i];return n===0;}
async function readBody(req){let text=await req.text();if(text.length>1050000)throw new Error('Request too large');return text?JSON.parse(text):{};}
const text=v=>String(v??'').trim();
async function rate(db,identifier){const id=await sha(identifier);const prior=await db.prepare('SELECT * FROM login_attempts WHERE id=?').bind(id).first();const early=prior&&Date.now()-Date.parse(prior.window_start)<5*60000;if(early&&prior.fails>=10)return false;return true;}
async function badLogin(db,identifier){const id=await sha(identifier),old=await db.prepare('SELECT * FROM login_attempts WHERE id=?').bind(id).first();if(old&&Date.now()-Date.parse(old.window_start)<5*60000)await db.prepare('UPDATE login_attempts SET fails=fails+1 WHERE id=?').bind(id).run();else await db.prepare('INSERT INTO login_attempts(id,window_start,fails) VALUES(?,?,1) ON CONFLICT(id) DO UPDATE SET window_start=excluded.window_start,fails=1').bind(id,now()).run();}
async function issue(db,{user_id=null,tenant_id=null,role}){const token=random();await db.prepare('INSERT INTO sessions VALUES(?,?,?,?,?)').bind(await sha(token),user_id,tenant_id,role,isoPlus(now(),role==='owner'?1:7)).run();return token;}
async function session(req,db){const m=/^Bearer\s+(.+)$/i.exec(req.headers.get('authorization')||'');if(!m)return null;const s=await db.prepare('SELECT * FROM sessions WHERE token_hash=? AND expires_at>?').bind(await sha(m[1]),now()).first();if(!s)return null;if(s.role==='owner')return s;
 if(s.role==='hr'){const hr=await db.prepare('SELECT active FROM ns_erp_hr_users WHERE id=? AND tenant_id=?').bind(s.user_id,s.tenant_id).first();return hr?.active?s:null;}const u=await db.prepare('SELECT active,role FROM users WHERE id=? AND tenant_id=?').bind(s.user_id,s.tenant_id).first();return u?.active&&u.role===s.role?s:null;}
const isActive=t=>t&&t.status==='active'&&Date.parse(t.expires_at)>Date.now();
async function tenant(db,id){return db.prepare('SELECT * FROM tenants WHERE id=?').bind(id).first();}
async function userCreate(db,tenantId,email,password,role,pepper){if(!['admin','rep'].includes(role)||!/^\S+@\S+\.\S+$/.test(email)||email.length>254||(password.length<12||password.length>128))throw Error('Email and strong 12+ character password required');let salt=b64(crypto.getRandomValues(new Uint8Array(16))),hash=await hashPassword(password,salt,pepper),id=crypto.randomUUID();await db.prepare('INSERT INTO users VALUES(?,?,?,?,?,?,1,?)').bind(id,tenantId,email,salt,hash,role,now()).run();return{id,email,role};}
async function loginIdentifierAvailable(db,username,email,exceptId=''){
 const u=text(username).toLowerCase(),e=text(email).toLowerCase();
 if(!/^[a-z0-9._-]{3,40}$/.test(u))return false;
 const r=await db.prepare('SELECT id FROM users WHERE id<>? AND (lower(username)=? OR lower(email)=? OR lower(username)=? OR lower(email)=?) LIMIT 1').bind(exceptId,u,u,e,e).first();
 const hr=await db.prepare('SELECT id FROM ns_erp_hr_users WHERE id<>? AND (lower(username)=? OR lower(email)=? OR lower(username)=? OR lower(email)=?) LIMIT 1').bind(exceptId,u,u,e,e).first();
 return !r&&!hr;
}
async function handle(req,env){if(req.method==='OPTIONS')return new Response(null,{status:204,headers});const url=new URL(req.url),path=url.pathname,db=env.DB;if(!db)return fail('D1 binding DB missing',503);
 if(path==='/v1/health')return json({ok:true,service:'NS POS PRO Cloud',time:now()});
 if(req.method==='POST'&&path==='/v1/owner/login'){
  const b=await readBody(req),key='owner:'+req.headers.get('cf-connecting-ip');if(!await rate(db,key))return fail('Too many login attempts',429);
  if(!env.OWNER_EMAIL||!env.OWNER_PASSWORD||env.OWNER_PASSWORD.length<12)return fail('Owner secrets not configured',503);
  if(!await secureEqual(text(b.email).toLowerCase(),env.OWNER_EMAIL.toLowerCase())||!await secureEqual(text(b.password),env.OWNER_PASSWORD)){await badLogin(db,key);return fail('Invalid credentials',401)}
  await db.prepare('DELETE FROM login_attempts WHERE id=?').bind(await sha(key)).run();return json({ok:true,role:'owner',token:await issue(db,{role:'owner'})});}
 if(req.method==='POST'&&path==='/v1/auth/login'){
  const b=await readBody(req),username=text(b.username||b.email).toLowerCase();
  if(!username||username.length>254)return fail('Invalid credentials',401);
  const key='account:'+req.headers.get('cf-connecting-ip')+':'+username;
  if(!await rate(db,key))return fail('Too many login attempts',429);
  // No business code is supplied by the app. Never choose an arbitrary tenant
  // when a login identifier occurs in more than one business.
  const matches=await db.prepare('SELECT * FROM users WHERE (lower(username)=? OR lower(email)=?) AND active=1 LIMIT 2').bind(username,username).all();
  if(matches.results.length!==1){
   if(matches.results.length>0){await badLogin(db,key);return fail('Invalid credentials or ambiguous username. Contact the administrator.',401)}
   const hr=await db.prepare('SELECT * FROM ns_erp_hr_users WHERE (lower(username)=? OR lower(email)=?) AND active=1 LIMIT 2').bind(username,username).all();
   if(hr.results.length!==1){await badLogin(db,key);return fail('Invalid credentials',401)}
   const h=hr.results[0];
   if(!await secureEqual(await hashPassword(text(b.password),h.password_salt,env.AUTH_PEPPER),h.password_hash)){await badLogin(db,key);return fail('Invalid credentials',401)}
   await db.prepare('DELETE FROM login_attempts WHERE id=?').bind(await sha(key)).run();
   const t=await tenant(db,h.tenant_id);
   return json({ok:true,token:await issue(db,{user_id:h.id,tenant_id:h.tenant_id,role:'hr'}),role:'hr',tenant:t,user:{id:h.id,email:h.email,username:h.username},licenseActive:isActive(t)});
  }
  const user=matches.results[0];
  if(!user||!await secureEqual(await hashPassword(text(b.password),user.password_salt,env.AUTH_PEPPER),user.password_hash)){await badLogin(db,key);return fail('Invalid username or password',401)}
  await db.prepare('DELETE FROM login_attempts WHERE id=?').bind(await sha(key)).run();const t=await tenant(db,user.tenant_id);return json({ok:true,token:await issue(db,{user_id:user.id,tenant_id:user.tenant_id,role:user.role}),role:user.role,tenant:t,user:{id:user.id,email:user.email,username:user.username||user.email},licenseActive:isActive(t)});}
 const s=await session(req,db);if(!s)return fail('Login required',401);const owner=s.role==='owner';
 // NS POS PRO v4.3: tenant-isolated remote design & seasonal effects.
 // Reuse VERIFIED original session. Never derive tenant ID or permissions from request body.
 const remote=await handleRemoteControl(req,env,{
  requireOwner:async()=>owner?{role:'owner'}:null,
  requireCustomer:async()=>!owner&&s.tenant_id?{tenantId:String(s.tenant_id),role:s.role}:null,
  businessExists:async(id)=>Boolean(await tenant(db,id))
 });
 if(remote)return remote;
 if(path==='/v1/auth/me'&&req.method==='GET'){const t=owner?null:await tenant(db,s.tenant_id);return json({ok:true,role:s.role,tenant:t,licenseActive:owner?true:isActive(t),user_id:s.user_id});}
 if(path==='/v1/auth/logout'&&req.method==='POST'){const token=req.headers.get('authorization').replace(/^Bearer\s+/i,'');await db.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await sha(token)).run();return json({ok:true});}

 // Secure cloud HR accounts: business Admin creates HR credentials (12+ character password).
 if(path==='/v1/admin/hr-users'&&req.method==='GET'){
  if(s.role!=='admin')return fail('Admin only',403);
  const rows=await db.prepare('SELECT id,username,email,active,created_at FROM ns_erp_hr_users WHERE tenant_id=? ORDER BY created_at DESC LIMIT 100').bind(s.tenant_id).all();
  return json({ok:true,users:rows.results});
 }
 if(path==='/v1/admin/hr-users'&&req.method==='POST'){
  if(s.role!=='admin')return fail('Admin only',403);
  const t=await tenant(db,s.tenant_id);if(!isActive(t))return fail('Subscription inactive',402);
  const b=await readBody(req),username=text(b.username).toLowerCase(),email=text(b.email).toLowerCase(),password=String(b.password??'');
  if(!/^[a-z0-9._-]{3,40}$/.test(username)||!/^\S+@\S+\.\S+$/.test(email)||email.length>254||password.length<12||password.length>128)return fail('Valid username/email and 12–128-character password required');
  if(!await loginIdentifierAvailable(db,username,email))return fail('Username or email already exists',409);
  const salt=b64(crypto.getRandomValues(new Uint8Array(16))),hash=await hashPassword(password,salt,env.AUTH_PEPPER),id=crypto.randomUUID();
  try{await db.prepare('INSERT INTO ns_erp_hr_users(id,tenant_id,username,email,password_salt,password_hash,created_at) VALUES(?,?,?,?,?,?,?)').bind(id,s.tenant_id,username,email,salt,hash,now()).run()}catch(e){return fail('Username/email already registered',409)}
  return json({ok:true,user:{id,username,email,role:'hr'}});
 }
 if(path==='/v1/admin/hr-users/status'&&req.method==='POST'){
  if(s.role!=='admin')return fail('Admin only',403);
  const b=await readBody(req),id=text(b.userId);if(typeof b.active!=='boolean')return fail('Boolean active required');
  const result=await db.prepare('UPDATE ns_erp_hr_users SET active=? WHERE tenant_id=? AND id=?').bind(b.active?1:0,s.tenant_id,id).run();if(!result.meta.changes)return fail('HR user not found',404);
  if(!b.active)await db.prepare('DELETE FROM sessions WHERE user_id=? AND tenant_id=?').bind(id,s.tenant_id).run();
  return json({ok:true});
 }
 const erpResponse=await handleERP(req,env,s);if(erpResponse)return erpResponse;


 // Owner-only branding updates. Business users may READ ONLY their own tenant.
 // An independent table avoids mutating existing tenants schema or passwords.
 if(path==='/v1/owner/branding'&&req.method==='GET'){
  if(!owner)return fail('Owner only',403);
  const code=text(url.searchParams.get('businessCode')).toUpperCase();
  if(!/^[A-Z0-9_-]{4,40}$/.test(code))return fail('Invalid business code',400);
  if(!await tenant(db,code))return fail('Business not found',404);
  const branding=await db.prepare('SELECT phone,logo_data,updated_at FROM tenant_branding WHERE tenant_id=?').bind(code).first();
  return json({ok:true,businessCode:code,branding:branding||{phone:'',logo_data:'',updated_at:null}});
 }
 if(path==='/v1/owner/branding'&&req.method==='POST'){
  if(!owner)return fail('Owner only',403);
  const b=await readBody(req),code=text(b.businessCode).toUpperCase();
  if(!/^[A-Z0-9_-]{4,40}$/.test(code))return fail('Invalid business code',400);
  if(!await tenant(db,code))return fail('Business not found',404);
  const phone=text(b.phone);
  if(phone.length>28||!/^[-+() 0-9]{0,28}$/.test(phone))return fail('Invalid business phone number',400);
  // Images are resized by the owner app to <= 120KB. Never accept SVG/HTML.
  const old=await db.prepare('SELECT logo_data FROM tenant_branding WHERE tenant_id=?').bind(code).first();
  let logo=old?.logo_data||'';
  if(b.removeLogo===true)logo='';
  else if(Object.hasOwn(b,'logoData')){
   const data=String(b.logoData??'');
   if(data && (data.length>175000||!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(data)))return fail('Logo must be a compressed JPEG/PNG/WebP (max 120KB)',400);
   if(data){
    let bytes;
    try{bytes=atob(data.slice(data.indexOf(',')+1));}catch(_){return fail('Invalid logo encoding',400)}
    const kind=data.slice(5,data.indexOf(';'));
    const jpeg=kind==='image/jpeg'&&bytes.charCodeAt(0)===255&&bytes.charCodeAt(1)===216&&bytes.charCodeAt(2)===255;
    const png=kind==='image/png'&&bytes.slice(0,8)==='\x89PNG\r\n\x1a\n';
    const webp=kind==='image/webp'&&bytes.slice(0,4)==='RIFF'&&bytes.slice(8,12)==='WEBP';
    if(!(jpeg||png||webp)||bytes.length>125000)return fail('Invalid or oversized logo image',400);
   }
   logo=data;
  }
  const time=now();
  await db.prepare(`INSERT INTO tenant_branding(tenant_id,phone,logo_data,updated_at) VALUES(?,?,?,?)
    ON CONFLICT(tenant_id) DO UPDATE SET phone=excluded.phone,logo_data=excluded.logo_data,updated_at=excluded.updated_at`)
    .bind(code,phone,logo,time).run();
  // Audit without collecting any customer credentials or images.
  await db.prepare('INSERT INTO tenant_branding_audit(id,tenant_id,changed_at,changed_fields) VALUES(?,?,?,?)')
    .bind(crypto.randomUUID(),code,time,JSON.stringify({phone:true,logo:b.removeLogo===true||Object.hasOwn(b,'logoData')})).run();
  return json({ok:true,businessCode:code,updatedAt:time});
 }
 if(path==='/v1/business/branding'&&req.method==='GET'){
  if(owner)return fail('Business account required',403);
  if(!s.tenant_id)return fail('Business account required',403);
  const brand=await db.prepare('SELECT phone,logo_data,updated_at FROM tenant_branding WHERE tenant_id=?').bind(s.tenant_id).first();
  return json({ok:true,businessCode:s.tenant_id,branding:brand||{phone:'',logo_data:'',updated_at:null}});
 }
 if(path==='/v1/owner/tenants'&&req.method==='GET'){if(!owner)return fail('Owner only',403);const r=await db.prepare('SELECT * FROM tenants ORDER BY created_at DESC LIMIT 500').all();return json({ok:true,tenants:r.results});}
 if(path==='/v1/owner/tenants'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req),id=text(b.businessCode).toUpperCase();if(!/^[A-Z0-9_-]{4,40}$/.test(id)||!text(b.name))return fail('Business code (4–40 A-Z/0-9/_/-) and name required');await db.prepare('INSERT INTO tenants VALUES(?,?,1000,?,?,?)').bind(id,text(b.name),isoPlus(now(),30),'active',now()).run();return json({ok:true,tenant:await tenant(db,id)});}
 if(path==='/v1/owner/set-fee'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req),fee=Number(b.feeLkr);if(!Number.isSafeInteger(fee)||fee<0||fee>1000000)return fail('Fee must be Rs. 0 to 1,000,000');const r=await db.prepare('UPDATE tenants SET fee_lkr=? WHERE id=?').bind(fee,text(b.businessCode)).run();if(!r.meta.changes)return fail('Unknown business',404);return json({ok:true,feeLkr:fee});}
 if(path==='/v1/owner/set-status'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req);if(!['active','blocked'].includes(b.status))return fail('Invalid status');const r=await db.prepare('UPDATE tenants SET status=? WHERE id=?').bind(b.status,text(b.businessCode)).run();if(!r.meta.changes)return fail('Unknown business',404);if(b.status==='blocked')await db.prepare('DELETE FROM sessions WHERE tenant_id=?').bind(text(b.businessCode)).run();return json({ok:true});}
 if(path==='/v1/owner/users'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req);if(!await tenant(db,text(b.businessCode)))return fail('Unknown business',404);if(!await loginIdentifierAvailable(db,b.username,b.email))return fail('Username required and must be unique across businesses (also cannot match another email)',409);const created=await userCreate(db,text(b.businessCode),text(b.email).toLowerCase(),text(b.password),b.role,env.AUTH_PEPPER);if(b.username){const un=text(b.username).toLowerCase();await db.prepare('UPDATE users SET username=? WHERE id=?').bind(un,created.id).run()}return json({ok:true,user:created});}
 if(path==='/v1/owner/user-list'&&req.method==='GET'){if(!owner)return fail('Owner only',403);const code=text(url.searchParams.get('businessCode'));if(!code)return fail('Business code required');const r=await db.prepare('SELECT id,email,username,role,active,created_at FROM users WHERE tenant_id=? ORDER BY created_at DESC LIMIT 500').bind(code).all();return json({ok:true,users:r.results});}
 if(path==='/v1/owner/user-update'&&req.method==='POST'){
  if(!owner)return fail('Owner only',403);const b=await readBody(req),id=text(b.userId),u=await db.prepare('SELECT * FROM users WHERE id=?').bind(id).first();if(!u)return fail('User not found',404);
  if(b.action==='set-username'){const un=text(b.username).toLowerCase();if(!await loginIdentifierAvailable(db,un,u.email,id))return fail('Username already used or invalid',409);await db.prepare('UPDATE users SET username=? WHERE id=?').bind(un,id).run();}
  else if(b.action==='set-email'){const email=text(b.email).toLowerCase();if(email.length>254||!/^\S+@\S+\.\S+$/.test(email))return fail('Invalid email');await db.prepare('UPDATE users SET email=? WHERE id=?').bind(email,id).run();}
  else if(b.action==='reset-password'){const password=String(b.password??'');if(password.length<12||password.length>128)return fail('Password must be 12–128 characters');const salt=b64(crypto.getRandomValues(new Uint8Array(16))),hash=await hashPassword(password,salt,env.AUTH_PEPPER);await db.prepare('UPDATE users SET password_salt=?,password_hash=? WHERE id=?').bind(salt,hash,id).run();}
  else if(b.action==='disable'||b.action==='enable'){await db.prepare('UPDATE users SET active=? WHERE id=?').bind(b.action==='enable'?1:0,id).run();}
  else if(b.action==='remove'){await db.prepare('UPDATE users SET active=0 WHERE id=?').bind(id).run();}
  else if(b.action==='logout-devices'){/* session invalidation below */}
  else return fail('Unknown action');
  await db.prepare('DELETE FROM sessions WHERE user_id=?').bind(id).run();return json({ok:true,action:b.action});}
 if(path==='/v1/owner/logout-business'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req);await db.prepare('DELETE FROM sessions WHERE tenant_id=?').bind(text(b.businessCode)).run();return json({ok:true});}
 if(path==='/v1/admin/users'&&req.method==='POST'){if(s.role!=='admin')return fail('Business Admin only',403);const t=await tenant(db,s.tenant_id);if(!isActive(t))return fail('Subscription inactive',402);const b=await readBody(req);if(b.role!=='rep')return fail('Business Admin can only create Reps',403);if(!await loginIdentifierAvailable(db,b.username,b.email))return fail('Username required and must be unique across businesses (also cannot match another email)',409);const created=await userCreate(db,s.tenant_id,text(b.email).toLowerCase(),text(b.password),'rep',env.AUTH_PEPPER);if(b.username){const un=text(b.username).toLowerCase();await db.prepare('UPDATE users SET username=? WHERE id=?').bind(un,created.id).run()}return json({ok:true,user:created});}
 if(path==='/v1/payment/request'&&req.method==='POST'){if(owner)return fail('Customer only',403);const b=await readBody(req),proof=text(b.slipData),reference=text(b.reference);if(proof.length>480000||proof&&!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(proof))return fail('Slip must be a small JPG/PNG/WebP (under 350KB)');if(!reference&&!proof)return fail('Payment reference or slip required');await db.prepare('INSERT INTO payment_requests(id,tenant_id,user_id,reference,amount_lkr,slip_data,status,submitted_at) VALUES(?,?,?,?,?,?,?,?)').bind(crypto.randomUUID(),s.tenant_id,s.user_id,reference,(await tenant(db,s.tenant_id))?.fee_lkr??1000,proof||null,'pending',now()).run();return json({ok:true,status:'pending'});}
 if(path==='/v1/owner/payments'&&req.method==='GET'){if(!owner)return fail('Owner only',403);const r=await db.prepare('SELECT id,tenant_id,reference,amount_lkr,status,submitted_at,reviewed_at,reviewed_note,CASE WHEN slip_data IS NOT NULL THEN 1 ELSE 0 END has_slip FROM payment_requests ORDER BY submitted_at DESC LIMIT 200').all();return json({ok:true,payments:r.results});}
 if(path==='/v1/owner/slip'&&req.method==='GET'){if(!owner)return fail('Owner only',403);const p=await db.prepare('SELECT slip_data FROM payment_requests WHERE id=?').bind(url.searchParams.get('id')).first();if(!p)return fail('Not found',404);return json({ok:true,slipData:p.slip_data});}
 if(path==='/v1/owner/payment-decision'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req);if(!['approved','rejected'].includes(b.decision))return fail('Decision required');const p=await db.prepare('SELECT * FROM payment_requests WHERE id=?').bind(text(b.id)).first();if(!p||p.status!=='pending')return fail('Pending payment not found',409);
  if(b.decision==='approved'){
   const t=await tenant(db,p.tenant_id);if(!t)return fail('Business not found',404);
   const expires=isoPlus(Math.max(Date.now(),Date.parse(t.expires_at)),30); // updated in one D1 batch; enforce conditional pending status
   const changes=await db.batch([db.prepare('UPDATE payment_requests SET status=?,reviewed_at=?,reviewed_note=? WHERE id=? AND status=?').bind('approved',now(),text(b.note),p.id,'pending'),db.prepare('UPDATE tenants SET expires_at=?,status=? WHERE id=? AND EXISTS (SELECT 1 FROM payment_requests WHERE id=? AND status=?)').bind(expires,'active',p.tenant_id,p.id,'approved')]);
   if(changes[0].meta.changes!==1)return fail('Already decided',409);return json({ok:true,expiresAt:expires});
  }
  await db.prepare('UPDATE payment_requests SET status=?,reviewed_at=?,reviewed_note=? WHERE id=? AND status=?').bind('rejected',now(),text(b.note),p.id,'pending').run();return json({ok:true});}
 // Desktop pilot controls: exact trial duration replaces expiry; no new tenant table.
 if(path==='/v1/owner/start-trial'&&req.method==='POST'){
  if(!owner)return fail('Owner only',403);
  const b=await readBody(req),id=text(b.businessCode).toUpperCase(),days=Number(b.days);
  if(!/^[A-Z0-9_-]{4,40}$/.test(id)||!Number.isInteger(days)||days<1||days>90)return fail('Trial must be 1-90 days',400);
  if(!await tenant(db,id))return fail('Business not found',404);
  const expires=isoPlus(now(),days);
  await db.batch([
   db.prepare('UPDATE tenants SET expires_at=?,status=? WHERE id=?').bind(expires,'active',id),
   db.prepare('DELETE FROM sessions WHERE tenant_id=?').bind(id)
  ]);
  return json({ok:true,businessCode:id,expiresAt:expires,status:'active',note:'All business sessions must re-login'});
 }
 if(path==='/v1/owner/set-expiry'&&req.method==='POST'){
  if(!owner)return fail('Owner only',403);
  const b=await readBody(req),id=text(b.businessCode).toUpperCase(),date=text(b.date);
  if(!/^[A-Z0-9_-]{4,40}$/.test(id)||!/^\d{4}-\d{2}-\d{2}$/.test(date))return fail('YYYY-MM-DD date required',400);
  // Sri Lanka business-local end of day, in UTC-05:30 offset notation (+05:30).
  const expires=new Date(date+'T23:59:59.999+05:30');
  if(!Number.isFinite(+expires)||new Date(+expires+19800000).toISOString().slice(0,10)!==date)return fail('Invalid date',400);
  if(+expires>Date.now()+3*365*86400000 || +expires<Date.now()-365*86400000)return fail('Date must be within supported range',400);
  const result=await db.prepare('UPDATE tenants SET expires_at=? WHERE id=?').bind(expires.toISOString(),id).run();
  if(!result.meta.changes)return fail('Business not found',404);
  return json({ok:true,businessCode:id,expiresAt:expires.toISOString()});
 }
 if(path==='/v1/owner/extend'&&req.method==='POST'){if(!owner)return fail('Owner only',403);const b=await readBody(req),t=await tenant(db,text(b.businessCode));if(!t)return fail('Unknown business',404);const n=Number(b.days);if(!Number.isInteger(n)||n<1||n>365)return fail('Invalid days');const exp=isoPlus(Math.max(Date.now(),Date.parse(t.expires_at)),n);await db.prepare('UPDATE tenants SET expires_at=?,status=? WHERE id=?').bind(exp,'active',t.id).run();return json({ok:true,expiresAt:exp});}
 if(path==='/v1/sync/push'&&req.method==='POST'){
  if(owner||s.role==='hr')return fail('POS staff only',403);const t=await tenant(db,s.tenant_id);if(!isActive(t))return fail('Subscription inactive',402);
  const b=await readBody(req),dev=text(b.deviceId),revision=Number(b.revision),payload=JSON.stringify(b.snapshot||{});if(!/^[a-z0-9-]{8,100}$/i.test(dev)||!Number.isSafeInteger(revision)||revision<1||payload.length>880000)return fail('Invalid snapshot or too large');
  const old=await db.prepare('SELECT revision FROM device_snapshots WHERE tenant_id=? AND user_id=? AND device_id=?').bind(s.tenant_id,s.user_id,dev).first();if(old&&old.revision>revision)return fail('Older revision',409);
  await db.prepare('INSERT INTO device_snapshots(tenant_id,user_id,device_id,revision,payload,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(tenant_id,user_id,device_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload,updated_at=excluded.updated_at WHERE excluded.revision>=device_snapshots.revision').bind(s.tenant_id,s.user_id,dev,revision,payload,now()).run();return json({ok:true,revision});}
 if(path==='/v1/sync/reports'&&req.method==='GET'){
  if(owner)return fail('Customer only',403);if(s.role!=='admin')return fail('Admin only',403);
  const t=await tenant(db,s.tenant_id);if(!isActive(t))return fail('Subscription inactive',402);
  const rows=await db.prepare('SELECT ds.user_id,ds.device_id,ds.updated_at,ds.revision,ds.payload,u.email FROM device_snapshots ds JOIN users u ON u.id=ds.user_id WHERE ds.tenant_id=? ORDER BY ds.updated_at DESC LIMIT 60').bind(s.tenant_id).all();return json({ok:true,devices:rows.results.map(r=>({...r,payload:JSON.parse(r.payload)}))});}
 return fail('Route not found',404);
}
export default {async fetch(req,env){try{return await handle(req,env)}catch(e){console.error('NS cloud error',e?.message);if(e?.message?.includes('UNIQUE constraint'))return fail('Business or account already exists',409);if(e instanceof SyntaxError)return fail('Invalid JSON',400);return fail('Request could not be completed',500)}}};
