/* NS POS PRO ERP server routes: role-scoped, tenant-isolated, revision-safe.
 * No owner endpoint ever reads employee salary records in this addon.
 */
const apiHeaders={'content-type':'application/json; charset=utf-8','cache-control':'no-store','access-control-allow-origin':'*'};
const respond=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:apiHeaders});
const invalid=(message,status=400)=>respond({ok:false,error:message},status);
const types=['employees','attendance','payroll','entries','config'];
const isMoney=n=>typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=1e11;
const allowedKeys={employees:['id','empNo','name','department','designation','phone','joinDate','basic','allowance','epfBase','active'],attendance:['id','employeeId','date','workedHours','otHours','createdAt','updatedAt'],payroll:['id','employeeId','employeeNo','employeeName','department','period','base','allowance','otHours','otPay','gross','epfBase','employeeEPF','employerEPF','employerETF','advance','apit','otherDeduct','net','employerCost','createdAt','createdBy','voidedAt','voidReason'],entries:['id','date','type','category','payment','description','amount','createdAt','voidedAt','voidReason'],config:['epfEmployee','epfEmployer','etfEmployer','otMultiplier','hourDivisor']};
const str=v=>String(v??'').trim();
const date=s=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s+'T00:00:00Z'));
const month=s=>/^\d{4}-(0[1-9]|1[0-2])$/.test(s);
function validate(kind,id,raw){
 if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid ERP payload');
 const p={}; for(const k of allowedKeys[kind])if(Object.prototype.hasOwnProperty.call(raw,k))p[k]=raw[k];
 const no=(v,max)=>typeof v==='string'&&v.length<=max;
 const nr=(k)=>isMoney(p[k]);
 if(kind!=='config'&&(!no(p.id,90)||p.id!==id))throw Error('Record ID invalid');
 if(kind==='employees'&&(!no(p.empNo,35)||!p.empNo||!no(p.name,100)||!p.name||!nr('basic')||!nr('allowance')||(p.epfBase!=null&&!nr('epfBase'))||!no(p.phone||'',30)))throw Error('Invalid employee');
 if(kind==='attendance'&&(!no(p.employeeId,90)||!date(p.date)||!nr('workedHours')||p.workedHours>24||!nr('otHours')||p.otHours>24))throw Error('Invalid attendance');
 if(kind==='payroll'&&(!no(p.employeeId,90)||!month(p.period)||!nr('employerCost')||!nr('net')||!nr('gross')||!nr('employeeEPF')||!nr('employerEPF')||!nr('employerETF')||!nr('otPay')))throw Error('Invalid payroll');
 if(kind==='entries'&&(!date(p.date)||!['income','expense'].includes(p.type)||!nr('amount')||!p.amount||!no(p.description,160)))throw Error('Invalid cashbook entry');
 if(kind==='config'&&(!nr('epfEmployee')||p.epfEmployee>100||!nr('epfEmployer')||p.epfEmployer>100||!nr('etfEmployer')||p.etfEmployer>100||!nr('otMultiplier')||p.otMultiplier<1||p.otMultiplier>5||!nr('hourDivisor')||p.hourDivisor<1||p.hourDivisor>744))throw Error('Invalid payroll config');
 for(const [k,v] of Object.entries(p))if(typeof v==='string'&&v.length>250)throw Error('Text field too long');
 return p;
}
function keyOf(kind,p,id){
 if(kind==='config')return 'settings';
 if(kind==='employees')return String(p.empNo).trim().toLowerCase();
 if(kind==='attendance')return p.employeeId+'|'+p.date;
 if(kind==='payroll')return p.employeeId+'|'+p.period+(p.voidedAt?'|void:'+id:'');
 return id;
}
async function audit(db,t,actor,action,target){await db.prepare('INSERT INTO ns_erp_audit VALUES(?,?,?,?,?,?)').bind(crypto.randomUUID(),t,actor,action,target,new Date().toISOString()).run()}
async function readBody(req){const raw=await req.text();if(raw.length>16000)throw Error('ERP payload too large');return JSON.parse(raw||'{}')}
function scope(kind,role,write){if(role==='admin')return true;if(role==='hr')return ['employees','attendance','payroll'].includes(kind)||(kind==='config'&&!write);return false}
async function records(req,env,user,url){const db=env.DB,kind=url.searchParams.get('kind');if(!types.includes(kind)||!scope(kind,user.role,req.method!=='GET'))return invalid('ERP permission denied',403);
 if(req.method==='GET'){
  const result=await db.prepare('SELECT id,payload,revision,updated_at FROM ns_erp_records WHERE tenant_id=? AND kind=? ORDER BY updated_at DESC LIMIT 1501').bind(user.tenant_id,kind).all();
  if(result.results.length>1500)return invalid('Over 1500 records; paging required before editing',413);
  return respond({ok:true,kind,records:result.results.map(r=>({id:r.id,value:JSON.parse(r.payload),revision:r.revision,updatedAt:r.updated_at}))});
 }
 if(req.method!=='PUT')return invalid('Method not allowed',405);
 const b=await readBody(req),id=str(b.id),revision=Number(b.expectedRevision);if(!/^[-a-zA-Z0-9_:]{1,90}$/.test(id)||!Number.isSafeInteger(revision)||revision<0)return invalid('Invalid record ID or revision');
 if(kind==='config'&&(user.role!=='admin'||id!=='singleton'))return invalid('Admin required',403);
 let p;try{p=validate(kind,id,b.value)}catch(e){return invalid(e.message)}
 const raw=JSON.stringify(p);if(raw.length>8500)return invalid('Record exceeds limit');
 const key=keyOf(kind,p,id),at=new Date().toISOString(),actor=user.user_id;
 try{
  let result;
  if(revision===0)result=await db.prepare('INSERT OR IGNORE INTO ns_erp_records(tenant_id,kind,id,natural_key,payload,revision,updated_at,updated_by) VALUES(?,?,?,?,?,1,?,?)').bind(user.tenant_id,kind,id,key,raw,at,actor).run();
  else result=await db.prepare('UPDATE ns_erp_records SET payload=?,natural_key=?,revision=revision+1,updated_at=?,updated_by=? WHERE tenant_id=? AND kind=? AND id=? AND revision=?').bind(raw,key,at,actor,user.tenant_id,kind,id,revision).run();
  if(!result.meta.changes)return invalid('Record changed on another device. Reload and reconcile; nothing was overwritten.',409);
  await audit(db,user.tenant_id,actor,revision===0?'create':'edit',kind+':'+id);
  return respond({ok:true,id,revision:revision+1});
 }catch(e){if(/UNIQUE constraint/i.test(e.message))return invalid('Duplicate employee ID or monthly payroll record',409);throw e}
}
async function sales(req,env,user){if(req.method!=='PUT')return invalid('Method not allowed',405);if(!['admin','rep'].includes(user.role))return invalid('POS staff only',403);
 const b=await readBody(req);if(!Array.isArray(b.invoices)||b.invoices.length>50)return invalid('Maximum 50 invoices at a time');
 const source=str(b.deviceId);if(!/^[a-z0-9-]{8,100}$/i.test(source))return invalid('Invalid device ID');
 const db=env.DB,at=new Date().toISOString();let sent=0,conflicts=[];
 for(const item of b.invoices){const id=str(item.id),branch=str(item.branch).slice(0,65),soldAt=str(item.date),x=Number(item.salesExTax),cost=Number(item.cost),tax=Number(item.tax);
  if(!/^[-a-zA-Z0-9_:]{1,90}$/.test(id)||!branch||!(date(soldAt.slice(0,10)))||!Number.isFinite(Date.parse(soldAt))||![x,cost,tax].every(isMoney)||!Number.isInteger(item.costUnknown)||item.costUnknown<0||item.costUnknown>500)return invalid('Invalid invoice summary');
  const old=await db.prepare('SELECT source_device FROM ns_erp_sales WHERE tenant_id=? AND invoice_id=?').bind(user.tenant_id,id).first();if(old&&old.source_device!==source){conflicts.push(id);continue}
  const r=await db.prepare('INSERT INTO ns_erp_sales(tenant_id,invoice_id,source_device,branch,sold_at,sales_ex_tax,cost,cost_unknown,tax,voided,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,invoice_id) DO UPDATE SET branch=excluded.branch,sold_at=excluded.sold_at,sales_ex_tax=excluded.sales_ex_tax,cost=excluded.cost,cost_unknown=excluded.cost_unknown,tax=excluded.tax,voided=excluded.voided,updated_at=excluded.updated_at WHERE ns_erp_sales.source_device=excluded.source_device').bind(user.tenant_id,id,source,branch,soldAt,x,cost,item.costUnknown,tax,item.voided===true?1:0,at).run();if(!r.meta.changes){conflicts.push(id);continue;}sent+=r.meta.changes||0;
 }
 return respond({ok:conflicts.length===0,sent,conflicts});
}
async function profit(req,env,user,url){if(user.role!=='admin')return invalid('Admin required',403);const period=url.searchParams.get('period')||'month',anchor=url.searchParams.get('date')||new Date().toISOString().slice(0,10);
 if(!['day','month','year'].includes(period)||!date(anchor))return invalid('Invalid period/date');
 const cond=period==='day'?anchor:period==='month'?anchor.slice(0,7):anchor.slice(0,4);
 const sriLanka="datetime(sold_at, '+330 minutes')";const fmt=period==='day'?`substr(${sriLanka},1,10)`:period==='month'?`substr(${sriLanka},1,7)`:`substr(${sriLanka},1,4)`;
 const rows=await env.DB.prepare(`SELECT branch, COUNT(*) invoices, SUM(sales_ex_tax) sales, SUM(cost) cogs, SUM(cost_unknown) unknown, SUM(tax) tax FROM ns_erp_sales WHERE tenant_id=? AND voided=0 AND ${fmt}=? GROUP BY branch ORDER BY branch`).bind(user.tenant_id,cond).all();
 const docs=await env.DB.prepare('SELECT kind,payload FROM ns_erp_records WHERE tenant_id=? AND kind IN (?,?) LIMIT 1501').bind(user.tenant_id,'entries','payroll').all();if(docs.results.length>1500)return invalid('ERP records exceed profit report limit',413);
 let income=0,expenses=0,payroll=0;for(const r of docs.results){const p=JSON.parse(r.payload);if(p.voidedAt)continue;const d=r.kind==='entries'?p.date:p.period+'-01';if(d.slice(0,cond.length)!==cond)continue;
  if(r.kind==='payroll')payroll+=Number(p.employerCost)||0;else if(p.type==='income')income+=Number(p.amount)||0;else if(p.type==='expense')expenses+=Number(p.amount)||0}
 const branches=rows.results.map(x=>({branch:x.branch,invoices:x.invoices,sales:Number(x.sales)||0,cogs:Number(x.cogs)||0,unknown:Number(x.unknown)||0,tax:Number(x.tax)||0}));
 const total=branches.reduce((x,v)=>({sales:x.sales+v.sales,cogs:x.cogs+v.cogs,unknown:x.unknown+v.unknown,invoices:x.invoices+v.invoices,tax:x.tax+v.tax}),{sales:0,cogs:0,unknown:0,invoices:0,tax:0});
 return respond({ok:true,period,date:anchor,branches,total:{...total,otherIncome:income,expenses,payroll,net:total.unknown?null:total.sales-total.cogs+income-expenses-payroll},source:'Sri Lanka local-date reporting. Cloud-acknowledged invoice summaries only. Returns adjust original sale periods. Missing/offline records and payroll allocations can make totals incomplete. Not a certified accounting report.'});
}
export async function handleERP(req,env,user){const url=new URL(req.url),path=url.pathname;
 if(!path.startsWith('/v1/erp/'))return null;
 if(!user||user.role==='owner')return invalid('Business login required',403);
 const tenant=await env.DB.prepare('SELECT status,expires_at FROM tenants WHERE id=?').bind(user.tenant_id).first();if(!tenant||tenant.status!=='active'||Date.parse(tenant.expires_at)<=Date.now())return invalid('Subscription inactive',402);
 try{
  if(path==='/v1/erp/records')return await records(req,env,user,url);
  if(path==='/v1/erp/sales')return await sales(req,env,user);
  if(path==='/v1/erp/profit')return await profit(req,env,user,url);
  return invalid('ERP route not found',404);
 }catch(e){console.error('ERP route error',e?.message);return invalid(e instanceof SyntaxError?'Invalid JSON':'ERP request failed',e instanceof SyntaxError?400:500)}
}
