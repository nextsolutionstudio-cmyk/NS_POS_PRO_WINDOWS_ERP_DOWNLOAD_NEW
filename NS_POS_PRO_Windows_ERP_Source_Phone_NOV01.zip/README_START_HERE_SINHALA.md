# NS POS PRO Desktop v4.7 · Windows Trial-Controlled Edition

## 1. මෙහි අඩංගු දේ
- Original NS POS PRO Customer v4.5.1 assets (Billing, GRN, Stock, HR, Accounts, Payroll, Profit, Cloud ERP).
- Windows-friendly Desktop UI: blue left sidebar, broad dashboard, business header, HR / Payroll / Profit shortcut links.
- Electron Windows installer (NSIS) + portable EXE **build source/workflow**. **මෙම ZIP එක compiled EXE එකක් නොවේ.**
- Cloudflare Developer Owner Worker: trial start 1–90 days, exact expiry, existing block/unblock/extend.
- Windows printing: use Default Windows Printer when Print Bill clicked, fall back to print dialog if needed. Requires driver / printer setup. Windows is NOT Android Classic Bluetooth native printer bridge.
- Online-only company trial: verifies current company status every **30 seconds** and when app regains focus. Block / expired / lost Internet -> locks app at next check. User data is retained, not deleted.
- One Windows OS profile is bound to one business after first successful sign-in; this avoids accidentally exposing local invoice data to another company. For a different company use a separate Windows profile or authorized data migration/backup.

## 2. Windows EXE එක GitHub එකෙන් Build කරන හැටි
1. මේ ZIP එක Extract කරන්න.
2. Extract කරපු root එකේ **`.github`, `app`, `desktop`, `Cloudflare_Server`, `package.json`, `tests`** ඇතුළු files අලුත් GitHub Repository එකකට upload කරන්න. (Hidden `.github` folder අනිවාර්යයි.)
3. GitHub -> Actions -> **Build NS POS PRO Windows EXE** -> **Run workflow**.
4. Build සාර්ථක වුණාම `NS-POS-PRO-Windows-EXE` artifact එක download කර extract කරන්න.
5. `NS-POS-PRO-Desktop-Setup-...exe` install කිරීමටත්, `NS-POS-PRO-Desktop-Portable-...exe` portable version එකටත් තියෙනවා.
6. **Trial company එකට EXE පමණක් දෙන්න.** Cloudflare_Server folder, secrets, Developer Owner password, GitHub source public කරන්න එපා.

ඔයාගේ PC එකේ Node.js 22+ තියෙනවා නම් project root එකේ `npm install`, `npm start` කරලා test කරන්න පුළුවන්; Windows build සඳහා `npm run dist:win`.

## 3. Cloudflare Developer Owner Trial Setup (අත්‍යවශ්‍යයි)
**Existing Cloudflare D1 database backup කරන්න, පසුව deployment එක update කරන්න.**
1. `Cloudflare_Server/` folder එකේ source එක ඔයාගේ existing Worker repo එකට ගැළපෙන විදිහට deploy කරන්න. Existing Worker URL එක: `https://ns-pos-pro-cloud.nextsolutionstudio.workers.dev` (එය වෙනස් නම් `desktop/main.cjs` සහ `app/cloud_client.js` වල URL එක දෙකම update කර build කරන්න).
2. ඔයා දැනට v4.5 D1 migration apply කරලා නැත්නම්, `migrations/0005_erp.sql` ඇතුළු unapplied migrations apply කරන්න. **දැනට production DB එක reset කරන්න එපා.** අලුත් Windows trial endpoints සඳහා අමතර migration එකක් අවශ්‍ය නැහැ.
3. Update කළ `Cloudflare_Server/owner_portal.html` එක private Owner Portal එකක් විදිහට HTTPS යටතේ host කරන්න. Existing Owner App එකේ Trial buttons ස්වයංක්‍රීයව පෙනෙන්නේ නැහැ; ඒ UI එකත් owner app එකට update කරන්න හෝ මේ portal එක භාවිත කරන්න. සෑම action එකක්ම Owner token backend එකෙන් verify කරනවා.
4. Owner Login -> New Business -> Create Admin account (username, email, password min 12 chars).
5. Businesses & Subscriptions -> **3-Day Trial**, **7-Day Trial**, **14-Day Trial**, or **Set Expiry** තෝරන්න. Trial reset එක current expiry replace කර all business sessions logout කරනවා. New login අවශ්‍ය වෙනවා.
6. Business username/password Windows app එකට ඇතුළත් කර company එකෙන් test කරන්න.
7. **Block** කළොත් server-side sessions revoke වෙනවා. Windows app එක ආසන්න වශයෙන් 30 seconds ඇතුළත හෝ නැවත window එකට focus කළ විට lock වෙනවා (network failures also lock). **Unblock** පසු user ආයෙ login කළ යුතුයි; expiry dateත් valid විය යුතුයි.

## 4. Windows Auto Printer (v4.7)
- XP-P301A: 58mm or 80mm paper. In Settings → Auto Printer Manager set the actual installed roll width ONCE.
- XP-P502A: 58mm fixed. XP-80T: 80mm fixed. XP-P302A 58mm alias included for certain earlier printer installations.
- USB printer: install manufacturer's Windows driver, make sure it is listed under Windows Settings → Printers & scanners, then run Test Print.
- Bluetooth printer: pair it AND install a supported Windows print driver/port so the device appears as a Windows printer. Pairing a COM-only Bluetooth serial port does NOT establish a Windows print queue and this build does not send direct serial COM raw jobs.
- Auto pick order: last printer that successfully accepted a print job; otherwise Windows default (if reported); otherwise first recognized Xprinter that Windows does not explicitly report as offline. Ignore PDF/OneNote/XPS devices.
- Print Bill / Reprint and Test Print now use a shared 58mm/80mm page renderer and the Windows spooler. Exactly ONE job goes to ONE printer; no automatic retransmission on unknown failures (avoids duplicate receipts).
- Printer connection / paper availability cannot be guaranteed by the OS/driver. A successful callback confirms spooler acceptance, not physical printing. If the Windows driver silently queues to a disconnected printer, fix its queue/pairing and run Test Print.
- Drivers can reject nonstandard continuous paper lengths. If you get “Invalid printer settings”, configure the driver's roll width/receipt mode correctly in Windows Printing Preferences, then retry the Test Print. Don't use Windows default A4 paper settings for the thermal driver.
- Settings → Auto Printer Manager → Check Connections shows installed supported models and the auto-selected printer; 58/80mm paper profiles are shown in this view, not selected during billing.
- DO NOT give the company Worker source, Developer Owner credentials, or the full project archive.

## 5. Data / Safety / Trial Limits
- **Windows App installer හෝ live Cloudflare deployment මෙහි build/test කර නැහැ.** JavaScript syntax සහ automated checks පමණයි සමත් කරලා තියෙන්නේ.
- Dashboard/HR/Accounts originals තවම prototype/local storage aspects තියෙනවා; Cloud ERP sync can require explicit authorization. Multiple counters may not have authoritative stock merge. This is **not audited accounting or payroll software**.
- Windows trial deliberately **requires Internet**; network outage locks the interface, so real shops shouldn't depend on this trial for continuous checkout. Prepare a fallback billing method.
- Native process checks the license, but **no locally distributed EXE is impossible to reverse engineer / bypass**. For strong enforcement, production data actions must remain server-authorized. Do not distribute Worker/Owner secrets.
- Before company trial: back up invoices/stock and D1; don't enter real staff NIC, salaries, tax details until security/compliance review. Do not uninstall earlier Android version or delete its data.
- **Windows application doesn't automatically inherit old Android browser-local data.** Cloud ERP records require login/sync; local Android billing history is not automatically copied to Windows.
- Unsigned Windows EXE can show SmartScreen warning. Use reputable code-signing certificate for public/commercial releases.

## Tests
- `npm run check` for desktop license tests.
- `cd Cloudflare_Server && npm test` for ERP tenant/role + trial owner tests.

© Developed by Next Solution Studio
