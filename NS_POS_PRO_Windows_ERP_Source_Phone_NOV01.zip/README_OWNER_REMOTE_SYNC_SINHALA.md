# NS POS PRO — Customer POS Remote Control Integration v2.1

## මෙම package එක කුමක්ද?
Customer POS app එකට Owner v2.0 Full Control Center එකෙන් publish කරන configuration ලබාගැනීමට අවශ්‍ය receiver module එක එකතු කළ source project එකක්. පැරණි bills, inventory, account passwords හෝ product files delete කරන්නේ නැහැ. Android/Windows executable files මේ ZIP එකේ නැහැ.

## වැඩ කරන දේ
- Customer Cloud Login භාවිතා කර tenant-specific `/v1/business/control` endpoint එකෙන් cloud settings fetch කරයි.
- Billing, GRN, Orders, Returns, Rep Accounts වැනි installed modules සඳහා visibility/navigation controls (UI only) යොදයි.
- Owner-published printer preference පෙන්වයි; local printer driver/hardware connection වෙනස් කරන්නේ නැහැ.
- Update Center එකෙන් HTTPS update *notice* එකක් පෙන්වයි; silent install නොකරයි.
- Optional device status sharing: user opt-in කළාම random per-install ID, platform, app version, printer preference සහ unverified status යවයි. Customer invoices/GPS/IMEI නොයවයි.
- Offline session එකේදී අදාළ business එකටම අයත් cached settings යොදයි. වෙනත් business එකක cache එක reuse නොකරයි.
- Module toggles ඉවත් කිරීම/සඟවීම authorization substitute එකක් නොවේ; critical action permissions server-side enforce කළ යුතුයි.
- Receipt website default WWW/header duplicate fix Android source එකේම තබා ඇත. Windows source එකටත් receipt-header patch එක එකතු කළා.

## Deploy කිරීමට පෙර
1. Production Cloudflare D1 DB backup කරන්න. Staging D1 DB එකකට Owner v2 migration එක දාලා අලුත් Worker routes deploy කරන්න.
2. Existing deployed Worker code සමඟ merge කරන්න; පැරණි routes overwrite නොකරන්න.
3. Owner app එකෙන් business-specific settings publish කරලා `/v1/business/control` සහ `/v1/business/releases` routes customer token එකෙන් respond කරනවාද test කරන්න.
4. Customer POS source project build කරලා APK/EXE sign කරලා, **test customer** installation එකක install කරන්න. App update install කරන්න user approval අවශ්‍යයි.
5. Cloud Login -> Settings -> Developer Owner Remote Control -> Refresh Owner Settings. Company A settings Company B app එකට නොයන එක verify කරන්න.
6. Printer USB/Bluetooth/LAN, 58mm/80mm test physical device එකෙන් වෙනම කරන්න.

## වැදගත් සීමා
- Owner App එකෙන් අලුත් code/function එකක් ඇත්තටම fix කරන්න Android APK හෝ Windows EXE අලුත් signed release එකක් අවශ්‍යයි.
- Printer preferences remote publish කිරීම printer physical auto-connect implementation එකක් නොවේ.
- Remote receipt prefix, theme, language settings මෙම integration එකෙන් config ලෙස expose කරයි; පැරණි saved invoice IDs හෝ printing transport settings බලෙන් rewrite කරන්නේ නැහැ.
- Remote data backup/restore මෙහි අඩංගු නොවේ. Settings-only history වෙනම Owner v2.0 එකේ තිබේ.
- Windows trial policy වෙනස් කර නැහැ. Windows app currently requires online verification.
- No production Cloudflare deployment or APK/EXE compiled or device tested in this workspace.
