# NS POS PRO Windows v4.8 – Wholesale Stock + Delivery Stock

- Main GRN / Products: Product quantity enters as total stock.
- Wholesale Stock: available quantity = total stock − delivery stock assigned to reps.
- Delivery Stock: admin allocates/reclaims stock for a specific rep. Rep sales subtract from Delivery balance; wholesale sales subtract from wholesale balance.
- Stock transfers are not sales and must not increase Sales/Profit figures.
- If you have not entered products, employees, or customers, all panels show empty values; **no demo customer/employee records are added**.
- These changes keep `vehicleLedger` and `vehicleRepId` as internal legacy data-field names to prevent breaking existing local data/imports. The user-facing labels are now Wholesale / Delivery only.
- Local inventory is not a Cloudflare-synced cross-device stock ledger. To use several cashier terminals, a server-authoritative inventory allocation and transaction history is needed.
- Current v4.8 is GitHub build **source**, not a built EXE or proof of real-device tests.

## Windows build
1. Upload entire extracted ZIP to your GitHub repository.
2. GitHub Actions → Build NS POS PRO Windows EXE → Run workflow.
3. Test Windows printer, GRN, stock allocations, Rep invoices, Returns and Accounts on a test computer before a live company trial.

## No existing user data
The source bundle does not ship any user's real stock, people or customers. If your test company is empty, you can start with Products → GRN → Wholesale → Allocate to Delivery.
