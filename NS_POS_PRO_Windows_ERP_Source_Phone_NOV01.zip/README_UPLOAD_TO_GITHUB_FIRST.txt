NS POS PRO Windows ERP v4.9.1 — GitHub EXE source

This archive is a valid source ZIP with package.json at its root.
Use one repo at a time: open the same repo where the failing Actions run appears.
1. Code -> Add file -> Upload files: upload THIS ZIP to the root of that repo.
2. Ensure workflow is in .github/workflows/build-windows-exe.yml in that same repo.
3. Actions -> Run workflow (or new push auto-runs).
4. Green check -> Artifacts -> EXE download.

If an old workflow says ZIP not found, the ZIP was uploaded to a different repository or at the wrong path.
If using this archive as an extracted project instead: upload its extracted contents, including the .github folder.
Production note: this is a SOURCE archive, not an EXE. Local Node tests do not validate printer devices/cloud.
