# NS POS PRO Windows ERP v4.9.1 — GitHub එකෙන් EXE ගන්න

**මෙය source project එකයි.** Windows Setup EXE සහ Portable EXE දෙකම ඔබේම GitHub repository එකේ Actions runner එකෙන් build කළ හැක.

## Phone එකෙන් හෝ PC එකෙන්

1. GitHub එකේ **අලුත් Private Repository එකක්** හදන්න, උදා. `NS-POS-PRO-WINDOWS-ERP`.
2. මේ ZIP එක **Extract** කරන්න. `.github`, `app`, `desktop`, `tests`, `package.json`, `README...` යන folders/files repository **root** එකට upload කර Commit කරන්න. ZIP එකක් විතරක් upload කළොත් workflow run වෙන්නේ නැහැ.
3. `.github/workflows/build-windows-exe.yml` file එක තියෙන බව Code tab එකෙන් තහවුරු කරන්න.
4. **Actions → Build NS POS PRO Windows ERP v4.9.1 EXE → Run workflow** ඔබන්න (නැත්නම් main branch push එකෙන් auto run).
5. Build එක **green** වුණොත් run එකේ පහළ **Artifacts → NS-POS-PRO-Windows-EXE** download කර Extract කරන්න.
6. `NS-POS-PRO-Desktop-Setup-4.9.1-x64.exe` Windows installation සඳහාත් `NS-POS-PRO-Desktop-Portable-4.9.1-x64.exe` portable launch සඳහාත් භාවිත කරන්න.

> Windows runner එකේ `npm install` සඳහා internet access අවශ්‍යයි. GitHub Actions build එක වෙනත් dependency/packaging ගැටලුවකින් fail වෙන්න පුළුවන්. `npm run check` local JS tests පමණයි; EXE, print devices හෝ Cloudflare production test වෙනුවට නොවේ.

## ඇතුළත් දේවල්

- ඔයා තෝරපු design එකට ගැළපෙන Navy Blue Windows Dashboard, colourful icon tiles, category filters, search (Ctrl+K), local daily sales, seven-day sales chart, recent invoices, low-stock alerts, and top selling products.
- කලින් තිබුණු ERP Windows v4.9 billing, stock, GRN, Cloudflare integration hooks, 58/80 mm printer profile code, role-based navigation අදාළ files රඳවා ඇත.
- Dashboard buttons පවතින module screens වෙත යයි. **Preview එකේ පෙන්වෙන සියලු features සම්පූර්ණයෙන් Cloud-synced බව මෙය අර්ථ නොදක්වයි.** අලුත් Android ERP එකේ A4 Letter Writer / GRN Return සම්පූර්ණ implementation එක තව Windows එකට port කරලා නැහැ.
- Dashboard එකට fake sales/customer data එකතු නොවේ. Data නැත්නම් 0 පෙන්වයි.
- HR / Payroll වගේ සංවේදී modules server-side role permissions නොමැතිව production deployment නොකරන්න.

## අනිවාර්ය Data Safety

පරණ Windows ERP installation එක uninstall/overwrite කිරීමට පෙර manual backup + test restore කරන්න. Cloudflare production DB/worker deploy කරන්න කලින් staging එකක migration පරීක්ෂා කරන්න. Windows EXE එක code signed නොවන නිසා Windows SmartScreen warning එන්න පුළුවන්.

**Developer:** © Next Solution Studio
